import { resolve } from "node:path";
import { each, put } from "@red-cup-engineering/semiotic-eavt-services-section/store";

/** The store type launch-state snapshots are kept under; each snapshot carries its time as `recordedAt`. */
const TYPE = "koios-launch-state";

/**
 * The store root of this package: the package root, beside its `data/` directory.
 * @param {string} dataRoot Absolute path to this package's `data/` directory.
 * @returns {string} The store root.
 * @throws {TypeError} When `dataRoot` is not a non-empty string.
 */
function storeRoot(dataRoot) {
  if (typeof dataRoot !== "string" || dataRoot.length === 0) {
    throw new TypeError("koios intelligence briefing launch-state journal requires its data root");
  }
  return resolve(dataRoot, "..");
}

/**
 * Records one dated koios-intelligence-briefing product-line launch-state
 * snapshot: the measured claim-store topic distribution, the pricing
 * rationale, the funnel, and the explicit not-yet-solicited fence.
 * @param {{dataRoot: string, recordedAt: string, record: object}} input
 *   `dataRoot` is this package's `data/` directory; `recordedAt` is an
 *   ISO-8601 timestamp; `record` is the plain JSON-serializable launch-state
 *   payload.
 * @returns {{id: string}} The address that holds the snapshot.
 */
export function recordLaunchState({ dataRoot, recordedAt, record }) {
  return { id: put(storeRoot(dataRoot), TYPE, { ...record, recordedAt }) };
}

/**
 * Queries every recorded koios-intelligence-briefing launch-state snapshot.
 * @param {{dataRoot: string}} input `dataRoot` is this package's `data/`
 *   directory.
 * @returns {object[]} Every recorded launch-state payload, oldest first.
 */
export function queryLaunchStates({ dataRoot }) {
  return [...each(storeRoot(dataRoot), TYPE)]
    .map((entry) => entry.record)
    .sort((a, b) => (a.recordedAt < b.recordedAt ? -1 : a.recordedAt > b.recordedAt ? 1 : 0));
}
