import { request as httpRequest } from "node:http";

function originUrl(value, name) {
  const url = new URL(value);
  if (url.username || url.password || url.pathname !== "/" || url.search || url.hash) {
    throw new TypeError(`${name} must be an origin without credentials, path, query or fragment`);
  }
  return url;
}

/**
 * Keep the issued HTTPS MCP identity while dialing this machine's explicit HTTP
 * loopback listener. OAuth and MCP share this fetch port; neither sees a changed
 * issuer/resource URL. With no override, the caller's original fetch is returned.
 */
export function mcpConnectFetch({ origin, connectOrigin, fetchImpl = fetch } = {}) {
  if (connectOrigin === undefined) return fetchImpl;
  const canonical = originUrl(origin, "MCP_ORIGIN");
  const local = originUrl(connectOrigin, "MCP_CONNECT_ORIGIN");
  if (canonical.protocol !== "https:") throw new TypeError("local MCP connection requires an HTTPS MCP_ORIGIN");
  if (local.protocol !== "http:" || !["127.0.0.1", "[::1]"].includes(local.hostname)) {
    throw new TypeError("MCP_CONNECT_ORIGIN must be an HTTP loopback literal origin (127.0.0.1 or [::1])");
  }

  return async (input, init) => {
    const request = new Request(input, init);
    const url = new URL(request.url);
    if (url.origin !== canonical.origin || url.username || url.password) {
      throw new TypeError("local MCP connection refuses a URL outside MCP_ORIGIN");
    }
    request.signal.throwIfAborted();
    const body = request.body === null ? undefined : Buffer.from(await request.arrayBuffer());
    request.signal.throwIfAborted();
    const headers = Object.fromEntries(request.headers);
    // Node fetch/Undici may replace Host with the dial address. Native HTTP
    // preserves the virtual host and transmits the normalized body bytes exactly.
    headers.host = canonical.host;
    delete headers["transfer-encoding"];
    delete headers["content-length"];
    if (body !== undefined) headers["content-length"] = String(body.length);
    const destination = new URL(local);
    destination.pathname = url.pathname;
    destination.search = url.search;
    return new Promise((resolve, reject) => {
      const outgoing = httpRequest(destination, {
        method: request.method, headers, signal: request.signal,
      }, (incoming) => {
        if (incoming.statusCode >= 300 && incoming.statusCode < 400) {
          incoming.destroy();
          outgoing.destroy();
          reject(new TypeError("local MCP connection refuses redirects"));
          return;
        }
        const chunks = [];
        incoming.on("data", (chunk) => chunks.push(chunk));
        incoming.on("error", reject);
        incoming.on("end", () => {
          const responseHeaders = new Headers();
          for (let index = 0; index < incoming.rawHeaders.length; index += 2) {
            responseHeaders.append(incoming.rawHeaders[index], incoming.rawHeaders[index + 1]);
          }
          const noBody = request.method === "HEAD" || [204, 205, 304].includes(incoming.statusCode);
          resolve(new Response(noBody ? null : Buffer.concat(chunks), {
            status: incoming.statusCode, statusText: incoming.statusMessage, headers: responseHeaders,
          }));
        });
      });
      outgoing.on("error", (error) => reject(request.signal.aborted ? request.signal.reason : error));
      outgoing.end(body);
    });
  };
}
