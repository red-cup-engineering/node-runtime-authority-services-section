#!/usr/bin/env node
const { readFileSync: readInput } = globalThis.process?.getBuiltinModule?.("node:fs") ?? {};
import contract from "../schemas/form-cloudevent.json" with { type: "json" };
export const inputSchema = contract.input;
export const outputSchema = contract.output;
import { validateCloudEvent } from "./validate-cloudevent.mjs";
import { canonicalJson } from "./canonical-json.mjs";

// CloudEvents v1.0.2 context attributes and JSON-format payload members cannot
// be redefined as extensions. Keep the actual standard's top-level JSON form.
// https://github.com/cloudevents/spec/blob/v1.0.2/cloudevents/spec.md
const optionalAttributes = ["time", "datacontenttype", "dataschema", "subject"];
const reservedAttributes = new Set([
  "specversion", "id", "source", "type", ...optionalAttributes, "data", "data_base64",
]);

export function formCloudEvent(request) {
  if (request === null || typeof request !== "object" || Array.isArray(request))
    throw new TypeError("request is required");
  // This JSON-facing command must not inspect getters or serialize arbitrary
  // JavaScript values: Data has one original canonical JSON admission.
  canonicalJson(request);
  for (const name of ["id", "source", "type"])
    if (typeof request[name] !== "string" || request[name].length === 0)
      throw new TypeError(`${name} is required`);
  if (request.specversion !== undefined && request.specversion !== "1.0")
    throw new TypeError("specversion must be 1.0");
  const event = {
    specversion: "1.0",
    id: request.id,
    source: request.source,
    type: request.type,
  };
  for (const name of optionalAttributes)
    if (request[name] !== undefined) event[name] = request[name];
  // The standard JSON format distinguishes an explicit JSON null payload from
  // an absent payload. Binary payloads occupy data_base64, never data.
  const hasData = Object.hasOwn(request, "data");
  const hasBinary = Object.hasOwn(request, "data_base64");
  if (hasData && hasBinary)
    throw new TypeError("CloudEvent data and data_base64 are mutually exclusive");
  if (hasData) event.data = request.data;
  if (hasBinary) event.data_base64 = request.data_base64;
  const extensions = request.extensions ?? {};
  if (
    extensions === null ||
    typeof extensions !== "object" ||
    Array.isArray(extensions)
  )
    throw new TypeError("extensions must be an object");
  for (const [name, value] of Object.entries(extensions)) {
    if (reservedAttributes.has(name))
      throw new TypeError(`CloudEvent extension may not redefine ${name}`);
    // Own-property definition avoids __proto__ setter effects even for invalid
    // user input; the original validator then refuses invalid attribute names.
    Object.defineProperty(event, name, {
      value, enumerable: true, configurable: true, writable: true,
    });
  }
  const admission = validateCloudEvent({ event });
  if (!admission.ok)
    throw new TypeError(`CloudEvent is not conformant: ${admission.violations[0].message}`);
  return event;
}

if (import.meta.main)
  process.stdout.write(
    JSON.stringify(formCloudEvent(JSON.parse(readInput(0, "utf8")))) + "\n",
  );
