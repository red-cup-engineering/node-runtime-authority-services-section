# Computer content addressing services section

The semiotic content address (SCA) in one place: how the Group names, identifies and locates content.
Every package that names content uses this one; none keeps its own.

The section is the Content Addressing micro-enterprise (`lib/agency/enterprises/content-addressing.json`),
a node micro-enterprise that serves every other one.

## What it owns

| export | what it is | specification |
|---|---|---|
| `./semiotic-content-address` | the carrier commitment: a JSON-shaped value's canonical form, its canonical CBOR bytes and its `ni:` name (`semanticId`) | [SCA](content/text/documents/articles/specifications/2026-09-23-specification-of-the-semiotic-content-address.md), layer 1 |
| `./ni-path` | where an addressed record lives, computed from its address alone, so no index is kept | [NI path formula](content/text/documents/articles/specifications/2026-10-10-specification-of-the-ni-path-formula.md) |
| `./content-address` | the address record of raw bytes: their `ni:` name with size and media type | SCA, layer 1 |

The `ni:` URI itself (RFC 6920) is `services/uri-services-section` (`./ni-uri`); multihash and CID
transformations are `services/multiformats-services-section`.

The semantic identity of typed content (layer 2: the SEN normalized-content envelope, and the
proof-path witness identity) belongs to the notation, as the specification says, and is
`computer-data-engineering-services-section/semiotic-expression-notation/semantic-content-identity`.

## Conformance

`conformance/ni-path-v1.json` and `conformance/ni-sha256-v1.json` are the vectors every
implementation of the formula and the name reproduces. `scripts/audit-content-addressing.mjs`
finds content names minted outside this section.
