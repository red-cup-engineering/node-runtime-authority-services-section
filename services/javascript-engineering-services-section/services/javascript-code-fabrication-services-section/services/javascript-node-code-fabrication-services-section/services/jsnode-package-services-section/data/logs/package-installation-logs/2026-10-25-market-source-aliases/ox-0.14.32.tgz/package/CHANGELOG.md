# ox

## 0.14.32

### Patch Changes

- [#310](https://github.com/wevm/ox/pull/310) [`d882d95`](https://github.com/wevm/ox/commit/d882d95788b06669427ced3a44484a32221617c7) Thanks [@jxom](https://github.com/jxom)! - Added `EarnShares` to `ox/tempo`: raw EarnToken/venue-share conversions at the vault anchor rate, the dilution-correct fee-share formula, and a `minimumOutput` slippage floor.

  ```ts
  import { EarnShares } from "ox/tempo";

  const tokens = EarnShares.toTokens({ engineShares: 3n, supply: 2n }, 7n);
  const minimumShares = EarnShares.minimumOutput(1_000_000n, 50n);
  ```

## 0.14.31

### Patch Changes

- [#306](https://github.com/wevm/ox/pull/306) [`e13c054`](https://github.com/wevm/ox/commit/e13c054ecd0adf319e2b306400e1564c67051e5a) Thanks [@jxom](https://github.com/jxom)! - `viem/tempo`: Updated multisig implementation.

- [#286](https://github.com/wevm/ox/pull/286) [`56f299f`](https://github.com/wevm/ox/commit/56f299f6c046aea41b55e64f7993b831a206c47c) Thanks [@jxom](https://github.com/jxom)! - Added `eth_getRawTransactionByHash` to `RpcSchema.Eth`.

- [#291](https://github.com/wevm/ox/pull/291) [`5ebb88d`](https://github.com/wevm/ox/commit/5ebb88dfc6139573844d9c6b97eed8c463ee1d3a) Thanks [@jxom](https://github.com/jxom)! - Fixed `KeyAuthorization.fromRpc` return type mismatch under TypeScript configs without `exactOptionalPropertyTypes`.

- [#284](https://github.com/wevm/ox/pull/284) [`c86f635`](https://github.com/wevm/ox/commit/c86f6350f199a0f5a9705083ad545da760e1f5c4) Thanks [@jxom](https://github.com/jxom)! - Fixed `AbiParameters.encode` and `AbiParameters.decode` handling of zero-width types (zero-length fixed arrays and empty tuples).

## 0.14.30

### Patch Changes

- [#281](https://github.com/wevm/ox/pull/281) [`da3309e`](https://github.com/wevm/ox/commit/da3309e19907db3e5a497140dee5e9041c05f514) Thanks [@jxom](https://github.com/jxom)! - **Breaking (`ox/tempo`):** Removed the TIP-1061 multisig `config_id` concept to match the updated Tempo reference implementation: multisig account addresses now derive directly from the initial config, owner approval digests bind only `account`, the signature wire format is `0x05 || rlp([account, signatures, init?])`, `MultisigConfig.maxOwners` is now 255 with `u8` weights, and owner approvals may be nested multisig signatures.

  ```diff
  - const id = MultisigConfig.toId(genesisConfig)
  - const account = MultisigConfig.getAddress({ genesisConfigId: id })
  + const account = MultisigConfig.getAddress(genesisConfig)

  - MultisigConfig.getSignPayload({ payload, account, genesisConfigId })
  + MultisigConfig.getSignPayload({ payload, account })

  - SignatureEnvelope.from({ account, genesisConfigId, signatures })
  + SignatureEnvelope.from({ account, signatures })
  ```

## 0.14.29

### Patch Changes

- [#268](https://github.com/wevm/ox/pull/268) [`ed93945`](https://github.com/wevm/ox/commit/ed93945197dd505d4848535de72a93c225fa8466) Thanks [@jxom](https://github.com/jxom)! - `viem/tempo`: Added `genesisConfig` shorthand to TIP-1061 multisig helpers and renamed `configId` → `genesisConfigId` on the typed `SignatureEnvelope.Multisig`.

## 0.14.28

### Patch Changes

- [#265](https://github.com/wevm/ox/pull/265) [`f5328d2`](https://github.com/wevm/ox/commit/f5328d2fb5f76f4d037ecb1ae5974a078e7b5034) Thanks [@jxom](https://github.com/jxom)! - `viem/tempo`: Added support for TIP-1061 native multisig accounts.

## 0.14.27

### Patch Changes

- [#263](https://github.com/wevm/ox/pull/263) [`451a442`](https://github.com/wevm/ox/commit/451a442f7c3ba0d415ce4c212bc9b6bc7fd0034e) Thanks [@jxom](https://github.com/jxom)! - `ox/tempo`: Added the `ReceivePolicyReceipt` module for encoding/decoding TIP-1028 receive-policy claim receipts (`ClaimReceiptV1` witnesses) with `decode`, `encode`, `from`, `fromLog`, and `fromTransactionReceipt` (returns one receipt per `TransferBlocked` log).

## 0.14.26

### Patch Changes

- [#262](https://github.com/wevm/ox/pull/262) [`b1ac8c8`](https://github.com/wevm/ox/commit/b1ac8c83f9f5f7a89e14f3486a1e32305e019292) Thanks [@jxom](https://github.com/jxom)! - `ox/tempo`: Added support for TIP-1049 (admin access keys) via optional `isAdmin` and `account` fields on `KeyAuthorization` that bind into the signing hash.

- [#260](https://github.com/wevm/ox/pull/260) [`581ccee`](https://github.com/wevm/ox/commit/581ccee2d9dab4a2c2f12aad0b2a63b1d4d0d62d) Thanks [@jxom](https://github.com/jxom)! - `ox/tempo`: Added support for TIP-1053 (witnesses in key authorizations) via an optional 32-byte `witness` field on `KeyAuthorization` that is included in the signing hash.

## 0.14.25

### Patch Changes

- [#256](https://github.com/wevm/ox/pull/256) [`ad7610b`](https://github.com/wevm/ox/commit/ad7610b115c1ebc20739289bfacead52652160be) Thanks [@jxom](https://github.com/jxom)! - Renamed `ChannelDescriptor.from` to `Channel.from`, made `Channel.Channel` the descriptor type, and changed `Channel.computeId` to receive channel and options separately.

## 0.14.24

### Patch Changes

- [#254](https://github.com/wevm/ox/pull/254) [`d837628`](https://github.com/wevm/ox/commit/d8376284988f6c2b56d9cb18ac2b677465f3b835) Thanks [@jxom](https://github.com/jxom)! - Added `ChannelDescriptor.from` for normalizing TIP-20 channel reserve descriptors.

## 0.14.23

### Patch Changes

- [#252](https://github.com/wevm/ox/pull/252) [`19cd833`](https://github.com/wevm/ox/commit/19cd83342bfddc682a8897f0cb5c383e8954586d) Thanks [@jxom](https://github.com/jxom)! - Added TIP-20 channel reserve constants, channel id computation, and voucher signing helpers.

## 0.14.22

### Patch Changes

- [#227](https://github.com/wevm/ox/pull/227) [`ffa64c0`](https://github.com/wevm/ox/commit/ffa64c0d56c218a9cf3aaa93570c6fa6ef187864) Thanks [@Genmin](https://github.com/Genmin)! - Fixed `Secp256k1.verify` narrowing signature branches before address recovery.

## 0.14.21

### Patch Changes

- [#246](https://github.com/wevm/ox/pull/246) [`32cf459`](https://github.com/wevm/ox/commit/32cf459b263edf8ffb937578e79b5792b0166294) Thanks [@0xrusowsky](https://github.com/0xrusowsky)! - Added `TxEnvelopeTempo.encodeForSigning` to expose the raw Tempo sender-signing preimage bytes.

- [#248](https://github.com/wevm/ox/pull/248) [`e0474e9`](https://github.com/wevm/ox/commit/e0474e982e2d5f961ac1c0f966e542d201c3f1fa) Thanks [@jxom](https://github.com/jxom)! - Added `blockTimestamp` support to transaction RPC conversions.

## 0.14.20

### Patch Changes

- [#225](https://github.com/wevm/ox/pull/225) [`7203ffc`](https://github.com/wevm/ox/commit/7203ffcc55cbcd1e31e7d89cd43bd86a948c135a) Thanks [@jxom](https://github.com/jxom)! - Fixed webpack compatibility for `VirtualMaster` by making the `node:worker_threads` import specifier non-literal, preventing bundlers from statically analyzing and failing on the `node:` scheme.

## 0.14.19

### Patch Changes

- [`3f6682d`](https://github.com/wevm/ox/commit/3f6682d88ba3ac53f4f84764acf62111ac229c9c) Thanks [@jxom](https://github.com/jxom)! - Embedded WASM keccak256 salt miner for `VirtualMaster.mineSaltAsync`. Added platform-agnostic worker pool supporting Node.js, Bun, Deno (`worker_threads`), and browsers (Web Workers via Blob URLs).

## 0.14.18

### Patch Changes

- [#221](https://github.com/wevm/ox/pull/221) [`3b84126`](https://github.com/wevm/ox/commit/3b841266704b2e2bc24359462bafd8acd7a16ec9) Thanks [@tmm](https://github.com/tmm)! - Added [TIP-1022](https://docs.tempo.xyz/protocol/tips/tip-1022) virtual address utilities to `ox/tempo`, including `VirtualAddress` helpers for formatting and parsing virtual addresses and `VirtualMaster` helpers for deriving registration hashes, validating salts, and mining bounded salt ranges.

## 0.14.17

### Patch Changes

- [#220](https://github.com/wevm/ox/pull/220) [`da7a62c`](https://github.com/wevm/ox/commit/da7a62cfbecb99b3cc24f275703e33b1320abb1b) Thanks [@Zygimantass](https://github.com/Zygimantass)! - Added Tempo zones support

- [#219](https://github.com/wevm/ox/pull/219) [`a934992`](https://github.com/wevm/ox/commit/a934992257add3724f16538c7a14d72e647a2b66) Thanks [@jxom](https://github.com/jxom)! - Added `feePayer` to `TransactionRequest` in `ox/tempo`.

- [#217](https://github.com/wevm/ox/pull/217) [`5e2ae4d`](https://github.com/wevm/ox/commit/5e2ae4d9a007bb4071896c5e4c0f258e9a637a54) Thanks [@jxom](https://github.com/jxom)! - Fixed `TransactionRequest.fromRpc` in `ox/tempo`. `TransactionRequest.toRpc` now folds top-level `to`/`data`/`value` into `calls` when `calls` is not provided.

## 0.14.16

### Patch Changes

- [`3ca1d56`](https://github.com/wevm/ox/commit/3ca1d56ac70a883fad5100e3d4da8208b84f5a20) Thanks [@jxom](https://github.com/jxom)! - Added `TransactionRequest.fromRpc` to `ox/tempo`.

## 0.14.15

### Patch Changes

- [`d073091`](https://github.com/wevm/ox/commit/d0730912904d951d3609d7191c5d83fc2d00030d) Thanks [@jxom](https://github.com/jxom)! - Fixed `TransactionRequest.blobVersionedHashes` to include `| undefined` for `exactOptionalPropertyTypes` compatibility.

## 0.14.14

### Patch Changes

- [`14137f7`](https://github.com/wevm/ox/commit/14137f77136a1184f5fecbb6083e7a93495ab7f8) Thanks [@jxom](https://github.com/jxom)! - Added `RpcSchema.ToViem` and `RpcSchema.FromViem` type utilities for converting between Ox and Viem RPC schema formats. Added `tempo_simulateV1` RPC schema to `ox/tempo`.

## 0.14.13

### Patch Changes

- [`68f8fa0`](https://github.com/wevm/ox/commit/68f8fa0514032e5495b6c527c61c957e1545850d) Thanks [@jxom](https://github.com/jxom)! - viem/tempo: Renamed `contractAddress` to `address` on `KeyAuthorization.Scope`. Added support for human-readable ABI signatures in `selector` (e.g. `'transfer(address,uint256)'`), which are automatically encoded into 4-byte selectors.

## 0.14.12

### Patch Changes

- [#208](https://github.com/wevm/ox/pull/208) [`30537f8`](https://github.com/wevm/ox/commit/30537f82b2721d5d8dbccdbc4fc422b4d41b0993) Thanks [@dgca](https://github.com/dgca)! - Added `serviceCodes` field to ERC-8021 `Attribution` schema.

- [#211](https://github.com/wevm/ox/pull/211) [`9d0d676`](https://github.com/wevm/ox/commit/9d0d6766385686ee380f5793d0ccb54f5928c153) Thanks [@jxom](https://github.com/jxom)! - `viem/tempo`: Added support for period and call scopes on `KeyAuthorization`.

## 0.14.11

### Patch Changes

- [#209](https://github.com/wevm/ox/pull/209) [`52d985e`](https://github.com/wevm/ox/commit/52d985e54ab063e4d835ad467da2bcf07fcbfb33) Thanks [@jxom](https://github.com/jxom)! - Fixed `Credential.serialize` to extract `authenticatorData` from the CBOR-encoded `attestationObject` when the browser/passkey provider doesn't expose it on the response object (e.g. Firefox + 1Password).

## 0.14.10

### Patch Changes

- [#204](https://github.com/wevm/ox/pull/204) [`9aec6a9`](https://github.com/wevm/ox/commit/9aec6a94ba294c38ec937dc8522582e2f0a40ddc) Thanks [@jxom](https://github.com/jxom)! - Added `Ed25519.toX25519PublicKey` and `Ed25519.toX25519PrivateKey` for converting Ed25519 keys to X25519 keys. Useful for performing X25519 Diffie-Hellman key exchange using an Ed25519 signing key pair.

## 0.14.9

### Patch Changes

- [#201](https://github.com/wevm/ox/pull/201) [`ea94ea6`](https://github.com/wevm/ox/commit/ea94ea627eec365de22ade3126dc39b824cc53f9) Thanks [@decofe](https://github.com/decofe)! - Fixed `KeyAuthorization.fromRpc` to preserve `undefined` expiry instead of defaulting to `0`.

## 0.14.8

### Patch Changes

- [`0d0575e`](https://github.com/wevm/ox/commit/0d0575e36503403ce245eaaaf29aac106bad508a) Thanks [@jxom](https://github.com/jxom)! - Added ERC-8021 Schema 2 (CBOR-encoded) attribution support to the `Attribution` module.

## 0.14.7

### Patch Changes

- [`8d51883`](https://github.com/wevm/ox/commit/8d5188398a2d63bbee566e1f59a00da345c3cc99) Thanks [@jxom](https://github.com/jxom)! - ox/tempo: Fixed output types.

## 0.14.6

### Patch Changes

- [#197](https://github.com/wevm/ox/pull/197) [`28ac186`](https://github.com/wevm/ox/commit/28ac1866867eda53bb2e2114f043d674cfcb093a) Thanks [@jxom](https://github.com/jxom)! - Fixed WebAuthn response serialization to fall back to getter methods (e.g. `getAuthenticatorData()`) when properties are not directly accessible on the response object. Some browsers and passkey providers (e.g. 1Password, Firefox) proxy the credential object, making property access return `undefined` even though the data is available via getter methods.

## 0.14.5

### Patch Changes

- [`6dcde2c`](https://github.com/wevm/ox/commit/6dcde2c34ae05928c9e7fd021af3731390b39619) Thanks [@jxom](https://github.com/jxom)! - Fixed type incompatibility between ox's `CredentialCreationOptions`/`CredentialRequestOptions` and the DOM's built-in types.

## 0.14.4

### Patch Changes

- [`0189572`](https://github.com/wevm/ox/commit/0189572f95c96bb9fed70966f7e0fa0eb951dee2) Thanks [@jxom](https://github.com/jxom)! - `ox/tempo`: Fixed sender recovery for fee payer transactions.

## 0.14.3

### Patch Changes

- [`3f7b80c`](https://github.com/wevm/ox/commit/3f7b80cb6537b407318abb6c6824b9daf91f02ef) Thanks [@jxom](https://github.com/jxom)! - Updated `TempoAddress` to new format.

## 0.14.2

### Patch Changes

- [`3dbb585`](https://github.com/wevm/ox/commit/3dbb5851fb486bdb2af5083f989018e6b2489847) Thanks [@jxom](https://github.com/jxom)! - Fixed `Registration.create` and `Authentication.sign` throwing "Permission denied to access object" in Firefox with the 1Password extension. Replaced `.bind()` defaults on `navigator.credentials.create`/`.get` with arrow functions, eagerly read credential response properties (`attestationObject`, `clientDataJSON`, `authenticatorData`, `signature`, `id`) before subsequent access is blocked by the cross-compartment proxy, and passed the already-read `attestationObject` to `parseCredentialPublicKey` so the 1Password fallback path no longer re-accesses the proxy.

## 0.14.1

### Patch Changes

- [`e0d36d4`](https://github.com/wevm/ox/commit/e0d36d4c82ee5234078df083fe5ebc845fe8676f) Thanks [@jxom](https://github.com/jxom)! - Added `keyId` to `SignatureEnvelope` and made keychain signatures default to v2.

## 0.14.0

### Minor Changes

- [#178](https://github.com/wevm/ox/pull/178) [`4a79ac5`](https://github.com/wevm/ox/commit/4a79ac540c05796ebc92a0d54ce0049a6ff5e195) Thanks [@jxom](https://github.com/jxom)! - **Breaking (`ox/tempo`):** `KeyAuthorization.chainId` is now required.

  ```diff
   const authorization = KeyAuthorization.from({
     address,
  +  chainId: 1n,
     expiry: 1234567890,
     type: 'secp256k1',
   })
  ```

### Patch Changes

- [#178](https://github.com/wevm/ox/pull/178) [`4a79ac5`](https://github.com/wevm/ox/commit/4a79ac540c05796ebc92a0d54ce0049a6ff5e195) Thanks [@jxom](https://github.com/jxom)! - **`ox/tempo`:** Added support for V2 keychain signature type (`0x04`) which binds the inner signature to the user account via `keccak256(0x04 || sigHash || userAddress)`.

## 0.13.2

### Patch Changes

- [#179](https://github.com/wevm/ox/pull/179) [`4b91335`](https://github.com/wevm/ox/commit/4b91335b5a68cfee39248ab91c78a0b98b1d1859) Thanks [@jxom](https://github.com/jxom)! - Added `Base32`, `CompactSize`, and `TempoAddress` modules. `Base32` implements BIP-173 bech32 base32 encoding/decoding. `CompactSize` implements Bitcoin's variable-length integer encoding. `TempoAddress` provides human-readable Tempo address formatting and parsing with `tempo1`/`tempoz1` prefixes, CompactSize zone ID encoding, and double-SHA256 checksumming.

## 0.13.1

### Patch Changes

- [`50c4d08`](https://github.com/wevm/ox/commit/50c4d08556e3c049979b24200efcb5534c156411) Thanks [@jxom](https://github.com/jxom)! - `ox/tempo`: Added `KeyAuthorization.serialize` and `KeyAuthorization.deserialize` for RLP encoding/decoding key authorizations.

  `ox/tempo`: Fixed `KeyAuthorization.toTuple` to always include expiry in the tuple when limits are present, preventing malformed RLP encoding.

- [`50c4d08`](https://github.com/wevm/ox/commit/50c4d08556e3c049979b24200efcb5534c156411) Thanks [@jxom](https://github.com/jxom)! - `ox/tempo`: Added `SignatureEnvelope.extractAddress` and `SignatureEnvelope.extractPublicKey` to extract signer address/public key from a signature envelope. Handles all signature types: secp256k1 (via ecrecover), p256/webAuthn (from embedded public key), and keychain (from inner signature or root `userAddress`).

## 0.13.0

### Minor Changes

- [`c8c6229`](https://github.com/wevm/ox/commit/c8c62297ac43161095482176e1846ce61bb62eb5) Thanks [@jxom](https://github.com/jxom)! - Overhauled WebAuthn support with a dedicated `ox/webauthn` entrypoint for server-side registration & authentication ceremonies, credential management, and authenticator data parsing.

  - `Registration` – Full registration ceremony: `create`, `getOptions`, `verify`, with `serializeOptions`/`deserializeOptions` for server↔client transport
  - `Authentication` – Full authentication ceremony: `sign`, `getOptions`, `verify`, with `serializeOptions`/`deserializeOptions` for server↔client transport
  - `Credential` – `serialize`/`deserialize` for persisting and transporting WebAuthn credentials as JSON
  - `Authenticator` – Low-level utilities for constructing/parsing authenticator data, attestation objects, and client data JSON

## 0.12.4

### Patch Changes

- [`772f3eb`](https://github.com/wevm/ox/commit/772f3eb7139d1ef1f8f7271d3d10729948195b42) Thanks [@jxom](https://github.com/jxom)! - Added support for recovering the sender address (`from`) from the transaction signature in `TxEnvelopeTempo.deserialize`.

## 0.12.3

### Patch Changes

- [#171](https://github.com/wevm/ox/pull/171) [`d206a6e`](https://github.com/wevm/ox/commit/d206a6e3c371b9ed5d89ec89adcf86eba35bd6ed) Thanks [@jxom](https://github.com/jxom)! - Fixed COSE key encoding in `WebAuthnP256.getAuthenticatorData` to use CBOR integer keys.

- [#171](https://github.com/wevm/ox/pull/171) [`d206a6e`](https://github.com/wevm/ox/commit/d206a6e3c371b9ed5d89ec89adcf86eba35bd6ed) Thanks [@jxom](https://github.com/jxom)! - Added `CoseKey` module with `fromPublicKey` and `toPublicKey` for converting between P256 public keys and CBOR-encoded COSE_Key format.

- [#171](https://github.com/wevm/ox/pull/171) [`d206a6e`](https://github.com/wevm/ox/commit/d206a6e3c371b9ed5d89ec89adcf86eba35bd6ed) Thanks [@jxom](https://github.com/jxom)! - Added `Map` support to `Cbor.encode` for encoding maps with non-string keys (e.g. CBOR integer keys).

- [#171](https://github.com/wevm/ox/pull/171) [`d206a6e`](https://github.com/wevm/ox/commit/d206a6e3c371b9ed5d89ec89adcf86eba35bd6ed) Thanks [@jxom](https://github.com/jxom)! - Fixed `WebAuthnP256.verify` type-check slice bug.

## 0.12.2

### Patch Changes

- [`ddf03bc`](https://github.com/wevm/ox/commit/ddf03bcb9fef345e3ee45999855d15554b006ec1) Thanks [@jxom](https://github.com/jxom)! - Added `Json.canonicalize` (RFC 8785)

## 0.12.1

### Patch Changes

- [#166](https://github.com/wevm/ox/pull/166) [`480d01a`](https://github.com/wevm/ox/commit/480d01ae5f165b2d06474df1a417abca814b57c2) Thanks [@jxom](https://github.com/jxom)! - Derived sender address from signature in `TxEnvelopeTempo.serialize` when using `format: 'feePayer'`.

## 0.12.0

### Minor Changes

- [`f605321`](https://github.com/wevm/ox/commit/f60532162ff75c3dd19ebfa9ad1c56905fb35fb6) Thanks [@jxom](https://github.com/jxom)! - Added `Hash.hmac256` for computing HMAC-SHA256 hashes.

## 0.11.3

### Patch Changes

- [`4a79129`](https://github.com/wevm/ox/commit/4a79129da654098ee28ac63b4771a47a4bb57179) Thanks [@jxom](https://github.com/jxom)! - Fixed `TokenId.compute` return value.

## 0.11.2

### Patch Changes

- [#153](https://github.com/wevm/ox/pull/153) [`95ebfcf`](https://github.com/wevm/ox/commit/95ebfcf1caf857b3658c26c26bb2d6ebbd88b904) Thanks [@jxom](https://github.com/jxom)! - Added `TokenId.compute` to compute deterministic TIP-20 token addresses from sender and salt.

## 0.11.1

### Patch Changes

- [`11cde15`](https://github.com/wevm/ox/commit/11cde150fa9ad07c4e2f398c20ab95278a8ab0d5) Thanks [@jxom](https://github.com/jxom)! - Fixed `KeyAuthorization.toRpc`

## 0.11.0

### Minor Changes

- [`4c55afa`](https://github.com/wevm/ox/commit/4c55afa2c942eb86789b1315e5b4ccc4611aafca) Thanks [@jxom](https://github.com/jxom)! - **Breaking:** Renamed `prehash` to `preHash` on `KeyAuthorization#P256Rpc`

## 0.10.6

### Patch Changes

- [`a24f08a`](https://github.com/wevm/ox/commit/a24f08a11b9d980709512fda6cbd350c44500b30) Thanks [@jxom](https://github.com/jxom)! - Updated `TransactionRequest.toRpc` for Tempo.

## 0.10.5

### Patch Changes

- [`e750936`](https://github.com/wevm/ox/commit/e7509364b3e9c0db3ec34e82e4e3b5baf43164e9) Thanks [@jxom](https://github.com/jxom)! - Throw error if signature envelope type not supported.

## 0.10.4

### Patch Changes

- [`a449324`](https://github.com/wevm/ox/commit/a44932462769ac9e9a42e342310eae3d821e130c) Thanks [@jxom](https://github.com/jxom)! - Added `SignatureEnvelope.verify`.

- [`fa6cc3c`](https://github.com/wevm/ox/commit/fa6cc3c64bc358d3c31c6a4e0ac76960ec36b9c1) Thanks [@jxom](https://github.com/jxom)! - Added `magic` to `SignatureEnvelope.serialize`.

## 0.10.3

### Patch Changes

- [#144](https://github.com/wevm/ox/pull/144) [`253b471`](https://github.com/wevm/ox/commit/253b47185cad37083fc9f50f150b831c23274bc5) Thanks [@tmm](https://github.com/tmm)! - Bumped ABIType

## 0.10.2

### Patch Changes

- [`a98c346`](https://github.com/wevm/ox/commit/a98c346aead489f5c4697f5a2cbf6f5803921655) Thanks [@jxom](https://github.com/jxom)! - `ox/tempo`: Removed `0x` fallback on `to` for `TransactionRequest.toRpc`

## 0.10.1

### Patch Changes

- [`a5a63d4`](https://github.com/wevm/ox/commit/a5a63d4940734fb8df042df1f67aa0c6c8d9b698) Thanks [@jxom](https://github.com/jxom)! - Explicitly widened `WebAuthn` `getFn`/`createFn` to avoid downstream type conflicts.

## 0.10.0

### Minor Changes

- [#138](https://github.com/wevm/ox/pull/138) [`29a2f43`](https://github.com/wevm/ox/commit/29a2f4357c90fad0c4ba69e3ebf3665bdd5c30d1) Thanks [@wbj-cb](https://github.com/wbj-cb)! - **Breaking:** Aligned to latest ERC-8021 specification. Modified `Attribution.toDataSuffix` parameters to include `codeRegistry` instead of `registryAddress`.

  ```diff ts twoslash
  Attribution.toDataSuffix({
      codes: ['baseapp', 'morpho'],
  -   registryAddress: '0xcccccccccccccccccccccccccccccccccccccccc',
  +   codeRegistry: {
  +       address: '0xcccccccccccccccccccccccccccccccccccccccc`
  +       chainId: 8453,
  +   }
  })
  ```

- [`f8bf590`](https://github.com/wevm/ox/commit/f8bf5908bfaf3b1a5d39c38cea98ed58fc9f7935) Thanks [@jxom](https://github.com/jxom)! - **Breaking:** Renamed `TransactionEnvelope*` to `TxEnvelope*`.

- [#140](https://github.com/wevm/ox/pull/140) [`7997629`](https://github.com/wevm/ox/commit/79976295604ef5281c33a89af9d59a6fafc9ddd0) Thanks [@jxom](https://github.com/jxom)! - Added `ox/tempo` entrypoint.

## 0.9.17

### Patch Changes

- [`e63c3b2`](https://github.com/wevm/ox/commit/e63c3b254371473becc918b7efc8ce89d0eeb5bb) Thanks [@jxom](https://github.com/jxom)! - Tweaked `WebAuthnP256.createCredential` to accept `challenge` of type `Hex`.

## 0.9.16

### Patch Changes

- [`d11e1fb`](https://github.com/wevm/ox/commit/d11e1fbd2554194a67d37c4da34dcf9f749e3698) Thanks [@jxom](https://github.com/jxom)! - Modified `WebAuthnP256.verify` to work with only `clientDataJSON` and `authenticatorData`

## 0.9.15

### Patch Changes

- [#133](https://github.com/wevm/ox/pull/133) [`07a7bb0`](https://github.com/wevm/ox/commit/07a7bb0110e38062c000d9e403e61621547eda7f) Thanks [@jxom](https://github.com/jxom)! - Added `Cbor` module.

## 0.9.14

### Patch Changes

- [`896096d`](https://github.com/wevm/ox/commit/896096d17516f686321b9353807bdaa63e7544cc) Thanks [@jxom](https://github.com/jxom)! - Exported types required for inference.

## 0.9.13

### Patch Changes

- [`95458ee`](https://github.com/wevm/ox/commit/95458ee13dc1b9333deb948791225e3883fb8b82) Thanks [@jxom](https://github.com/jxom)! - Added `TransactionRequest.fromRpc`

- [`c165694`](https://github.com/wevm/ox/commit/c1656940e959b9e904c3ec497b720e1315f390e2) Thanks [@jxom](https://github.com/jxom)! - Added ability to pass custom event map to `Provider.createEmitter`.

- [`c165694`](https://github.com/wevm/ox/commit/c1656940e959b9e904c3ec497b720e1315f390e2) Thanks [@jxom](https://github.com/jxom)! - Added ability to pass `schema` to `RpcRequest.createStore`

## 0.9.12

### Patch Changes

- [`242558a`](https://github.com/wevm/ox/commit/242558a745169931b08030f7e4b41f21b2d65e24) Thanks [@jxom](https://github.com/jxom)! - Fixed formatting between metadata and version on `BaseError`.

## 0.9.11

### Patch Changes

- [#126](https://github.com/wevm/ox/pull/126) [`b4572ed`](https://github.com/wevm/ox/commit/b4572ed6feaed7ee1063f8b710d98e928d848016) Thanks [@jxom](https://github.com/jxom)! - Added `ox/erc8021` entrypoint.

## 0.9.10

### Patch Changes

- [`f61d713`](https://github.com/wevm/ox/commit/f61d713d6dd5387b5f4d1c71643b28e77e1aaff8) Thanks [@jxom](https://github.com/jxom)! - Added `version` and `docsOrigin` to `Errors.BaseError`.

## 0.9.9

### Patch Changes

- [`a1c8a43`](https://github.com/wevm/ox/commit/a1c8a43d0d6549c1be8aa86d32a10e8ee327ffcf) Thanks [@jxom](https://github.com/jxom)! - Added `eth_sendRawTransactionSync` to types.

## 0.9.8

### Patch Changes

- [#119](https://github.com/wevm/ox/pull/119) [`447e386`](https://github.com/wevm/ox/commit/447e386a50fe514cf2abd472bace0a934d068358) Thanks [@jxom](https://github.com/jxom)! - Added [ERC-7821](https://eips.ethereum.org/EIPS/eip-7821) modules.

## 0.9.7

### Patch Changes

- [`8a08b24`](https://github.com/wevm/ox/commit/8a08b243bd255a2e35cd24a3d5d1bb3342b1f672) Thanks [@jxom](https://github.com/jxom)! - Serialize `type` on `TransactionRequest.toRpc`.

- [`5e1c0df`](https://github.com/wevm/ox/commit/5e1c0df66d429aa43a1e90b56a3daba788cedd6d) Thanks [@jxom](https://github.com/jxom)! - Added micro-optimizations.

## 0.9.6

### Patch Changes

- [`c154290`](https://github.com/wevm/ox/commit/c154290c6958702f854bece58309a15694589f22) Thanks [@jxom](https://github.com/jxom)! - Added ABI-shorthand for `AbiItem.{getSelector,getSignature,getSignatureHash}`

## 0.9.5

### Patch Changes

- [#113](https://github.com/wevm/ox/pull/113) [`e21cb3c`](https://github.com/wevm/ox/commit/e21cb3cf0b7412f9ca72824247d22ba25e8be4c9) Thanks [@jxom](https://github.com/jxom)! - Added support for specifying the ABI and signature name to:

  - `AbiFunction.{encodeData,encodeResult,decodeData,decodeResult}`
  - `AbiError.{encode,decode}`
  - `AbiEvent.{encode,decode}`

  Example:

  ```ts twoslash
  import { AbiFunction } from "ox";
  import { abi } from "./abi";

  const data = AbiFunction.encodeData(abi, "approve", [
    "0x0000000000000000000000000000000000000000",
    1n,
  ]);
  ```

## 0.9.4

### Patch Changes

- [`8aaf1a4`](https://github.com/wevm/ox/commit/8aaf1a4c4aedf654abf9319932eb57b560186d43) Thanks [@jxom](https://github.com/jxom)! - Removed proxy packages. Metro (the problematic bundler) now respects `package.json#exports`.

## 0.9.3

### Patch Changes

- [`1cd8943`](https://github.com/wevm/ox/commit/1cd894336fb0a4cef8b0879cc214a7997fea1042) Thanks [@jxom](https://github.com/jxom)! - Updated dependencies.

## 0.9.2

### Patch Changes

- [`9be7919`](https://github.com/wevm/ox/commit/9be791906d9496111a1607344ddb02077f02f6a6) Thanks [@jxom](https://github.com/jxom)! - Updated `ox/erc8010` to latest spec changes.

## 0.9.1

### Patch Changes

- [`dec161a`](https://github.com/wevm/ox/commit/dec161ac7b3089bd6a0647d91e02f174ac421d65) Thanks [@jxom](https://github.com/jxom)! - Fixed `signature` type on ERC-6492 and ERC-8010.

## 0.9.0

### Minor Changes

- [#104](https://github.com/wevm/ox/pull/104) [`4f4b635`](https://github.com/wevm/ox/commit/4f4b635dfb399ca9df07bab843857743f389639e) Thanks [@jxom](https://github.com/jxom)! - **Breaking(`ox/erc6492`:**

  - Renamed `WrappedSignature` to `SignatureErc6492`
  - Renamed `WrappedSignature.WrappedSignature` to `SignatureErc6492.Unwrapped`
  - Renamed `WrappedSignature.toHex` to `SignatureErc6492.wrap`
  - Renamed `WrappedSignature.fromHex` to `SignatureErc6492.unwrap`

- [#104](https://github.com/wevm/ox/pull/104) [`4f4b635`](https://github.com/wevm/ox/commit/4f4b635dfb399ca9df07bab843857743f389639e) Thanks [@jxom](https://github.com/jxom)! - Added `ox/erc8010` entrypoint with `SignatureErc8010` module.

## 0.8.9

### Patch Changes

- [#102](https://github.com/wevm/ox/pull/102) [`5796d6d`](https://github.com/wevm/ox/commit/5796d6dbebff719c84b4658de37e3240adbc87e1) Thanks [@dan1kov](https://github.com/dan1kov)! - Fixed signature destructuring on `Authorization.fromTuple`.

## 0.8.8

### Patch Changes

- [#98](https://github.com/wevm/ox/pull/98) [`96c2046`](https://github.com/wevm/ox/commit/96c20462420a3e6be1301cccb4b66afe1bccc3f8) Thanks [@mmv08](https://github.com/mmv08)! - Added handling for `bigint` chain IDs in `TypedData.extractEip712DomainTypes`.

## 0.8.7

### Patch Changes

- [`9a9ef21`](https://github.com/wevm/ox/commit/9a9ef21e17f982fa6f7b76d5ad615b68d200d9eb) Thanks [@jxom](https://github.com/jxom)! - Fixed zeroish conversion of `chainId` and `nonce` in `Authorization.fromTuple`.

## 0.8.6

### Patch Changes

- [#94](https://github.com/wevm/ox/pull/94) [`301c319`](https://github.com/wevm/ox/commit/301c319fafab25b1a3a85bcf6bc81c3c9dee72d9) Thanks [@jxom](https://github.com/jxom)! - **ERC-4337**: Added `UserOperation.fromPacked`.

## 0.8.5

### Patch Changes

- [#92](https://github.com/wevm/ox/pull/92) [`b6eaa05`](https://github.com/wevm/ox/commit/b6eaa055ce415cd24f802b8bfa5bdbbd53480ab8) Thanks [@jxom](https://github.com/jxom)! - Added support for EntryPoint 0.8.

## 0.8.4

### Patch Changes

- [`ce19a08`](https://github.com/wevm/ox/commit/ce19a087bffaa205067fca530532fb05cc02c792) Thanks [@jxom](https://github.com/jxom)! - Added `stack` to `Provider.InternalError`.

## 0.8.3

### Patch Changes

- [#74](https://github.com/wevm/ox/pull/74) [`72209ef`](https://github.com/wevm/ox/commit/72209efaf2bf6dd5d71274db8df7416532ebe9cb) Thanks [@danpopenko](https://github.com/danpopenko)! - Added extensions support for `WebAuthnP256.sign`.

## 0.8.2

### Patch Changes

- [`9fd0bf0`](https://github.com/wevm/ox/commit/9fd0bf0460694709566805bc29f50cad25816620) Thanks [@jxom](https://github.com/jxom)! - Added [ECDH (Elliptic Curve Diffie-Hellman)](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/deriveKey#ecdh) shared secrets to `P256`, `Secp256k1`, and `WebCryptoP256` modules. This enables secure key agreement between parties using elliptic curve cryptography for both secp256k1 and secp256r1 (P256) curves, with support for both `@noble/curves` (for `P256` and `Secp256k1`) implementation and Web Crypto APIs (`WebCryptoP256`).

  - `P256.getSharedSecret`
  - `Secp256k1.getSharedSecret`
  - `WebCryptoP256.getSharedSecret`

- [`9fd0bf0`](https://github.com/wevm/ox/commit/9fd0bf0460694709566805bc29f50cad25816620) Thanks [@jxom](https://github.com/jxom)! - Added `createKeyPair` helper functions for `Bls`, `P256`, and `Secp256k1` modules. These functions provide a convenient way to generate complete key pairs (private key + public key) in a single operation, simplifying key generation workflows and reducing the need for separate `randomPrivateKey` and `getPublicKey` calls.

- [`9fd0bf0`](https://github.com/wevm/ox/commit/9fd0bf0460694709566805bc29f50cad25816620) Thanks [@jxom](https://github.com/jxom)! - Added `Ed25519` and `X25519` modules. The `Ed25519` module provides functionality for creating key pairs, signing messages, and verifying signatures using the Ed25519 signature scheme. The `X25519` module enables Elliptic Curve Diffie-Hellman (ECDH) key agreement operations for secure shared secret derivation.

## 0.8.1

### Patch Changes

- [`74e47c5`](https://github.com/wevm/ox/commit/74e47c5df471a48f4fb389f0684ca52f841fbc11) Thanks [@jxom](https://github.com/jxom)! - Added `Keystore.toKey` and `Keystore.toKeyAsync` to derive a key from a JSON Keystore using a password.

## 0.8.0

### Minor Changes

- [`7fc1da0`](https://github.com/wevm/ox/commit/7fc1da0717a17dbac0e4effed2ea3911c7ca3236) Thanks [@jxom](https://github.com/jxom)! - **Breaking(`Keystore`):** Keystore derivation functions (e.g. `Keystore.pbkdf2`) now return a tuple of the key and derivation options,
  instead of an object with the key and options.

  ```diff
  import { Keystore } from 'ox'

  - const key = Keystore.pbkdf2({ password: 'testpassword' })
  + const [key, opts] = Keystore.pbkdf2({ password: 'testpassword' })
  ```

- [`7fc1da0`](https://github.com/wevm/ox/commit/7fc1da0717a17dbac0e4effed2ea3911c7ca3236) Thanks [@jxom](https://github.com/jxom)! - **Breaking(`Keystore`):** `Keystore.decrypt` function interface no longer requires an object as the second parameter, now it only requires the key itself.

  ```diff
  import { Keystore } from 'ox'

  const [key, opts] = Keystore.pbkdf2({ password: 'testpassword' })

  const encrypted = await Keystore.encrypt(secret, key, opts)

  + const decrypted = await Keystore.decrypt(encrypted, key)
  ```

- [`7fc1da0`](https://github.com/wevm/ox/commit/7fc1da0717a17dbac0e4effed2ea3911c7ca3236) Thanks [@jxom](https://github.com/jxom)! - **Breaking(`Keystore`):** `Keystore.encrypt` function interface has changed to require derivation options (`opts`).

  ```diff
  import { Keystore } from 'ox'

  const [key, opts] = Keystore.pbkdf2({ password: 'testpassword' })

  - const encrypted = await Keystore.encrypt(secret, key)
  + const encrypted = await Keystore.encrypt(secret, key, opts)
  ```

## 0.7.2

### Patch Changes

- [`6090531`](https://github.com/wevm/ox/commit/6090531e29be96d2bd1eda1f85f3e7322b48ff18) Thanks [@jxom](https://github.com/jxom)! - Updated dependencies.

- [`c4c7070`](https://github.com/wevm/ox/commit/c4c7070c7d50fd8d745e5f881305bdf4aa5362d0) Thanks [@jxom](https://github.com/jxom)! - Fixed parsing of zeroish nonces.

## 0.7.1

### Patch Changes

- [#75](https://github.com/wevm/ox/pull/75) [`27a1e28`](https://github.com/wevm/ox/commit/27a1e28e1f403ca18d428611fc3b88dcb5a4503e) Thanks [@jxom](https://github.com/jxom)! - Added `Keystore` module.

## 0.7.0

### Minor Changes

- [`09f72cb`](https://github.com/wevm/ox/commit/09f72cb33f076151e3437cf42b1cad775148a2bb) Thanks [@jxom](https://github.com/jxom)! - Updated EIP-5792 APIs to the latest spec on `RpcSchema`.

### Patch Changes

- [`61a9c57`](https://github.com/wevm/ox/commit/61a9c5798b8072b9c16691463742835b15c17468) Thanks [@jxom](https://github.com/jxom)! - Added EIP-5792 provider errors.

## 0.6.12

### Patch Changes

- [`5247546`](https://github.com/wevm/ox/commit/5247546f0400a3edb3c99f90be7696ab7d3fd7d9) Thanks [@jxom](https://github.com/jxom)! - Fixed `Provider.parseError` case.

## 0.6.11

### Patch Changes

- [`ba67f11`](https://github.com/wevm/ox/commit/ba67f11bb377f132583a3eb04ae761bd36a08387) Thanks [@jxom](https://github.com/jxom)! - Enhanced handling of arbitrary Provider errors.

## 0.6.10

### Patch Changes

- [#65](https://github.com/wevm/ox/pull/65) [`33712a5`](https://github.com/wevm/ox/commit/33712a5680e4b2ad6be0513e70049160628287a0) Thanks [@thomas779](https://github.com/thomas779)! - Added support for multiple `credentialId`s in `WebAuthnP256`.

- [`10e6449`](https://github.com/wevm/ox/commit/10e6449e0e5f060c5ea3db026f4fb98978f78cca) Thanks [@jxom](https://github.com/jxom)! - Added case to fall back to `cause.details` for `BaseError` details.

## 0.6.9

### Patch Changes

- [`6480607`](https://github.com/wevm/ox/commit/6480607767387a64f720e0fa3abbc26ea9409990) Thanks [@jxom](https://github.com/jxom)! - Fixed `AbiEvent.encode` for zeroish arguments.

## 0.6.8

### Patch Changes

- [#60](https://github.com/wevm/ox/pull/60) [`7ff54a2`](https://github.com/wevm/ox/commit/7ff54a2d0a77e2af5a2cc0e1095f0f8d952510c8) Thanks [@jxom](https://github.com/jxom)! - Added `BinaryStateTree` (EIP-7864) module.

## 0.6.7

### Patch Changes

- [`076c6a2`](https://github.com/wevm/ox/commit/076c6a260bfd42d6e66a7490bfb36425f91099d7) Thanks [@jxom](https://github.com/jxom)! - Removed redundant pure annotation.

## 0.6.6

### Patch Changes

- [`980f0e2`](https://github.com/wevm/ox/commit/980f0e269cca1ef3c564aba75055fef867ca3e6f) Thanks [@jxom](https://github.com/jxom)! - Fixed TSDoc.

## 0.6.5

### Patch Changes

- [`0b5182f`](https://github.com/wevm/ox/commit/0b5182f94821715c227dc8b0c891d4548b30fa0e) Thanks [@jxom](https://github.com/jxom)! - Fixed build process for typedef generation.

## 0.6.4

### Patch Changes

- [`74ceae4`](https://github.com/wevm/ox/commit/74ceae4089663ebae18690a44fd98accc28b9b5c) Thanks [@jxom](https://github.com/jxom)! - Fixed `Provider.parseError` behavior.

## 0.6.3

### Patch Changes

- [`ddaed51`](https://github.com/wevm/ox/commit/ddaed51550308eceda3c9a080503cf1fdfac6ac0) Thanks [@jxom](https://github.com/jxom)! - Fixed parsing of Provider RPC errors.

## 0.6.2

### Patch Changes

- [`e541cec`](https://github.com/wevm/ox/commit/e541ceca3c00f0d0b2fbd239696476934dc13ea3) Thanks [@jxom](https://github.com/jxom)! - Modified fallback RPC Errors to `RpcResponse.InternalError`.

## 0.6.1

### Patch Changes

- [`5d007ae`](https://github.com/wevm/ox/commit/5d007aebab4a7fe6acc8eb3cfecbce59fe79a00b) Thanks [@jxom](https://github.com/jxom)! - Added `RpcResponse.parseErrorObject` and `Provider.parseErrorObject`.

## 0.6.0

### Minor Changes

- [`94ec558`](https://github.com/wevm/ox/commit/94ec558c3f56d3254080be520a0d257e8b5d42c2) Thanks [@jxom](https://github.com/jxom)! - Added `BlockOverrides` & `StateOverrides` modules.

- [`94ec558`](https://github.com/wevm/ox/commit/94ec558c3f56d3254080be520a0d257e8b5d42c2) Thanks [@jxom](https://github.com/jxom)! - Added `eth_simulateV1` to `eth_` RPC schema.

## 0.5.0

### Minor Changes

- [`1406e22`](https://github.com/wevm/ox/commit/1406e224d0527732885fdb7737ed2f0dc41929ef) Thanks [@jxom](https://github.com/jxom)! - Added ERC-4337 utilities.

## 0.4.4

### Patch Changes

- [#45](https://github.com/wevm/ox/pull/45) [`48b896f`](https://github.com/wevm/ox/commit/48b896f3c491bcf9e0d8460857b278ede74eaf9e) Thanks [@deodad](https://github.com/deodad)! - Ensured addresses are checksummed when creating SIWE messages

## 0.4.3

### Patch Changes

- [`c09d165`](https://github.com/wevm/ox/commit/c09d1655a1fa65be33d0dfb86d14cfe0dad7bdc3) Thanks [@jxom](https://github.com/jxom)! - Added `checksumAddress` as an option to `AbiParameters.{encode|decode}`.

## 0.4.2

### Patch Changes

- [#40](https://github.com/wevm/ox/pull/40) [`47e306d`](https://github.com/wevm/ox/commit/47e306d8ab95140eb7e2589c05351d1663a507ae) Thanks [@jxom](https://github.com/jxom)! - **ox/erc6492:** Added universal signature verification exports.

## 0.4.1

### Patch Changes

- [#37](https://github.com/wevm/ox/pull/37) [`39604df`](https://github.com/wevm/ox/commit/39604df9f84b810322e12f767ef450c0c2ced308) Thanks [@jxom](https://github.com/jxom)! - Added `ox/erc6492` entrypoint.

## 0.4.0

### Minor Changes

- [#35](https://github.com/wevm/ox/pull/35) [`4680b06`](https://github.com/wevm/ox/commit/4680b06d4715b1b62d903f45490d325506a1e959) Thanks [@gregfromstl](https://github.com/gregfromstl)! - Updated `Signature.toHex` to serialize the last byte as `v` instead of `yParity` for widened compatibility.

### Patch Changes

- [`15f9863`](https://github.com/wevm/ox/commit/15f98630c46ec0c09998162a92a5e8bac709e32d) Thanks [@jxom](https://github.com/jxom)! - Added assertion for ABI-encoding integer ranges.

- [`2e0d4af`](https://github.com/wevm/ox/commit/2e0d4af5c6e26c09a9b83971be0fc06415ee4976) Thanks [@jxom](https://github.com/jxom)! - Added support for block identifiers.

## 0.3.1

### Patch Changes

- [`e4104cd`](https://github.com/wevm/ox/commit/e4104cdb217de1fa30480b40060eb0fb0f7ad8d5) Thanks [@jxom](https://github.com/jxom)! - Added `extraEntropy` option to `Secp256k1.sign` & `P256.sign`.

## 0.3.0

### Minor Changes

- [`9ad0d2c`](https://github.com/wevm/ox/commit/9ad0d2c9777b5c6a8c1cd64ad8742f9c05706606) Thanks [@jxom](https://github.com/jxom)! - Added extra entropy to signature generation.

## 0.2.2

### Patch Changes

- [`4f40358`](https://github.com/wevm/ox/commit/4f4035826313dce974b7c7fa64ba4ea20d1f7f61) Thanks [@jxom](https://github.com/jxom)! - Tweaked `RpcResponse` and `Provider` errors to have optional parameters.

## 0.2.1

### Patch Changes

- [`6e4b635`](https://github.com/wevm/ox/commit/6e4b635ee720312be6631dee4f24fdd3c066f2eb) Thanks [@jxom](https://github.com/jxom)! - Derive EIP-712 Domain type if not provided in `TypedData.serialize`.

## 0.2.0

### Minor Changes

- [`2f0fc9b`](https://github.com/wevm/ox/commit/2f0fc9b66ff70bf03a3ecf146ed1a62433f53eb8) Thanks [@jxom](https://github.com/jxom)! - **Breaking:** Removed `.parseError` property on functions. Use the `.ErrorType` property instead. [Example](https://oxlib.sh/error-handling#usage-with-neverthrow)

### Patch Changes

- [`af01579`](https://github.com/wevm/ox/commit/af01579951b898ebd659cd6b64aaa56f7733c191) Thanks [@jxom](https://github.com/jxom)! - Assert that EIP-712 domains are valid.

## 0.1.8

### Patch Changes

- [#25](https://github.com/wevm/ox/pull/25) [`5da9efb`](https://github.com/wevm/ox/commit/5da9efbfebfa738ee0f78927e90b3fab61cbb2e8) Thanks [@tmm](https://github.com/tmm)! - Shimmed `WebAuthnP256.createCredential` for 1Password Firefox Add-on.

## 0.1.7

### Patch Changes

- [`33b5123`](https://github.com/wevm/ox/commit/33b51236908f17cb8644a47e222995e1800853db) Thanks [@tmm](https://github.com/tmm)! - Updated Provider errors.

## 0.1.6

### Patch Changes

- [`4405c4b`](https://github.com/wevm/ox/commit/4405c4bd2bff3f9f222a90de7323cce77c94b5f3) Thanks [@jxom](https://github.com/jxom)! - Amended `accountsChanged` parameter to be `readonly`.

- [#22](https://github.com/wevm/ox/pull/22) [`23f2d61`](https://github.com/wevm/ox/commit/23f2d61f817c5d33f0053cb154447f0b26244cc1) Thanks [@tmm](https://github.com/tmm)! - Added EIP 1193 errors.

## 0.1.5

### Patch Changes

- [`644b96a`](https://github.com/wevm/ox/commit/644b96a169a118c6f0606eda5354785523ed099b) Thanks [@jxom](https://github.com/jxom)! - Added additional guard for `result` in `Provider.from`.

## 0.1.4

### Patch Changes

- [`777fe42`](https://github.com/wevm/ox/commit/777fe4249c5225c676ff690fda58c5fcfb35d1f0) Thanks [@jxom](https://github.com/jxom)! - Tweaked `trimLeft` to remove all leading zeros.

## 0.1.3

### Patch Changes

- [`868d431`](https://github.com/wevm/ox/commit/868d4319a8cda77345f85f9f2e88ca786f0c8cfe) Thanks [@jxom](https://github.com/jxom)! - Added handling for odd-length hex values.

## 0.1.2

### Patch Changes

- [#17](https://github.com/wevm/ox/pull/17) [`f438faf`](https://github.com/wevm/ox/commit/f438fafbd396248283876eba220f4c661c47bfd2) Thanks [@jxom](https://github.com/jxom)! - Moved modules to `core/`.

## 0.1.1

### Patch Changes

- [`b7de4f2`](https://github.com/wevm/ox/commit/b7de4f2180520fd7f2bf08955df6e676d75db93e) Thanks [@jxom](https://github.com/jxom)! - Fixed `RpcSchema` inference on `params`.

## 0.1.0

### Minor Changes

- [`4297bcf`](https://github.com/wevm/ox/commit/4297bcf0acef7f1f208ba3770d679fefa0c2cb8d) Thanks [@jxom](https://github.com/jxom)! - Initial release.
