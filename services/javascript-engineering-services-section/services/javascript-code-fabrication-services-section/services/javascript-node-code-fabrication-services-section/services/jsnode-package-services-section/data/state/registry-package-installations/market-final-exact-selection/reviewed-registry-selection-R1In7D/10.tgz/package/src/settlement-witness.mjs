import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

import { each, put } from "@red-cup-engineering/semiotic-eavt-services-section/store";

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const ACTOR = "urn:ame:blockchain-trashpanda";

/** The store type trashpanda's settlement witnesses are kept under. */
export const SETTLEMENT_WITNESS_TYPE = "trashpanda-settlement";

/**
 * Witness one admitted trashpanda record: a record of the store naming the actor, the record's ni,
 * its type and its disposition, under the admission's own category.
 */
export function recordSettlementRecord({ actor, category, recordedAt, record, dataRoot = ROOT }) {
  if (actor !== ACTOR || typeof category !== "string" || !Number.isFinite(Date.parse(recordedAt)) || record === null || typeof record !== "object") throw new TypeError("blockchain-trashpanda settlement witness is malformed");
  if (typeof record.id !== "string" || !/^ni:\/\/\/sha-256;[A-Za-z0-9_-]{43}$/u.test(record.id)) throw new TypeError("record must be one semantic-content ni token");
  const disposition = typeof record.disposition === "string" ? record.disposition : "admitted";
  const id = put(dataRoot, SETTLEMENT_WITNESS_TYPE, { type: "BlockchainTrashpandaSettlementWitness", version: 1, actor, category, at: recordedAt, record: record.id, recordType: String(record.type), disposition });
  return Object.freeze({ id, documentNi: record.id, record: record.id });
}

/** Every settlement witness held under `category`, in the order they were recorded. */
export function settlementWitnesses(category, { dataRoot = ROOT } = {}) {
  return [...each(dataRoot, SETTLEMENT_WITNESS_TYPE)]
    .filter(({ record }) => record.category === category)
    .sort((left, right) => String(left.record.at).localeCompare(String(right.record.at)) || left.address.localeCompare(right.address))
    .map(({ record: { at: _at, ...witness } }) => witness);
}
