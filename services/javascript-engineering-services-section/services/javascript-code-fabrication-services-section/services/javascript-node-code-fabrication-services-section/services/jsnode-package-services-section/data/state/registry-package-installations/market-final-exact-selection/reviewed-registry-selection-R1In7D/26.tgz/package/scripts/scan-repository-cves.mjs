#!/usr/bin/env node
import { readFile } from "node:fs/promises";
import { scanRepositoryCves } from "../src/scan-repository-cves.mjs";

// Safe by default: reads an existing lockfile, queries OSV and writes JSON.
// No npm install, lifecycle script, checkout, token or mutation.
const args = process.argv.slice(2);
if (args.length !== 1 || args[0].startsWith("-")) {
  process.stderr.write("Usage: scan-repository-cves <package-lock.json>\n");
  process.exitCode = 2;
} else {
  try {
    const bytes = await readFile(args[0], "utf8");
    if (bytes.length > 4_000_000) throw new RangeError("lockfile exceeds 4 MB");
    const report = await scanRepositoryCves({ packageLock: JSON.parse(bytes) });
    process.stdout.write(JSON.stringify(report, null, 2) + "\n");
    if (!report.coverage.complete) process.exitCode = 3;
  } catch (error) {
    process.stderr.write("scan-repository-cves: " + (error instanceof Error ? error.message : String(error)) + "\n");
    process.exitCode = 1;
  }
}
