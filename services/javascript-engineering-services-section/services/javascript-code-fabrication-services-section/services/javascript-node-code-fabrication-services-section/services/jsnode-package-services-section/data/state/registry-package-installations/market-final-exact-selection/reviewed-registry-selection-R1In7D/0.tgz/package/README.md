# Koios intelligence briefing

## Thread

Five-custody thread (org-layering.md, 2026-09-01):
- science: [Agent-Readable Claim Infrastructure](../../../../../../../../../science-services-section/services/social-science-services-section/services/sociology-science-services-section/services/work-science-services-section/content/text/documents/articles/notes/2026/06/19/2026-06-19-claim-infrastructure-business.md) (news-media-science-services-section) — studies the exact economic object this product sells: a structured, agent-readable claim/provenance archive monetized as premium feeds and briefings, not articles
- engineering: [News Media Engineering Services Section](../../../../../../../../../../../../../engineering-services-section/services/computer-engineering-services-section/services/computer-data-engineering-services-section/services/computer-content-engineering-services-section/services/computer-news-content-engineering-services-section/README.md) — owns the claim-state infrastructure, per-claim conformance, and warrant-preserving pipeline engineering the koios claim store this package reads is built on
- operations: [ScheduleDelivery Service](../../../../../../../../../../../../../operations-services-section/services/agent-services-section/services/scheduled-activity-delivery-service/README.md) — the Cold Red Gate scheduler that actually runs koios-news's routine publication cadence feeding the store this briefing measures
- 561-group: [Koios.News restart plan](../../../../../../../../../561-group-services-section/content/text/documents/articles/notes/2026/08/16/2026-08-16-koios-news-restart-plan.md) — the board's actual restart/monetization plan for koios-news, the governing decision this briefing product arms
- public: self (this section) — the named-subscriber premium face over the free koios.news site

theory-base: [Agent-Readable Claim Infrastructure](../../../../../../../../../science-services-section/services/social-science-services-section/services/sociology-science-services-section/services/work-science-services-section/content/text/documents/articles/notes/2026/06/19/2026-06-19-claim-infrastructure-business.md) — its monetization-path survey (premium feeds, validators, conformance products) is this package's theory base for pricing a $50/month briefing over the same claim store.

This package is the counterpoint enterprise beside koios.news's general news
mission: a named-subscriber intelligence briefing (target ~20 subscribers at
~$50/month) built on the same machine backend as the free site — the
`sites/koios.news/store/<category>/<slug>.json` sourced-claim store, where
every asserted fact carries a `provenance.witness` and `provenance.citation`.
koios.news remains a general news site; this package adds a premium product
line beside it, never in place of it.

It does not replace, deploy, or schedule anything the parent settlement
already owns. It reads the store read-only and writes only its own
`data/records/`.

## What it measures

`src/topic-distribution.mjs` exports `computeClaimTopicDistribution`, a pure
function that walks every category directory in the store, and returns:

- per-category file and claim counts;
- a secondary breakdown by each claim's `force` and `status`;
- a recency histogram bucketed by each claim's `time.asserted` month.

Run it against the real store:

```sh
node scripts/measure-claim-topic-distribution.mjs
```

Measured on 2026-08-31 against the real 1,195-file store (4,770 claims):
`collapse-tech` is the corpus's strongest single category, both by file count
(144 of 1,195) and by claim count (576 of 4,770) — ahead of `collapse-politics`
(141 files), `collapse-finance` (119), `culture` (112), `politics` (111), and
`economy` (102). Every observed claim in the corpus carries `force: "alleges"`
and `status: "supported"`; that uniformity is itself a real, measured finding,
not an assumption. The corpus spans two months, `2026-06` (2,360 claims) and
`2026-07` (2,410 claims).

`collapse-tech`'s stories cluster on tech-infrastructure fragility, digital
sovereignty, and cybersecurity-geopolitics (cloud-sovereignty retreats,
critical-infrastructure cyberattacks, AI-tooling sovereignty disputes,
defense-tech supply chains) — a coherent, well-evidenced beat for a premium
briefing, not a forced label.

## Recording the launch state

`scripts/record-intelligence-briefing-launch-state.mjs` recomputes the
distribution, attaches the pricing rationale and funnel plan below, and
records one dated snapshot through
`@red-cup-engineering/semantic-record-journal-service` into this package's own
`data/records/journal/` (the service's own fixed `data/logs/YYYY/MM/DD/`
custody shape, nested beneath `data/records/` per house convention — this
package never hand-rolls a journal writer):

```sh
node scripts/record-intelligence-briefing-launch-state.mjs
```

## Pricing

Target: **$50/month, ~20 subscribers.** Comparables found by WebSearch
(August 2026), each cited in the recorded launch-state snapshot:

| Comparable | Price/month | Note |
| --- | ---: | --- |
| Stratechery Plus | $15 | 40,000+ paid subscribers |
| The Information | $42.25 | Pro tier $749/yr (~$62/mo) |
| Platformer | $10 | ~170K subscribers, 5% paid |
| Zero Day (Kim Zetter) | $10 | $25/mo "Special Friends and Sponsors" tier |
| The Maley Report | $49 | professional analyst briefing |
| FT Standard Digital | $45 | FT Premium Digital (incl. analyst briefings) is $75/mo |
| beehiiv 2026 market data | n/a | $10/mo is the generic anchor; niche verticals (investing $27, finance $20, business $15) command more; subscriber count near-20 vs. near-20,000 does not meaningfully move price — niche and differentiation do |

**Rationale (one paragraph):** $50/month sits well above the $10/month
generic-newsletter anchor beehiiv's 2026 market data describes, and inside the
$42-75/month band that professional analyst briefings actually charge (The
Information, The Maley Report, FT Premium Digital) — the tier this product
belongs in because it is not a curated-links digest but a machine-backed
briefing where every claim traces to a witness and citation in the koios
store, the source discipline a free feed does not surface and that a subscriber
paying for named analysis, not volume, is buying.

## Funnel

Measured niche (from the real distribution above): **collapse-tech**
(tech-infrastructure fragility / digital-sovereignty / cybersecurity-geopolitics).
Where that audience actually congregates, per WebSearch (August 2026):

- r/netsec, r/cybersecurity, r/blueteamsec (Reddit) — the practitioner
  communities cybersecurity professionals report actually using day to day.
- TechPolicy.Press — an existing publication covering the identical
  digital-sovereignty/AI-governance beat; its readership is this product's
  target readership.
- IAPP Navigate / Global Summit digital-sovereignty tracks — where this
  audience gathers in person.
- CSO Online, Security Boulevard — trade press this audience already reads.

**First concrete move:** post sample issue 01 as a free, value-first post
in r/netsec or r/cybersecurity. That is the source-disciplined analysis
itself, with a subscribe link at the end.

## Selling it

1. **Open subscriptions.** Buttondown takes paid subscriptions through its
   Stripe connection. Hold the `koios-briefing` newsletter's key, price the list at
   $50/month, and the delivery script sends each issue.
2. **Publish on a cadence.** Compose a weekly issue from the claim store
   with `scripts/compose-briefing-issue.mjs`. Sample issue 01 clears the
   sourcing and coherence bars, and each later issue sharpens the editing
   from readers' replies.
3. **Sell directly too.** A caller or email reaches security and
   privacy leads at the organizations on the audience list above. Offer a
   free month, then $50/month, and a team price for five seats or more.

## Composing and delivering an issue

`scripts/compose-briefing-issue.mjs` closes this product's delivery
mechanism. It reads the koios claim store through this package's own
store readers (`src/topic-distribution.mjs`'s `listStoreCategories`/
`listCategoryFiles`/`readClaimFile`, wired into `src/briefing-issue.mjs`'s
`listStoreStories`), selects a dated window of stories (default: the
seven days ending on the most recent `time.asserted` claim in the store —
anchored on the store's own data, not wall-clock now(), because the store
is a dated snapshot, not a live feed), and composes the window into a
briefing issue through
`@red-cup-engineering/email-newsletter-engineering-services-section`,
writing `issue.md`, `issue.paste.html`, and `issue.feed-item.rss.xml` to
`content/text/documents/issues/<since>-to-<until>/`:

```sh
node scripts/compose-briefing-issue.mjs --category collapse-tech
# flags: --store --out-dir --since --until --window-days --max-stories
#        --category --title --dek --link --format
```

A handful of real claim files carry a `summary` claim whose object is an
empty string (present, not missing) — real store data-quality variance,
not a bug. `listStoreStories` skips those files (returned in the
result's `skipped` array) rather than aborting the whole walk; a file
that is not valid claim JSON at all still throws.

`scripts/deliver-briefing-draft.mjs` hands one composed issue's rendered
Markdown to `@red-cup-engineering/buttondown-services-section`'s
`createDraftEmail` — **draft only, never send**, per the fence above:

```sh
node scripts/deliver-briefing-draft.mjs \
  content/text/documents/issues/<since>-to-<until>/issue.md "Issue subject line"
```

Delivery turns on when the `koios-briefing` Buttondown newsletter exists and
its key is held at `~/.config/561-group/buttondown/koios-briefing.api-key`
(buttondown-services-section's newsletter keys). The script never accepts a
key as an argument and exits before touching the filesystem or network when
none is held; `test/deliver-briefing-draft.test.mjs` proves that refusal.

## Machinery reused vs. new

Reused: the koios-news settlement's real claim store (read-only), the
`services/editorial-admission-receipt` package shape (package.json/src/cli/test
layout), `@red-cup-engineering/semantic-record-journal-service` (pinned to
the actual latest registry version, 0.1.9, verified with `npm view` this
session — not the stale 0.1.6 the root package still pins),
`@red-cup-engineering/email-newsletter-engineering-services-section` (0.1.0)
for issue validation/rendering, and
`@red-cup-engineering/buttondown-services-section` (0.2.0) for the
create-draft flow and the newsletter's key.

New: this package itself — the topic-distribution algebra, the
briefing-issue windowing/composition algebra (`src/briefing-issue.mjs`),
the operational scripts (measure, record-launch-state,
compose-briefing-issue, deliver-briefing-draft), the test suite, this
README, and the one sample-issue Markdown carrier at
`content/text/documents/sample-issues/`.

## First-dollar path (HANDS vs. ENGINEERING)

ENGINEERING (delivered by this work): the package, the measurer, the
launch-state record, the sample issue, this pricing/funnel writeup, and
the delivery mechanism — `compose-briefing-issue.mjs` (claim store to
rendered issue) and `deliver-briefing-draft.mjs` (rendered issue to a
Buttondown draft, never a send).

HANDS (a human must do this next, outside any repository): create a
Buttondown newsletter `koios-briefing` and its key — the rail this
delivery mechanism is wired to — or open a named monthly-billing account
on another rail (Stripe, Substack, Ghost) if the founder wants a
different masthead/billing combination; not the org's x402/pseudonymous
rails. Twenty *named* monthly subscribers who expect a receipt, a renewal, and
support if a charge fails are a poor fit for x402's agent-to-agent
micropayment design; they need conventional subscription billing with
customer-support and dispute handling, which
Stripe/Substack/Ghost/Buttondown provide and x402 does not.

## Risks, honestly

- The sample issue proves the mechanism (real claims, real citations, a
  coherent beat); it does not prove a sustainable weekly/monthly cadence at
  the editorial quality a paying subscriber expects issue after issue.
- Audience-building precedes revenue: no distribution channel has been used
  yet, only researched. The first move above is a distribution step, not a
  sale.
- Every claim in the corpus is currently `force: "alleges"` /
  `status: "supported"` — the store has not yet recorded a disputed or
  refuted claim. That is an honest limit of the current corpus, not a defect
  of this package; briefings drawing on it should say "reported" rather than
  implying independent verification beyond the cited source.

## Market research as a richer briefing

`createPaidBriefing` accepts optional `research` and `publication` fields.
Research is an explicitly selected, content-addressed public-fact packet from
`mandate-portfolio-allocation-service/research-publication`; every source must
also appear in the briefing references. The normal current-briefing admission
pins prose and data together before payment, so a concurrent current update
cannot change the buyer's admitted dataset. Legacy prose-only briefings remain
readable through the same export and market route.

The Koios news line's release stage publishes this richer artifact only after
its associated edition is released and its underlying source and claim cells
remain held without opposition. It uses the existing
`koios-intelligence-briefings` bucket and current x402 offer. It adds no payment
server, subscription scheduler or separate trader. The actual delivery and
discovery boundary remains the shared market, consistent with the
[x402 v2 specification](https://github.com/x402-foundation/x402/blob/main/specs/x402-specification-v2.md).

From the parent Koios package, the isolated demonstration runs as:

```sh
node examples/market-research.mjs --record /path/to/public-play.jsonl --assignment /path/to/research-assignment.json --directory /tmp/new-research-demonstration
```

It uses actual collected facts but performs no live release, payment or trade.
The parent `koios-market-research` executable accepts `--record`, either
`--packet` or `--assignment`, and an optional `--section` (business-markets by
default). Its configured newsroom receives the claims for the ordinary agent
writer and editorial stages. Deployment still needs the functioning upstream
dispatcher, newsroom authority and existing R2 environment.
