#!/usr/bin/env node
// One effect: read one OrphanPatchHarvestInput JSON object per stdin line,
// score it with the pure src/ algebra, write one OrphanPatchHarvestOutput
// JSON object per stdout line. No network, no fork, no publish.
import { scoreOrphanPatchCandidates } from "../src/orphan-patch-scoring.mjs";
import { runJavascriptNodeOperation } from "@red-cup-engineering/javascript-node-services-section/operation";

function requireArray(value, label) {
  if (!Array.isArray(value)) throw new TypeError(`score-set-of-orphan-patch-candidates: ${label} must be an array`);
  return value;
}

/**
 * Reads an OrphanPatchHarvestInput JSON object, validates its shape, and
 * returns the ranked OrphanPatchHarvestOutput scored by the orphan-patch
 * scoring algebra.
 *
 * @param {object} request An OrphanPatchHarvestInput JSON object.
 * @param {object[]} request.advisories `{id, package, ecosystem, severity, published, fixedVersion}` rows.
 * @param {object[]} request.maintenance `{package, ecosystem, lastReleaseDaysAgo, openIssueResponseDaysMedian}` rows.
 * @param {object[]} request.dependents `{package, ecosystem, dependentCount}` rows.
 * @returns {{candidates: object[]}} An OrphanPatchHarvestOutput JSON object.
 * @throws {TypeError} When request is not a JSON object or any of its three arrays is missing.
 */
export function scoreSetOfOrphanPatchCandidates(request) {
  if (request === null || typeof request !== "object" || Array.isArray(request)) {
    throw new TypeError("score-set-of-orphan-patch-candidates: request must be a JSON object");
  }
  const advisories = requireArray(request.advisories, "advisories");
  const maintenance = requireArray(request.maintenance, "maintenance");
  const dependents = requireArray(request.dependents, "dependents");
  return scoreOrphanPatchCandidates({ advisories, maintenance, dependents });
}

if (import.meta.main) {
  const result = await runJavascriptNodeOperation({ name: "score-set-of-orphan-patch-candidates", description: "Reads an OrphanPatchHarvestInput JSON object, validates its shape, and returns the ranked OrphanPatchHarvestOutput scored by the orphan-patch scoring algebra.", operation: scoreSetOfOrphanPatchCandidates }, { arguments: process.argv.slice(2), standardInput: process.stdin, standardOutput: process.stdout });
  process.exitCode = result.exitCode;
}
