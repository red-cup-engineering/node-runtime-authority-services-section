import type { IncomingMessage } from "node:http";
export type BodyParseOptions = Readonly<{
  maxBytes?: number;
  maxEncodedBytes?: number;
  contentType?: string;
  contentEncoding?: string | readonly string[];
  decodeContentEncoding?: boolean;
}>;
export type JsonBodyOptions = BodyParseOptions & Readonly<{ empty?: unknown }>;
export class BodyReadError extends Error {
  status: number;
  code: string;
  constructor(status: number, code: string, message: string, options?: ErrorOptions);
}
export type MultipartPart = Readonly<{
  name: string;
  filename?: string;
  headers: Readonly<Record<string, string>>;
  contentType?: string;
  data: Buffer;
  text: (encoding?: BufferEncoding) => string;
}>;
export type MultipartForm = Readonly<{
  fields: URLSearchParams;
  files: readonly MultipartPart[];
  parts: readonly MultipartPart[];
  get: (name: string) => string | null;
  getAll: (name: string) => string[];
  file: (name: string) => MultipartPart | undefined;
  filesFor: (name: string) => readonly MultipartPart[];
}>;
export function readBody(req: IncomingMessage, options?: number | BodyParseOptions): Promise<Buffer>;
export function readTextBody(req: IncomingMessage, options?: BodyParseOptions): Promise<string>;
/** Parsing establishes JSON syntax, not an object-envelope or application schema. */
export function readJsonBody(req: IncomingMessage, options?: JsonBodyOptions): Promise<unknown>;
export function readFormBody(req: IncomingMessage, options?: BodyParseOptions): Promise<URLSearchParams>;
export function readMultipartBody(req: IncomingMessage, options?: BodyParseOptions): Promise<MultipartForm>;
