/** @internal */
export const version = '0.14.32';
//# sourceMappingURL=version.js.map