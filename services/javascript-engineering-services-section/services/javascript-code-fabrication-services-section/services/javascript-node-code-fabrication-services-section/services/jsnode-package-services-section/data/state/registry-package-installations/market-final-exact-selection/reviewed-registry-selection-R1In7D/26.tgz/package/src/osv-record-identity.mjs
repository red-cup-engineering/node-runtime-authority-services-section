/**
 * The published OSV schema (1.9.2) admits ASCII letters, digits, colon,
 * underscore, period and hyphen in a source record's permanent identifier.
 * A source-provided identifier is an opaque pointer, never a filename, path,
 * or a promise that this project has CVE Numbering Authority status.
 * The finite length is this service's bounded-input policy, not an OSV law.
 */
const OSV_ID_CHARACTERS = /^[A-Za-z0-9:_.-]+$/u;

export function isOsvRecordId(value) {
  return typeof value === "string" &&
    value.length > 0 && value.length <= 512 &&
    OSV_ID_CHARACTERS.test(value);
}
