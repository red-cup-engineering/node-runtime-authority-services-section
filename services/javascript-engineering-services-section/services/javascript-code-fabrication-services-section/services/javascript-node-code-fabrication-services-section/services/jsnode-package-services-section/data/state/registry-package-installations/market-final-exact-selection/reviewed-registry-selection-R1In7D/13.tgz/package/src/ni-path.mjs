/**
 * Where an NI-addressed record lives: its location computed from its address, never looked up.
 *
 * An RFC 6920 SHA-256 NI address `ni:///sha-256;<d>` (d: 43 characters of unpadded base64url) is
 * read as a filesystem proof path: the algorithm is the first segment and leading spans of the
 * digest are the segments under it.
 *
 *   niPathSegments(ni, widths) = [algorithm, d[0, w0), d[w0, w0 + w1), ...]
 *
 * With the default `widths = [2]` a record's bucket is `sha-256/<d0 d1>.jsonl`: one of 64^2 = 4096
 * files, each holding the lines of the records whose digests share those two characters. A reader
 * that holds an address computes its bucket and opens only that file; no index from address to
 * location is kept, in memory or on disk. Base64url is case-sensitive, so the formula assumes a
 * case-sensitive filesystem (every machine of the house).
 *
 * The digest is uniformly distributed, so buckets fill evenly: a store of N records holds about
 * N / 64^k lines per bucket with k characters of fan-out. A store whose buckets grow past what one
 * read should cost moves to a wider formula version; a version names its widths and never changes.
 */
import { isNiUri, makeNiUri } from "@red-cup-engineering/uri-services-section/ni-uri";

const PREFIX = "ni:///sha-256;";
const ALPHABET = /^[A-Za-z0-9_-]+$/u;

/** The formula versions: each names its digest spans for good. */
export const NI_PATH_FORMULAS = Object.freeze({
  "ni-path-v1": Object.freeze({ widths: Object.freeze([2]), suffix: ".jsonl" }),
});

function widthsOf(widths) {
  if (!Array.isArray(widths) || widths.length === 0) throw new TypeError("ni path widths must be a nonempty array");
  let total = 0;
  for (const width of widths) {
    if (!Number.isSafeInteger(width) || width < 1) throw new TypeError("ni path widths must be positive integers");
    total += width;
  }
  if (total > 43) throw new TypeError("ni path widths exceed the digest");
  return widths;
}

/** The path segments an NI address names: its algorithm, then the digest spans `widths` cut. */
export function niPathSegments(ni, widths = NI_PATH_FORMULAS["ni-path-v1"].widths) {
  if (!isNiUri(ni)) throw new TypeError(`not a canonical sha-256 NI address: ${String(ni)}`);
  const digest = ni.slice(PREFIX.length);
  if (!ALPHABET.test(digest)) throw new TypeError("NI digest is not base64url");
  const segments = ["sha-256"];
  let at = 0;
  for (const width of widthsOf(widths)) { segments.push(digest.slice(at, at + width)); at += width; }
  return Object.freeze(segments);
}

/** The relative bucket file of an NI address under formula `version` (POSIX separators). */
export function niBucketPath(ni, version = "ni-path-v1") {
  const formula = NI_PATH_FORMULAS[version];
  if (formula === undefined) throw new TypeError(`unknown ni path formula: ${String(version)}`);
  return `${niPathSegments(ni, formula.widths).join("/")}${formula.suffix}`;
}

/**
 * The NI address a non-NI key is located by: the SHA-256 NI of its UTF-8 bytes. A store keyed by
 * names that are not content addresses still computes their location by the same formula.
 */
export function niOfKey(key) {
  if (typeof key !== "string" || key.length === 0) throw new TypeError("a located key must be nonempty text");
  return key.startsWith(PREFIX) && isNiUri(key) ? key : makeNiUri(Buffer.from(key, "utf8"));
}

/** The bucket of any key: an NI address's own, otherwise that of the NI of its bytes. */
export function keyBucketPath(key, version = "ni-path-v1") {
  return niBucketPath(niOfKey(key), version);
}
