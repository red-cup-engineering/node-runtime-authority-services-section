#!/usr/bin/env node
// Deliver a real public vulnerability-advisory aggregation, not a claim to
// issue CVE identifiers, to one opt-in public GitHub issue.
import { readFile, writeFile } from "node:fs/promises";
import { assemblePublicAdvisories } from "../src/assemble-public-advisories.mjs";

const event = JSON.parse(await readFile(process.env.GITHUB_EVENT_PATH, "utf8"));
const issue = event.issue, ownRepository = process.env.GITHUB_REPOSITORY, token = process.env.GH_TOKEN;
if (!issue || !Number.isInteger(issue.number) || !String(issue.title ?? "").startsWith("[CVE dossier]") ||
    !/^[\w.-]+\/[\w.-]+$/u.test(ownRepository ?? "") || !token) {
  throw new Error("only the opted-in public advisory dossier issue is accepted");
}
const body = String(issue.body ?? "").replace(/\r\n/gu, "\n");
const prefix = "### Public advisory IDs\n";
const start = body.indexOf(prefix);
const rest = start < 0 ? "" : body.slice(start + prefix.length);
const end = rest.indexOf("\n### ");
const raw = (end < 0 ? rest : rest.slice(0, end)).trim();
const ids = raw.split("\n").map(x => x.trim()).filter(x => x && x !== "_No response_");
function plain(value) {
  return String(value ?? "").replace(/[\r\n<>|]/gu, " ").slice(0, 200);
}
async function comment(message) {
  const response = await fetch("https://api.github.com/repos/" + ownRepository + "/issues/" + issue.number + "/comments", {
    method: "POST",
    headers: { authorization: "Bearer " + token, accept: "application/vnd.github+json",
      "content-type": "application/json", "x-github-api-version": "2022-11-28" },
    body: JSON.stringify({ body: message }), signal: AbortSignal.timeout(15000)
  });
  if (!response.ok) throw new Error("GitHub could not deliver the advisory dossier: HTTP " + response.status);
}
function format(dossier) {
  const lines = ["## Your assembled public CVE/GHSA dossier", "",
    "**Public source:** OSV advisory revisions",
    "**Records:** " + dossier.advisories.length,
    "**Source observation:** " + plain(dossier.observedAt),
    ""];
  for (const row of dossier.advisories) {
    lines.push("### [" + plain(row.id) + "](" + row.source + ")");
    lines.push("**Title:** " + plain(row.title ?? "Untitled public record"));
    lines.push("**Modified:** " + plain(row.modified) + (row.withdrawn ? " · **Withdrawn:** " + plain(row.withdrawn) : ""));
    lines.push("**CVE identifiers:** " + (row.cves.length ? row.cves.map(plain).join(", ") : "None asserted in this source record"));
    lines.push("**Aliases:** " + (row.aliases.length ? row.aliases.map(plain).join(", ") : "None"));
    const impacted = row.affected.slice(0, 8).map(a => plain(a.ecosystem) + "/" + plain(a.package));
    lines.push("**Affected product records:** " + (impacted.length ? impacted.join(", ") : "None in source record"));
    lines.push("");
  }
  const run = "https://github.com/" + ownRepository + "/actions/runs/" + process.env.GITHUB_RUN_ID;
  lines.push("**Complete source-record revisions, affected version ranges and reference URLs:** download the JSON artifact from [this GitHub Actions run](" + run + ").");
  lines.push("", "This assembles existing publicly released advisories; it does **not** assign a CVE identifier, establish reachability, certify a product, or authorize disclosure of unpublished findings.");
  lines.push("", "For a coordinated disclosure, repeated impact watch, or professional remediation, [request a 561 Group service scope](https://561.group/work/).");
  return lines.join("\n").slice(0, 14000);
}
try {
  const dossier = await assemblePublicAdvisories({ ids });
  await writeFile("cve-report.json", JSON.stringify(dossier, null, 2) + "\n", { flag: "wx" });
  await comment(format(dossier));
  console.log("Delivered real public advisory dossier to issue #" + issue.number + ": " + dossier.advisories.length + " records");
} catch (error) {
  await comment("## Public advisory assembly could not complete\n\n" +
    plain(error instanceof Error ? error.message : error) +
    "\n\nNo official CVE issuance, private disclosure or authoritative vulnerability clearance has occurred. Please correct the public record identifiers.");
  throw error;
}
