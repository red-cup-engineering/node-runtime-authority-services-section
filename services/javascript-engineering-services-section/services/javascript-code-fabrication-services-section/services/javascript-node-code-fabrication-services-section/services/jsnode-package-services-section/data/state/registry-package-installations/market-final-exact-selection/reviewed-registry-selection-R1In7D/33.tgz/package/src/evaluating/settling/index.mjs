/**
 * @packageDocumentation
 *
 * `@red-cup-engineering/relating/evaluating/settling` exports the free settling construction
 * as SEN terms.
 *
 * `freeTerm` materializes the full settled object from filtration generators:
 * a single initial stage at countable cofinality. `cellSetOf` and `zeroStageOrdinalTerm`
 * are exported for the reading sub-module, which composes them into the reader terms.
 *
 * Product reading: settlement generators can be materialized inside the term
 * calculus before reader terms inspect them. This keeps finite settlement reads
 * portable without claiming this module is a general transfinite closure engine.
 */
import {          tm } from "@red-cup-engineering/computer-data-engineering-services-section/semiotic-expression-notation";
import { objectTerm, arrayTerm, stringTerm } from "@red-cup-engineering/computer-data-engineering-services-section/semiotic-expression-notation/json-codec";

// ── generic list combinators ──────────────────────────────────────────────────

const boolFalse     = tm.bool(false);
const boolTrue     = tm.bool(true);

/** `member x list` — whether any element of an array term coincides with `x`. */
const memberTerm     = tm.lam(tm.lam(
  tm.fold(
    tm.lam(tm.lam(
      tm.cond(tm.var(1), boolTrue, tm.coincide(tm.var(3), tm.var(0))),
    )),
    boolFalse,
    tm.var(0),
  ),
));

/** `dedup list` — array term with coincidence-duplicates removed, order preserved. */
export const dedupTerm     = tm.lam(
  tm.fold(
    tm.lam(tm.lam(
      tm.cond(
        tm.app(tm.app(memberTerm, tm.var(0)), tm.var(1)),
        tm.var(1),
        tm.append(tm.var(1), arrayTerm([tm.var(0)])),
      ),
    )),
    arrayTerm([]),
    tm.var(0),
  ),
);

/** `subjectsAndObjects cells` — flat list of every cell's subject then object. */
const subjectObjectListTerm     = tm.lam(
  tm.fold(
    tm.lam(tm.lam(
      tm.append(tm.var(1), arrayTerm([tm.field("subject", tm.var(0)), tm.field("object", tm.var(0))])),
    )),
    arrayTerm([]),
    tm.var(0),
  ),
);

/** `predicates cells` — list of every cell's predicate. */
const predicateListTerm     = tm.lam(
  tm.fold(
    tm.lam(tm.lam(
      tm.append(tm.var(1), arrayTerm([tm.field("predicate", tm.var(0))])),
    )),
    arrayTerm([]),
    tm.var(0),
  ),
);

// ── exported settlement primitives ────────────────────────────────────────────

/** The zero settling-stage ordinal carrier. */
export const zeroStageOrdinalTerm     = objectTerm([
  ["kind", stringTerm("predication.settling.stageOrdinal")],
  ["ordinal", objectTerm([["kind", stringTerm("ordinal.closure.ordinal.zero")]])],
]);

/** `cellSet cells` — the designated cell set: deduped cells with derived entity/predicate sets. */
export function cellSetOf(cells    )     {
  return objectTerm([
    ["kind", stringTerm("predication.cellSet")],
    ["cells", tm.app(dedupTerm, cells)],
    ["entities", objectTerm([
      ["kind", stringTerm("predication.entitySet")],
      ["entities", tm.app(dedupTerm, tm.app(subjectObjectListTerm, cells))],
    ])],
    ["predicates", objectTerm([
      ["kind", stringTerm("predication.predicateSet")],
      ["predicates", tm.app(dedupTerm, tm.app(predicateListTerm, cells))],
    ])],
  ]);
}

// ── the free settling construction ───────────────────────────────────────────

/** The filtration generators (var 0) → the single initial stage at countable cofinality. */
export const freeTerm     = (() => {
  const cells = tm.field("cells", tm.var(0));
  const stage = objectTerm([
    ["kind", stringTerm("predication.settling.stage")],
    ["ordinal", zeroStageOrdinalTerm],
    ["shape", objectTerm([
      ["kind", stringTerm("predication.settling.stage.initial")],
      ["ordinal", zeroStageOrdinalTerm],
    ])],
    ["designated", cellSetOf(cells)],
  ]);
  return tm.lam(objectTerm([
    ["kind", stringTerm("predication.settlement.filtration")],
    ["stages", arrayTerm([stage])],
    ["cofinality", objectTerm([["kind", stringTerm("predication.settling.cofinality.countable")]])],
  ]));
})();
