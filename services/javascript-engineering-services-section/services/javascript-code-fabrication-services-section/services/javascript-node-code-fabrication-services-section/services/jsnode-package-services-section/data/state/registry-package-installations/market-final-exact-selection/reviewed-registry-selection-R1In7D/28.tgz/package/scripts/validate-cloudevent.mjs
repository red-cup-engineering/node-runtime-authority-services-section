#!/usr/bin/env node
const { readFileSync: readInput } = globalThis.process?.getBuiltinModule?.("node:fs") ?? {};
import contract from "../schemas/validate-cloudevent.json" with { type: "json" };
export const inputSchema = contract.input;
export const outputSchema = contract.output;
import { canonicalJson } from "./canonical-json.mjs";
import { isJsonRecord } from "./is-json-record.mjs";
import { decodeJsonByteCarrier } from "../src/json-byte-carrier.mjs";

const contextAttributes = new Set([
  "specversion",
  "id",
  "source",
  "type",
  "datacontenttype",
  "dataschema",
  "subject",
  "time",
  "data",
  "data_base64",
]);
// v1.0.2: lowercase ASCII letters/digits are MUST; 20 characters is SHOULD.
const extensionName = /^[a-z0-9]+$/u;
const cloudEventInteger = (value) =>
  typeof value === "number" && Number.isInteger(value) &&
  value >= -2_147_483_648 && value <= 2_147_483_647;
// CloudEvents String is narrower than a JavaScript string: context values
// must not carry controls, unpaired surrogates or Unicode noncharacters.
const cloudEventString = (value) => {
  if (typeof value !== "string") return false;
  for (let i = 0; i < value.length; i++) {
    const scalar = value.codePointAt(i);
    if (scalar <= 0x1f || (scalar >= 0x7f && scalar <= 0x9f) ||
        (scalar >= 0xd800 && scalar <= 0xdfff) ||
        (scalar >= 0xfdd0 && scalar <= 0xfdef) ||
        (scalar & 0xfffe) === 0xfffe) return false;
    if (scalar > 0xffff) i++;
  }
  return true;
};
const cloudEventExtensionValue = (value) =>
  value === null || typeof value === "boolean" ||
  cloudEventString(value) || cloudEventInteger(value);
const rfc3339 =
  /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/u;

export function validateCloudEvent(request) {
  const event = request?.event;
  if (!isJsonRecord(event)) throw new TypeError("event is required");
  const violations = [];
  // Call the existing RFC 8785/Data JSON admission before reading any event
  // properties. This refuses cycles, accessor fields, undefined, NaN and
  // JavaScript objects before they can masquerade as a JSON wire event.
  try {
    canonicalJson(event);
  } catch {
    return {
      type: "CloudEventValidation", ok: false,
      violations: [{
        kind: "instance", path: "", keyword: "jsonValue",
        message: "CloudEvent must be an admitted JSON value",
      }],
      event,
    };
  }
  for (const name of ["id", "source", "specversion", "type"]) {
    if (!cloudEventString(event[name]) || event[name].length === 0)
      violations.push({
        kind: "instance",
        path: "",
        keyword: "required",
        message: `must have required property '${name}'`,
      });
  }
  if (event.specversion !== undefined && event.specversion !== "1.0")
    violations.push({
      kind: "instance",
      path: "/specversion",
      keyword: "const",
      message: "must be exactly 1.0",
    });
  for (const name of ["datacontenttype", "dataschema", "subject"])
    if (event[name] !== undefined && event[name] !== null &&
        (!cloudEventString(event[name]) || event[name].length === 0))
      violations.push({
        kind: "instance", path: `/${name}`, keyword: "type",
        message: `${name} must be a CloudEvents String`,
      });
  if (
    event.time !== undefined && event.time !== null &&
    (typeof event.time !== "string" || !rfc3339.test(event.time))
  )
    violations.push({
      kind: "instance",
      path: "/time",
      keyword: "format",
      message: "must match format date-time",
    });
  if (Object.hasOwn(event, "data") && Object.hasOwn(event, "data_base64"))
    violations.push({
      kind: "instance",
      path: "/data",
      keyword: "mutuallyExclusive",
      message: "data and data_base64 must not both be present",
    });
  if (Object.hasOwn(event, "data_base64")) {
    // This is exactly the existing Data Base64 codec; CloudEvents does not
    // get a second parser. data_base64 denotes binary payload, not a generic
    // extension attribute or a UTF-8 JSON string.
    try {
      decodeJsonByteCarrier({
        carrier: { mediaType: event.datacontenttype, contentBase64: event.data_base64 },
      });
    } catch {
      violations.push({
        kind: "instance", path: "/data_base64", keyword: "contentEncoding",
        message: "binary data must be canonical RFC 4648 Base64 with a declared data content type",
      });
    }
  }
  for (const name of Object.keys(event)) {
    if (contextAttributes.has(name)) continue;
    if (!extensionName.test(name)) {
      violations.push({
        kind: "instance", path: `/${name}`, keyword: "extensionName",
        message: "extension attribute names must contain only lowercase ASCII letters and digits",
      });
    } else if (!cloudEventExtensionValue(event[name])) {
      violations.push({
        kind: "instance", path: `/${name}`, keyword: "type",
        message: "extension attributes must be CloudEvents String, Boolean, Integer (signed 32-bit), or null",
      });
    }
  }
  return {
    type: "CloudEventValidation",
    ok: violations.length === 0,
    violations,
    event,
  };
}

if (import.meta.main)
  process.stdout.write(
    JSON.stringify(validateCloudEvent(JSON.parse(readInput(0, "utf8")))) + "\n",
  );
