/**
 * Incremental bounded-memory SSE frame acquisition.
 * Computer Serialized Content remains the sole owner of SSE field parsing.
 * Per WHATWG HTML 9.2, CR, LF and CRLF delimit lines, a blank line dispatches,
 * and an unterminated last event at EOF is discarded (not reported as success).
 */
import { parseSseStream } from "@red-cup-engineering/computer-serialized-content-engineering-services-section/services/http-data-services-section/src/server-sent-event";

/** Find the earliest completed frame, without treating a split CRLF as two ends. */
function eventBoundary(text, final = false) {
  let lineStart = 0;
  let priorLineEnding = 0;
  for (let i = 0; i < text.length;) {
    const value = text[i];
    if (value !== "\r" && value !== "\n") { i++; continue; }
    // The final CR of a chunk may be the first byte of the next chunk's CRLF.
    if (value === "\r" && i + 1 === text.length && !final) return undefined;
    const width = value === "\r" && text[i + 1] === "\n" ? 2 : 1;
    if (i === lineStart) return { frameEnd: priorLineEnding, after: i + width };
    priorLineEnding = i;
    lineStart = i + width;
    i = lineStart;
  }
  return undefined;
}

function eventOfFrame(frame) {
  return parseSseStream(`${frame}\n\n`)[0];
}

/** Emits only completely separated events, bounded individually by encoded bytes. */
export async function* parseSseByteStream(source, options = {}) {
  const maximum = options.maxEventBytes ?? 4 * 1024 * 1024;
  if (!Number.isSafeInteger(maximum) || maximum < 1)
    throw new RangeError("SSE maxEventBytes must be a positive safe integer");
  const decoder = new TextDecoder("utf-8");
  const encoder = new TextEncoder();
  let buffer = "";

  function* drain(final = false) {
    for (;;) {
      const boundary = eventBoundary(buffer, final);
      if (boundary === undefined) break;
      if (encoder.encode(buffer.slice(0, boundary.after)).length > maximum)
        throw new RangeError(`SSE event exceeds ${maximum} bytes`);
      const frame = buffer.slice(0, boundary.frameEnd);
      buffer = buffer.slice(boundary.after);
      const event = eventOfFrame(frame);
      if (event !== undefined) yield event;
    }
  }

  for await (const chunk of source) {
    buffer += typeof chunk === "string" ? chunk : decoder.decode(chunk, { stream: true });
    // A transport batch may contain hundreds of *small* events: parse them
    // before applying the size bound to the remaining incomplete frame.
    yield* drain();
    if (encoder.encode(buffer).length > maximum)
      throw new RangeError(`SSE event exceeds ${maximum} bytes`);
  }
  buffer += decoder.decode();
  yield* drain(true);
  // Remaining nonblank-line-terminated material is intentionally discarded.
}
