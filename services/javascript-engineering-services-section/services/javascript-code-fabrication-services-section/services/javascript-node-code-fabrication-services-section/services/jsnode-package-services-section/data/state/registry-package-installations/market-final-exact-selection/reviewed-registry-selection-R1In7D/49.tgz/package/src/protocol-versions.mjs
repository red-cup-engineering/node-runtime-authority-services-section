/**
 * One source for the version list shared by MCP's legacy server and its
 * stateless 2026 adapter. Pure data: importing /modern must not eagerly
 * import SignCell, schema admission, Node transports, or OAuth machinery.
 * Consumers must still independently qualify which protocol eras they serve.
 */
export const MCP_PROTOCOL_VERSIONS = Object.freeze([
  "2025-11-25", "2025-06-18", "2025-03-26", "2024-11-05",
]);
export const LATEST_MCP_PROTOCOL_VERSION = MCP_PROTOCOL_VERSIONS[0];
