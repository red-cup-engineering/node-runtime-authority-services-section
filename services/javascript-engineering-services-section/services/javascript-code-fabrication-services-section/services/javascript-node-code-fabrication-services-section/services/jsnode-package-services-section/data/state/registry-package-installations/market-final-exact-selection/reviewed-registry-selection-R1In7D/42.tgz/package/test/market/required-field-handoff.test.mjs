import test from "node:test";
import assert from "node:assert/strict";
import { compareMarketOfferSamples, projectMarketOfferBody } from "../../src/market/catalog.mjs";
import { validateJsonSchema } from "@red-cup-engineering/json-schema-services-section/validation";

// These declarations follow the actual published Causeway x402 market
// canonicalization -> UTF-8 -> NI naming contracts, without importing the
// merchant inventory into a reusable Networking protocol provider.
const canonical = {
  sku: "ni:canonical", listed: true, method: "POST",
  output: {
    schema: {type:"object",additionalProperties:false,
      required:["text","byteLength","standard"],properties:{
        text:{type:"string",maxLength:65536},byteLength:{type:"integer"},
        standard:{const:"RFC8785"}}},
    example: {text:'{"a":1,"z":2}',byteLength:13,standard:"RFC8785"},
  },
};
const utf8 = {
  sku: "ni:utf8", listed: true, method: "POST",
  request:{bodySchema:{type:"object",additionalProperties:false,
    required:["text"],properties:{text:{type:"string",maxLength:65536}}}},
  output:{
    schema:{type:"object",additionalProperties:false,
      required:["carrier","byteLength"],properties:{
        carrier:{type:"object",additionalProperties:false,
          required:["mediaType","contentBase64"],properties:{
            mediaType:{const:"text/plain;charset=utf-8"},
            contentBase64:{type:"string",maxLength:87384}}},
        byteLength:{type:"integer"}}},
    example:{carrier:{mediaType:"text/plain;charset=utf-8",
      contentBase64:"eyJhIjoxLCJ6IjoyfQ=="},byteLength:13},
  },
};
const named = {
  sku:"ni:named",listed:true,method:"POST",
  request:{bodySchema:{type:"object",additionalProperties:false,
    required:["carrier"],properties:{
      carrier:{type:"object",additionalProperties:false,
        required:["mediaType","contentBase64"],properties:{
          mediaType:{type:"string",minLength:1,maxLength:256},
          contentBase64:{type:"string",maxLength:87384}}}}}},
  output:{schema:{type:"object",required:["uri"],properties:{uri:{type:"string"}}},
    example:{uri:"ni:///sha-256;receipt"}},
};

test("source-owned catalog finds two field-selecting service edges, not false direct edges", () => {
  assert.equal(validateJsonSchema(canonical.output.example,utf8.request.bodySchema).valid,false);
  assert.equal(validateJsonSchema(utf8.output.example,named.request.bodySchema).valid,false);
  const reading=compareMarketOfferSamples([canonical,utf8,named],{maxSamplePairs:6});
  const projected=reading.sampleAdmittedLinks.filter(x=>x.fieldSelection);
  assert.deepEqual(projected.map(x=>[x.from,x.to,x.fieldSelection]),[
    ["ni:canonical","ni:utf8",["text"]],
    ["ni:utf8","ni:named",["carrier"]],
  ]);
  assert.equal(reading.complete,true);
  assert.equal(reading.authorizesExecution,false);
  assert.ok(projected.every(edge=>
    edge.executionAuthorized===false && edge.contractualCompositionProven===false));
});

test("original JSON Schema supplier validates actual received result and required-field request", () => {
  const first=projectMarketOfferBody(canonical,utf8,canonical.output.example);
  assert.deepEqual(first.body,{text:'{"a":1,"z":2}'});
  assert.equal(first.paymentAuthorized,false);
  const second=projectMarketOfferBody(utf8,named,utf8.output.example);
  assert.deepEqual(second.body,{carrier:{
    mediaType:"text/plain;charset=utf-8",contentBase64:"eyJhIjoxLCJ6IjoyfQ=="}});
  assert.equal(second.deliveryReceived,false);
  utf8.output.example.carrier.contentBase64="later-change";
  assert.equal(second.body.carrier.contentBase64,"eyJhIjoxLCJ6IjoyfQ==");
  assert.equal(Object.isFrozen(second.body), true);
  assert.equal(Object.isFrozen(second.body.carrier), true,
    "nested transport values must stay stable after validation");
});

test("HTTP byte limit rejects oversized Unicode body despite valid JSON Schema", () => {
  const longText = "汉".repeat(40000);
  const source = { ...canonical, output: {
    ...canonical.output,
    example: { text: longText, byteLength: 120000, standard: "RFC8785" },
  }};
  assert.equal(validateJsonSchema(source.output.example,source.output.schema).valid,true);
  assert.equal(validateJsonSchema({text:longText},utf8.request.bodySchema).valid,true);
  assert.throws(()=>projectMarketOfferBody(source,utf8,source.output.example),
    /UTF-8|byte ceiling/);
  const tiny={...utf8,request:{...utf8.request,maxBytes:8}};
  assert.throws(()=>projectMarketOfferBody(canonical,tiny,canonical.output.example),
    /byte ceiling/);
  const malformed={...utf8,request:{...utf8.request,maxBytes:-1}};
  assert.throws(()=>projectMarketOfferBody(canonical,malformed,canonical.output.example),
    /valid byte ceiling/);
});

test("incompatible type, withheld offer, absent required field and wrong media refuse", () => {
  assert.throws(()=>projectMarketOfferBody(canonical,utf8,
    {text:4,byteLength:13,standard:"RFC8785"}),/output schema/);
  assert.throws(()=>projectMarketOfferBody(canonical,utf8,
    {byteLength:13,standard:"RFC8785"}),/required fields/);
  assert.throws(()=>projectMarketOfferBody({...canonical,listed:false},utf8,
    canonical.output.example),/distinct listed/);
  assert.throws(()=>projectMarketOfferBody(canonical,{...utf8,
    request:{bodySchema:{type:"object",required:["payload"],
      properties:{payload:{type:"string"}}}}},canonical.output.example),/cannot supply/);
  const wrong={...named,request:{bodySchema:{type:"object",additionalProperties:false,
    required:["carrier"],properties:{carrier:{type:"object",
      required:["mediaType"],properties:{mediaType:{const:"application/pdf"}}}}}}};
  assert.throws(()=>projectMarketOfferBody(utf8,wrong,
    {carrier:{mediaType:"text/plain;charset=utf-8",contentBase64:"YWJj"},byteLength:3}),
    /target input schema/);
});
