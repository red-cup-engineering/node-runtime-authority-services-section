//#region src/experimental-config/types.d.ts
/**
 * The shape of `wrangler.config.ts` — tooling / bundling / dev-server
 * configuration that complements the Worker configuration authored in
 * `cloudflare.config.ts` via `defineConfig`.
 */
interface WranglerConfig {
  noBundle?: boolean;
  minify?: boolean;
  keepNames?: boolean;
  alias?: Record<string, string>;
  define?: Record<string, string>;
  findAdditionalModules?: boolean;
  preserveFileNames?: boolean;
  baseDir?: string;
  rules?: Array<{
    type: "ESModule" | "CommonJS" | "CompiledWasm" | "Text" | "Data" | "PythonModule" | "PythonRequirement";
    globs: string[];
    fallthrough?: boolean;
  }>;
  wasmModules?: Record<string, string>;
  textBlobs?: Record<string, string>;
  dataBlobs?: Record<string, string>;
  tsconfig?: string;
  jsxFactory?: string;
  jsxFragment?: string;
  pythonModules?: {
    exclude?: string[];
  };
  uploadSourceMaps?: boolean;
  build?: {
    command?: string;
    cwd?: string;
    watchDir?: string | string[];
  };
  /**
   * Assets directory — the only tooling-side asset setting. The runtime
   * asset fields (`binding`, `htmlHandling`, `notFoundHandling`,
   * `runWorkerFirst`) live in `cloudflare.config.ts` under `worker.assets`.
   */
  assetsDirectory?: string;
  /**
   * Type-generation settings used by Wrangler dev and build. Defaults to
   * `{ generate: true, includeRuntime: true }`.
   *
   * - `generate`: emit `.cloudflare/types/index.d.ts`.
   * - `includeRuntime`: append the Workers runtime types generated from the
   *   project's compatibility date and flags.
   */
  types?: {
    generate?: boolean;
    includeRuntime?: boolean;
  };
  dev?: {
    ip?: string;
    port?: number;
    inspectorPort?: number;
    inspectorIp?: string;
    localProtocol?: "http" | "https";
    upstreamProtocol?: "http" | "https";
    host?: string;
    /**
     * Container-related dev settings. `containers` itself is currently not
     * supported under `--experimental-new-config`, but these dev-time settings are
     * accepted so users can enable them ahead of `containers` opening up.
     * They're no-ops when `containers` is absent.
     */
    enableContainers?: boolean;
    /**
     * Either the Docker unix socket (e.g. `unix:///var/run/docker.sock`) or
     * a full configuration. The string form is the common case; the full
     * object form (with `localDocker.socketPath` and TLS settings) can be
     * added later if needed.
     */
    containerEngine?: string;
  };
  sendMetrics?: boolean;
}
//#endregion
//#region ../config/dist/public-DsUKmT49.d.mts

//#endregion
//#region src/definition.d.ts
interface ConfigContext {
  /** Whether the config is being evaluated for a Preview build. */
  isPreview: boolean;
  /**
   * The mode the config is being evaluated in.
   * Set via the `--mode` CLI flag.
   * In Vite the mode defaults to `development` in `vite dev` and `production` in `vite build` ([more info](https://vite.dev/guide/env-and-mode.html#modes)).
   * In Wrangler the mode defaults to `undefined`.
   */
  mode: string | undefined;
}
/**
 * A configuration value, promise, or factory. Factories can be passed directly
 * for automatic resolution with the current context or called explicitly with
 * another context before they are used.
 */
//#endregion
//#region src/experimental-config/wrangler-definition.d.ts
type WranglerConfigExport = WranglerConfig | Promise<WranglerConfig> | ((ctx: ConfigContext) => WranglerConfig | Promise<WranglerConfig>);
declare function defineWranglerConfig(config: WranglerConfigExport): WranglerConfigExport;
//#endregion
export { WranglerConfig, WranglerConfigExport, defineWranglerConfig };
//# sourceMappingURL=experimental-config.d.mts.map