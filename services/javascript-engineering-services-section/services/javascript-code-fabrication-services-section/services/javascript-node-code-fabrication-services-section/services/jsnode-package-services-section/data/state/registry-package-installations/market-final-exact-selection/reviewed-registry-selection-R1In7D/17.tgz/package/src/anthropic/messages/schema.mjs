/**
 * Anthropic Messages schema compatibility surface.
 *
 * The wire schema, validating contracts, codec and streaming client belong to
 * @red-cup-engineering/computer-inference-engine under its anthropic/* exports.
 * The accepted inference consolidation moved the former provider-team
 * boundary into this engine. This source file has no runtime exports; the
 * actual wire schemas live in ../messages-schema.mjs.
 */

/** Forward-compatible SSE event; per-event interpretation remains in the pure inference reading. */

