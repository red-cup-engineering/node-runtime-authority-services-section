import { isOsvRecordId } from "./osv-record-identity.mjs";

/**
 * Assemble revision-bearing public OSV advisories into a buyer-useful dossier.
 * This assembles public records; it does not allocate identifiers, submit to a
 * CVE Numbering Authority, publish undisclosed research, or claim CNA rights.
 */
const CVE = /^CVE-[0-9]{4}-[0-9]{4,}$/u;
const MAX = 8;
function object(input) {
  if (!input || typeof input !== "object" || Array.isArray(input)) throw new TypeError("advisory request must be an object");
  return input;
}
function sourceId(record) {
  return { id: record.id, modified: record.modified ?? null, published: record.published ?? null,
    withdrawn: record.withdrawn ?? null, source: `https://osv.dev/vulnerability/${encodeURIComponent(record.id)}` };
}
function references(record) {
  return (record.references ?? []).filter(item => {
    if (typeof item?.url !== "string") return false;
    try { return new URL(item.url).protocol === "https:"; } catch { return false; }
  }).slice(0, 30).map(({ type, url }) => ({ type: type ?? "WEB", url }));
}
function affectedProducts(record) {
  return (record.affected ?? []).map(row => ({
    ecosystem: row.package?.ecosystem ?? "unknown",
    package: row.package?.name ?? "unknown",
    purl: row.package?.purl ?? null,
    versions: Array.isArray(row.versions) ? row.versions : [],
    ranges: (row.ranges ?? []).map(r => ({ type: r.type ?? "unknown", repo: r.repo ?? null,
      events: (r.events ?? []).map(event => Object.fromEntries(
        Object.entries(event).filter(([key]) => ["introduced", "fixed", "last_affected", "limit"].includes(key))
      )) })),
  }));
}
export function diffPublicAdvisories(previous, current) {
  const old = new Map((previous?.advisories ?? []).map(row => [row.id, row]));
  const now = new Map((current?.advisories ?? []).map(row => [row.id, row]));
  const changes = [];
  for (const row of current?.advisories ?? []) {
    const past = old.get(row.id);
    if (!past) changes.push({ kind: "new", id: row.id, modified: row.modified });
    else if (row.modified !== past.modified || row.withdrawn !== past.withdrawn)
      changes.push({ kind: row.withdrawn && !past.withdrawn ? "withdrawn" : "updated", id: row.id, modified: row.modified });
  }
  if (current?.complete) for (const row of previous?.advisories ?? []) if (!now.has(row.id))
    changes.push({ kind: "no-longer-selected", id: row.id, modified: row.modified });
  return changes.sort((a, b) => a.id.localeCompare(b.id));
}
export function admitPublicAdvisoryRequest(request) {
  object(request);
  const ids = request.ids;
  if (!Array.isArray(ids) || ids.length < 1 || ids.length > MAX ||
      ids.some(id => !isOsvRecordId(id)) || new Set(ids).size !== ids.length) {
    throw new TypeError("supply 1-8 distinct, exact public OSV/GHSA record IDs");
  }
  return true;
}
export async function assemblePublicAdvisories(request, { fetchImplementation = fetch, now = () => new Date().toISOString() } = {}) {
  admitPublicAdvisoryRequest(request);
  const ids = request.ids;
  const records = await Promise.all(ids.map(async id => {
    const response = await fetchImplementation(`https://api.osv.dev/v1/vulns/${encodeURIComponent(id)}`, {
      headers: { Accept: "application/json" }, signal: AbortSignal.timeout(12_000)
    });
    if (!response?.ok) throw new Error(`OSV advisory ${id} unavailable: HTTP ${response?.status ?? "unknown"}`);
    const record = await response.json();
    if (record.id !== id || !record.modified) throw new Error(`OSV advisory ${id} has an inconsistent identity or revision`);
    return record;
  }));
  const advisories = records.map(record => ({
    ...sourceId(record),
    title: record.summary ?? null,
    aliases: (record.aliases ?? []).filter(id => typeof id === "string"),
    cves: [record.id, ...(record.aliases ?? [])].filter(id => typeof id === "string" && CVE.test(id)),
    affected: affectedProducts(record),
    references: references(record),
    credits: (record.credits ?? []).map(item => ({ name: item.name ?? null, type: item.type ?? null })),
  })).sort((a, b) => a.id.localeCompare(b.id));
  const aliasMap = new Map();
  for (const row of advisories) {
    for (const id of [row.id, ...row.aliases]) {
      const associated = aliasMap.get(id) ?? [];
      associated.push(row.id);
      aliasMap.set(id, associated);
    }
  }
  const dossier = {
    format: "561-public-advisory-dossier-v1",
    observedAt: now(),
    complete: true,
    advisories,
    identifierIndex: [...aliasMap.entries()].sort(([a], [b]) => a.localeCompare(b))
      .map(([identifier, sourceIds]) => ({ identifier, records: [...new Set(sourceIds)].sort() })),
    disclosure: { source: "public OSV records only", authority: "No CNA status or new CVE identifier is asserted",
      distribution: "Public record and revision links; no authorization to disclose unpublished vulnerabilities" },
  };
  if (request.previousDossier !== undefined) dossier.changes = diffPublicAdvisories(request.previousDossier, dossier);
  return dossier;
}
