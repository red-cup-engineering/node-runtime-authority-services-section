/** Acquire a GET response within one original deadline, including shared origin
 * Retry-After floors and Code retry waits. The returned signal retains that
 * deadline for the existing bounded body reader. Body/schema policy belongs to
 * the consumer; this operation never retries an already received body. */
import {retryWithBackoff,delay} from '@red-cup-engineering/javascript-node-services-section/retry';
import {retryAfterDelayMs} from './retry-after.mjs';
const cooldowns=new WeakMap();
export async function acquireHttpResponse(url,{fetchImpl=fetch,headers={},timeoutMs=10000,redirect='follow'}={}) {
 if(!Number.isSafeInteger(timeoutMs)||timeoutMs<=0||timeoutMs>4294967295)throw new TypeError('positive finite acquisition timeout required');
 const target=new URL(url),deadline=Date.now()+timeoutMs,receipts=[];
 let origins=cooldowns.get(fetchImpl);if(!origins){origins=new Map();cooldowns.set(fetchImpl,origins);}
 let latest=null,signal,attempts=0;
 const refused=(reason)=>Object.assign(new Error(`HTTP acquisition ${reason}; ${JSON.stringify({attempts,rateLimits:receipts,cooldownUntil:origins.get(target.origin)??null})}`),{attempts,rateLimits:receipts});
 const wait=async milliseconds=>{
  const remaining=deadline-Date.now();
  if(milliseconds>=remaining)throw refused('retry delay exceeds original acquisition deadline');
  if(milliseconds>0)await delay(milliseconds);
 };
 const result=await retryWithBackoff({
  operation:async()=>{
   await wait(Math.max(0,(origins.get(target.origin)??0)-Date.now()));
   const remaining=deadline-Date.now();if(remaining<=0)throw refused('original acquisition deadline exhausted');
   signal=AbortSignal.timeout(remaining);attempts++;
   let response;
   try { response=await fetchImpl(target,{headers,signal,redirect}); }
   catch(error) {
    latest={status:null,receivedAt:new Date().toISOString(),code:error.code??error.name,networkFailure:true};
    return {ok:false,refusal:latest};
   }
   if(response.ok)return {ok:true,value:response};
   const at=Date.now(),retryAfterMs=retryAfterDelayMs(response.headers?.get('retry-after'),at);
   latest={status:response.status,receivedAt:new Date(at).toISOString(),retryAfterMs};
   if(response.status===429||response.status===503){receipts.push(latest);if(retryAfterMs!==null)origins.set(target.origin,Math.max(origins.get(target.origin)??0,at+retryAfterMs));}
   // Cancellation releases the failed response; it cannot extend acquisition
   // beyond the original deadline while a stream waits to acknowledge it.
   void response.body?.cancel().catch(()=>{});
   return {ok:false,refusal:latest};
  },
  isRetryable:refusal=>refusal.status===429||[500,502,503,504].includes(refusal.status)||refusal.networkFailure===true&&Date.now()<deadline,
  delay:milliseconds=>wait(Math.max(milliseconds,(origins.get(target.origin)??0)-Date.now())),
 });
 if(!result.ok)throw refused(`HTTP ${latest?.status??'unknown'}`);
 return {response:result.value,signal,attempts,rateLimits:receipts,requestedUrl:target.href,url:result.value.url||target.href,receivedAt:new Date().toISOString()};
}
