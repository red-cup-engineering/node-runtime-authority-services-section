"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.zoneOutbox = exports.zonePortal = exports.zoneFactory = void 0;
exports.zoneFactory = [
    {
        type: 'event',
        name: 'ZoneCreated',
        inputs: [
            { name: 'zoneId', type: 'uint32', indexed: true },
            { name: 'portal', type: 'address', indexed: true },
            { name: 'initialToken', type: 'address', indexed: false },
            { name: 'admin', type: 'address', indexed: false },
            { name: 'sequencers', type: 'address[]', indexed: false },
            { name: 'threshold', type: 'uint8', indexed: false },
            { name: 'verifier', type: 'address', indexed: false },
        ],
    },
    {
        type: 'event',
        name: 'ZoneCreated',
        inputs: [
            { name: 'zoneId', type: 'uint32', indexed: true },
            { name: 'portal', type: 'address', indexed: true },
            { name: 'messenger', type: 'address', indexed: true },
            { name: 'initialToken', type: 'address', indexed: false },
            { name: 'admin', type: 'address', indexed: false },
            { name: 'sequencer', type: 'address', indexed: false },
            { name: 'verifier', type: 'address', indexed: false },
            { name: 'genesisBlockHash', type: 'bytes32', indexed: false },
            { name: 'genesisTempoBlockHash', type: 'bytes32', indexed: false },
            {
                name: 'genesisTempoBlockNumber',
                type: 'uint64',
                indexed: false,
            },
        ],
    },
    {
        type: 'function',
        name: 'createZone',
        stateMutability: 'nonpayable',
        inputs: [
            {
                name: 'params',
                type: 'tuple',
                components: [
                    { name: 'initialToken', type: 'address' },
                    { name: 'admin', type: 'address' },
                    { name: 'sequencers', type: 'address[]' },
                    { name: 'threshold', type: 'uint8' },
                    { name: 'rpcUrl', type: 'string' },
                ],
            },
        ],
        outputs: [
            { name: 'zoneId', type: 'uint32' },
            { name: 'portal', type: 'address' },
        ],
    },
    {
        type: 'function',
        name: 'createZone',
        stateMutability: 'nonpayable',
        inputs: [
            {
                name: 'params',
                type: 'tuple',
                components: [
                    { name: 'initialToken', type: 'address' },
                    { name: 'admin', type: 'address' },
                    { name: 'sequencer', type: 'address' },
                    { name: 'verifier', type: 'address' },
                    {
                        name: 'zoneParams',
                        type: 'tuple',
                        components: [
                            { name: 'genesisBlockHash', type: 'bytes32' },
                            { name: 'genesisTempoBlockHash', type: 'bytes32' },
                            { name: 'genesisTempoBlockNumber', type: 'uint64' },
                        ],
                    },
                    { name: 'rpcUrl', type: 'string' },
                ],
            },
        ],
        outputs: [
            { name: 'zoneId', type: 'uint32' },
            { name: 'portal', type: 'address' },
        ],
    },
    {
        type: 'function',
        name: 'verifier',
        stateMutability: 'view',
        inputs: [],
        outputs: [{ name: '', type: 'address' }],
    },
];
exports.zonePortal = [
    {
        name: 'WithdrawalProcessed',
        type: 'event',
        inputs: [
            { name: 'to', type: 'address', indexed: true },
            { name: 'senderTag', type: 'bytes32', indexed: true },
            { name: 'token', type: 'address', indexed: false },
            { name: 'amount', type: 'uint128', indexed: false },
            { name: 'callbackSuccess', type: 'bool', indexed: false },
        ],
    },
    {
        name: 'deposit',
        type: 'function',
        stateMutability: 'nonpayable',
        inputs: [
            { name: '_token', type: 'address' },
            { name: 'to', type: 'address' },
            { name: 'amount', type: 'uint128' },
            { name: 'memo', type: 'bytes32' },
            { name: 'bouncebackRecipient', type: 'address' },
        ],
        outputs: [{ name: '', type: 'bytes32' }],
    },
    {
        name: 'depositEncrypted',
        type: 'function',
        stateMutability: 'nonpayable',
        inputs: [
            { name: 'token', type: 'address' },
            { name: 'amount', type: 'uint128' },
            { name: 'keyIndex', type: 'uint256' },
            {
                name: 'encrypted',
                type: 'tuple',
                components: [
                    { name: 'ephemeralPubkeyX', type: 'bytes32' },
                    { name: 'ephemeralPubkeyYParity', type: 'uint8' },
                    { name: 'ciphertext', type: 'bytes' },
                    { name: 'nonce', type: 'bytes12' },
                    { name: 'tag', type: 'bytes16' },
                ],
            },
            { name: 'bouncebackRecipient', type: 'address' },
        ],
        outputs: [{ name: '', type: 'bytes32' }],
    },
    {
        name: 'sequencerEncryptionKey',
        type: 'function',
        stateMutability: 'view',
        inputs: [],
        outputs: [
            { name: 'x', type: 'bytes32' },
            { name: 'yParity', type: 'uint8' },
        ],
    },
    {
        name: 'encryptionKeyCount',
        type: 'function',
        stateMutability: 'view',
        inputs: [],
        outputs: [{ name: '', type: 'uint256' }],
    },
];
exports.zoneOutbox = [
    {
        name: 'requestWithdrawal',
        type: 'function',
        stateMutability: 'nonpayable',
        inputs: [
            { name: 'token', type: 'address' },
            { name: 'to', type: 'address' },
            { name: 'amount', type: 'uint128' },
            { name: 'memo', type: 'bytes32' },
            { name: 'gasLimit', type: 'uint64' },
            { name: 'fallbackRecipient', type: 'address' },
            { name: 'data', type: 'bytes' },
            { name: 'revealTo', type: 'bytes' },
        ],
        outputs: [],
    },
    {
        name: 'calculateWithdrawalFee',
        type: 'function',
        stateMutability: 'view',
        inputs: [{ name: 'gasLimit', type: 'uint64' }],
        outputs: [{ name: 'fee', type: 'uint128' }],
    },
];
//# sourceMappingURL=Abis.js.map