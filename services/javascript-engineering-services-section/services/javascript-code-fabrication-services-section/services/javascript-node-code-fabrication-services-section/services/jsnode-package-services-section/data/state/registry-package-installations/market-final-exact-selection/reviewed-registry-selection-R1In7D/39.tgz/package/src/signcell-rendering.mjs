/** An inert, theme-independent HTML view of the native SignCell section.
 *  Browser clients and server documents read the same data-layer method. */
import { sectionReading } from "@red-cup-engineering/signcell/cell";
import { escapeHtml } from "./tufte-browser.mjs";

export function renderSignCellSection(cells = []) {
  const view = sectionReading(cells);
  const text = (value) => escapeHtml(typeof value === "string" ? value : JSON.stringify(value, null, 2));
  return `<section aria-label="Perceived evidence"><p>${Object.entries(view.readings).map(([name, count]) => `${count} ${name}`).join(" · ")}</p>${view.alternatives.length ? `<p>Multiple values: ${view.alternatives.map(text).join(", ")}. A functional reading requires one unopposed cell.</p>` : ""}${view.entries.map(({ cell, address, reading, presence, witnesses }) => `<details><summary>${text(cell.predicate)} · ${reading}</summary><p>Witness presence: ${presence}; ${witnesses.pos} for, ${witnesses.neg} against.</p><pre>${text(cell.object)}</pre><code>${address}</code><details><summary>Witnesses</summary><pre>${text({ for: cell.for, against: cell.against })}</pre></details></details>`).join("")}${view.entries.length ? "" : "<p>No perceived cells. Map scenery supplies no evidence.</p>"}</section>`;
}
