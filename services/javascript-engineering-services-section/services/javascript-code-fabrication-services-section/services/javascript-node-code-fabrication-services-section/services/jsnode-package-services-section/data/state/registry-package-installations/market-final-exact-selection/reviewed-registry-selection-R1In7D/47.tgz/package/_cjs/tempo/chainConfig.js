"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.chainConfig = void 0;
const Hex = require("ox/Hex");
const tempo_1 = require("ox/tempo");
const getCode_js_1 = require("../actions/public/getCode.js");
const verifyHash_js_1 = require("../actions/public/verifyHash.js");
const number_js_1 = require("../constants/number.js");
const isAddressEqual_js_1 = require("../utils/address/isAddressEqual.js");
const defineChain_js_1 = require("../utils/chain/defineChain.js");
const transaction_js_1 = require("../utils/formatters/transaction.js");
const transactionReceipt_js_1 = require("../utils/formatters/transactionReceipt.js");
const transactionRequest_js_1 = require("../utils/formatters/transactionRequest.js");
const getAction_js_1 = require("../utils/getAction.js");
const keccak256_js_1 = require("../utils/hash/keccak256.js");
const accessKey_js_1 = require("./actions/accessKey.js");
const Formatters = require("./Formatters.js");
const Concurrent = require("./internal/concurrent.js");
const Transaction = require("./Transaction.js");
const maxExpirySecs = 25;
function randomValidAfter() {
    const now = BigInt(Math.floor(Date.now() / 1_000));
    const latest = now - 60n;
    if (latest <= 0n)
        return 0;
    return Number(BigInt(Hex.random(8)) % latest);
}
exports.chainConfig = {
    blockTime: 1_000,
    extendSchema: (0, defineChain_js_1.extendSchema)(),
    formatters: {
        transaction: (0, transaction_js_1.defineTransaction)({
            exclude: ['aaAuthorizationList'],
            format: Formatters.formatTransaction,
        }),
        transactionReceipt: (0, transactionReceipt_js_1.defineTransactionReceipt)({
            format: Formatters.formatTransactionReceipt,
        }),
        transactionRequest: (0, transactionRequest_js_1.defineTransactionRequest)({
            format: Formatters.formatTransactionRequest,
        }),
    },
    prepareTransactionRequest: [
        async (r, { client, phase }) => {
            const request = r;
            if (phase === 'afterFillParameters') {
                if (typeof request.gas !== 'undefined' &&
                    request.feePayer &&
                    !request.feePayerSignature) {
                    if (request.keyAuthorization?.signature.type === 'webAuthn')
                        request.gas = (request.gas ?? 0n) + 20000n;
                    else if (request.account?.source === 'accessKey')
                        request.gas = (request.gas ?? 0n) + 10000n;
                }
                return request;
            }
            const multisig = request.multisig ??
                (request.account?.source === 'multisig'
                    ? request.account.config
                    : undefined);
            if (multisig) {
                const config = tempo_1.MultisigConfig.from(multisig);
                request.multisig = config;
                request.from = tempo_1.MultisigConfig.getAddress(config);
                request.multisigInit = {
                    salt: config.salt ?? tempo_1.MultisigConfig.zeroSalt,
                    threshold: Number(config.threshold),
                    owners: config.owners.map((owner) => ({
                        owner: owner.owner,
                        weight: Number(owner.weight),
                    })),
                };
                request.multisigSignatureCount ??= inferMultisigSignatureCount(config);
                if (request.account?.source !== 'multisig')
                    delete request.account;
            }
            if (!request.keyAuthorization &&
                request.account?.source === 'accessKey') {
                const keyAuthorizationManager = request.account.keyAuthorizationManager;
                if (keyAuthorizationManager) {
                    const chainId = request.chainId ?? request.chain?.id;
                    if (typeof chainId !== 'undefined') {
                        const address = request.account.address;
                        const accessKey = request.account.accessKeyAddress;
                        const key = { address, accessKey, chainId };
                        const keyAuthorization = await keyAuthorizationManager.get(key);
                        if (keyAuthorization) {
                            const now = BigInt(Math.floor(Date.now() / 1000));
                            if (keyAuthorization.expiry != null &&
                                BigInt(keyAuthorization.expiry) <= now) {
                                await keyAuthorizationManager.remove(key);
                            }
                            else {
                                const metadata = await (0, getAction_js_1.getAction)(client, accessKey_js_1.getMetadata, 'getMetadata')({ account: address, accessKey });
                                if ((0, isAddressEqual_js_1.isAddressEqual)(metadata.address, accessKey) &&
                                    !metadata.isRevoked &&
                                    metadata.expiry > now)
                                    await keyAuthorizationManager.remove(key);
                                else
                                    request.keyAuthorization = keyAuthorization;
                            }
                        }
                    }
                }
            }
            const useExpiringNonce = await (async () => {
                if (request.nonceKey === 'expiring')
                    return true;
                if (multisig)
                    return false;
                if (request.feePayer && typeof request.nonceKey === 'undefined')
                    return true;
                const address = request.account?.address;
                if (address && typeof request.nonceKey === 'undefined')
                    return await Concurrent.detect(address);
                return false;
            })();
            if (useExpiringNonce) {
                request.nonceKey = number_js_1.maxUint256;
                request.nonce = 0;
                if (typeof request.validAfter === 'undefined')
                    request.validAfter = randomValidAfter();
                if (typeof request.validBefore === 'undefined')
                    request.validBefore = Math.floor(Date.now() / 1000) + maxExpirySecs;
            }
            else if (typeof request.nonceKey !== 'undefined') {
                request.nonce = typeof request.nonce === 'number' ? request.nonce : 0;
            }
            if (!request.feeToken && request.chain?.feeToken)
                request.feeToken = request.chain.feeToken;
            return request;
        },
        { runAt: ['beforeFillTransaction', 'afterFillParameters'] },
    ],
    serializers: {
        transaction: ((transaction, signature) => Transaction.serialize(transaction, signature)),
    },
    async verifyHash(client, parameters) {
        const { address, hash, signature, mode } = parameters;
        const envelope = (() => {
            if (typeof signature !== 'string')
                return;
            try {
                return tempo_1.SignatureEnvelope.deserialize(signature);
            }
            catch {
                return undefined;
            }
        })();
        if (envelope) {
            if (envelope?.type === 'keychain' && mode === 'allowAccessKey') {
                const innerPayload = envelope.version === 'v2'
                    ? (0, keccak256_js_1.keccak256)(Hex.concat('0x04', hash, address))
                    : hash;
                const accessKeyAddress = (() => {
                    try {
                        return tempo_1.SignatureEnvelope.extractAddress({
                            payload: innerPayload,
                            signature: envelope.inner,
                        });
                    }
                    catch {
                        return undefined;
                    }
                })();
                if (!accessKeyAddress)
                    return false;
                const keyInfo = await (0, accessKey_js_1.getMetadata)(client, {
                    account: address,
                    accessKey: accessKeyAddress,
                    blockHash: parameters.blockHash,
                    blockNumber: parameters.blockNumber,
                    blockTag: parameters.blockTag,
                    requireCanonical: parameters.requireCanonical,
                });
                if (keyInfo.isRevoked)
                    return false;
                if (keyInfo.expiry <= BigInt(Math.floor(Date.now() / 1000)))
                    return false;
                return tempo_1.SignatureEnvelope.verify(envelope.inner, {
                    address: accessKeyAddress,
                    payload: innerPayload,
                });
            }
            if (envelope.type === 'p256' || envelope.type === 'webAuthn') {
                const code = await (0, getCode_js_1.getCode)(client, {
                    address,
                    blockHash: parameters.blockHash,
                    blockNumber: parameters.blockNumber,
                    blockTag: parameters.blockTag,
                    requireCanonical: parameters.requireCanonical,
                });
                if (!code ||
                    code === '0xef01007702c00000000000000000000000000000000000')
                    return tempo_1.SignatureEnvelope.verify(envelope, {
                        address,
                        payload: hash,
                    });
            }
        }
        return await (0, getAction_js_1.getAction)(client, verifyHash_js_1.verifyHash, 'verifyHash')({ ...parameters, chain: null });
    },
};
function inferMultisigSignatureCount(config) {
    const threshold = Number(config.threshold);
    const weights = config.owners
        .map((owner) => Number(owner.weight))
        .sort((a, b) => b - a);
    let total = 0;
    for (const [index, weight] of weights.entries()) {
        total += weight;
        if (total >= threshold)
            return index + 1;
    }
    return weights.length;
}
//# sourceMappingURL=chainConfig.js.map