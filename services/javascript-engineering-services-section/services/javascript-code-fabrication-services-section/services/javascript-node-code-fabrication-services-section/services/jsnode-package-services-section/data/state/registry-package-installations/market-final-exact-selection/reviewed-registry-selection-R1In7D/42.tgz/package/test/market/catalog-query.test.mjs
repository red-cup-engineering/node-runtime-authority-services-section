import test from "node:test";
import assert from "node:assert/strict";
import { selectPublicMarketCatalogRows as select, compareMarketOfferSamples, requestContract, selectMarketCoordinateFiber, publicMarketOfferFields, publicX402RequestCommand, previewPublicMarketBasket } from "../../src/market/catalog.mjs";
import { validateJsonSchema } from "@red-cup-engineering/json-schema-services-section/validation";

const rows = {
  recordType:"x402.market-catalog/v1",
  offers:[
    { sku:"ni:1", listed:true, name:"Gas price", category:"chain",
      seller:{enterprise:"seller-a"}, compute:{package:"@owner/gas",export:"read"},
      gateway:"base", operation:"gas", route:"/v1/gas", description:"Market data" },
    { sku:"ni:2", listed:true, name:"Book quote", category:"publication",
      seller:{enterprise:"seller-b"}, compute:{package:"@owner/books",export:"read"},
      gateway:"books",operation:"book",route:"/v1/book",description:"Publication" },
    { sku:"ni:3", listed:false, name:"Private", category:"chain",
      seller:{enterprise:"seller-a"}, compute:{package:"@owner/gas",export:"read"},
      gateway:"base",operation:"private",route:"/private",description:"Internal" },
  ],
};
const policy={ defaultPageSize:1, maxPageSize:2, maxOffset:100000,
  maxQueryLength:200, maxTerms:12,
  exactMaxLength:{category:128,sellerEnterprise:256,producerPackage:256} };

test("one source-owned unsigned command renderer can be used by multiple buyer faces", () => {
  const example = { method: "POST", url: "https://seller.example/v1/compute",
    headers: { accept: "application/json", "content-type": "application/json" },
    body: { message: "it's $(not a shell command)" } };
  const command = publicX402RequestCommand(example);
  assert.match(command, /^curl --include --request POST /u);
  assert.match(command, /--data-raw/u);
  assert.match(command, /--url 'https:\/\/seller\.example\/v1\/compute'$/u);
  assert.ok(command.includes("'\\''"), "single quotes inside data are escaped, not evaluated");
  assert.equal(publicX402RequestCommand({ ...example, url: null }), null,
    "unresolved templated paths must not generate a misleading invocation");
});

test("one source-owned public offer projection retains identities without manufacturing payment or rights proof", () => {
  const row = { ...rows.offers[0], sku: "ni:qualified-source", listed: true,
    cell: "ni:original-cell", law: "ni:original-law", method: "POST",
    url: "https://seller.example/offer", price: "$0.02",
    sourceRightsClaim: { permission: "seller-alleges" },
    sourceRightsVerification: "verified", settlementVerified: true, paidDeliveryVerified: true,
  };
  const source = JSON.stringify(row);
  const publicFields = publicMarketOfferFields(row);
  assert.equal(publicFields.sku, "ni:qualified-source");
  assert.equal(publicFields.cell, "ni:original-cell");
  assert.equal(publicFields.law, "ni:original-law");
  assert.equal(publicFields.pricePreview, "$0.02");
  assert.equal(publicFields.sourceRightsVerification, "unassayed");
  assert.equal(publicFields.settlementVerified, false);
  assert.equal(publicFields.paidDeliveryVerified, false);
  assert.equal("sourceRightsClaim" in publicFields, false);
  assert.equal(Object.isFrozen(publicFields), true);
  assert.equal(JSON.stringify(row), source, "the original seller declaration is not rewritten");
  const another = publicMarketOfferFields({ ...row, sku: "ni:other",
    sourceRightsClaim: undefined, price: "$0.01" });
  assert.equal(another.sku, "ni:other");
  assert.equal(another.pricePreview, "$0.01");
  assert.equal(another.sourceRightsVerification, "not-declared");
});

test("public offer fields refuse non-public, identity-less and unadmitted seller records", () => {
  for (const row of [null, {}, [], rows.offers[2],
    { ...rows.offers[0], listed: false },
    { ...rows.offers[0], sku: "" },
    { ...rows.offers[0], sku: null }]) {
    assert.throws(() => publicMarketOfferFields(row), /source-listed seller SKU/);
  }
});

test("the first buyer and a different owner share the same source-ordered catalogue selection", () => {
  const first = select(rows,"list",{},policy);
  const second = select(rows,"list",{offset:first.nextOffset},policy);
  assert.equal(first.total,2);
  assert.deepEqual(first.offers.map(x=>x.sku),["ni:1"]);
  assert.deepEqual(second.offers.map(x=>x.sku),["ni:2"]);
  assert.equal(second.nextOffset,null);
  assert.ok(Object.isFrozen(first) && Object.isFrozen(first.offers));
});
test("literal term search and exact owner/package coordinates never turn synonyms into claimed identity",()=>{
  assert.deepEqual(select(rows,"search",{query:"gas base"},policy).offers.map(x=>x.sku),["ni:1"]);
  assert.deepEqual(select(rows,"search",{query:"",category:"chain",sellerEnterprise:"seller-a",
    producerPackage:"@owner/gas"},policy).offers.map(x=>x.sku),["ni:1"]);
  assert.equal(select(rows,"search",{query:"gas",sellerEnterprise:"seller-b"},policy).total,0);
  assert.equal(select(rows,"search",{query:"private"},policy).total,0);
});
test("the source-owned inspection retains detail but never returns a held or duplicate SKU",()=>{
  assert.equal(select(rows,"get",{sku:"ni:2"},policy),rows.offers[1]);
  assert.equal(select(rows,"get",{sku:"ni:3"},policy),null);
  assert.throws(()=>select({...rows,offers:[rows.offers[0],rows.offers[0]]},"get",{sku:"ni:1"},policy),/duplicate/i);
});
test("transport budgets are parameters, not a fixed global catalogue size",()=>{
  assert.equal(select(rows,"list",{limit:2},policy).offers.length,2);
  assert.throws(()=>select(rows,"list",{limit:3},policy),/outside/);
  assert.throws(()=>select(rows,"search",{query:"a b c",sellerEnterprise:42},
    {...policy,maxTerms:2}),/too many/);
  assert.throws(()=>select(rows,"search",{query:"",producerPackage:""},policy),/bounded/);
  assert.throws(()=>select(rows,"list",null,policy),/tool arguments/);
  assert.equal(select(rows,"list",{}).offers.length,2);
});

test("all public buyer operations refuse ambiguous or unaddressed saleable SKUs", () => {
  const duplicated = { ...rows, offers: [rows.offers[0], rows.offers[0], rows.offers[1]] };
  for (const mode of ["list", "search", "get"]) {
    const args = mode === "search" ? { query: "" } : mode === "get" ? { sku: "ni:1" } : {};
    assert.throws(() => select(duplicated, mode, args, policy), /duplicate catalog SKU/);
  }
  const anonymous = { ...rows, offers: [{ ...rows.offers[0], sku: null }] };
  assert.throws(() => select(anonymous, "list", {}, policy), /source SKU identities/);
  const privateRepeat = { ...rows, offers: [rows.offers[0], { ...rows.offers[0], listed: false }] };
  assert.equal(select(privateRepeat, "list", {}, policy).total, 1,
    "hidden historical declarations remain outside the buyer projection");
});


test("source-owned comparison of exact public SKUs retains requested order and original seller representations", () => {
  const reading = select(rows, "compare", { skus: ["ni:2", "ni:1"] },
    { maxComparedOffers: 8, maxSkuLength: 256 });
  assert.equal(reading.kind, "x402.market.offer-comparison.v1");
  assert.deepEqual(reading.requestedSkus, ["ni:2", "ni:1"]);
  assert.equal(reading.offers[0], rows.offers[1], "original addressed offer, not a fabricated clone");
  assert.equal(reading.offers[1], rows.offers[0]);
  assert.deepEqual(reading.missingSkus, []);
  assert.equal(Object.isFrozen(reading.offers), true);
  assert.match(reading.basis, /source-example admission is not operation equivalence/);
});

test("comparison cannot expose held/unlisted offers or invent unknown suppliers", () => {
  const reading = select(rows, "compare", { skus: ["ni:3", "ni:unknown", "ni:1"] },
    { maxComparedOffers: 8, maxSkuLength: 256 });
  assert.deepEqual(reading.offers.map(x => x.sku), ["ni:1"]);
  assert.deepEqual(reading.missingSkus, ["ni:3", "ni:unknown"]);
  assert.equal(reading.offers.some(x => x.listed === false), false);
  assert.throws(() => select({ ...rows, offers: [rows.offers[0], rows.offers[0]] },
    "compare", { skus: ["ni:1", "ni:2"] }), /duplicate catalog SKU/);
});

test("comparison rejects ambiguous and unbudgeted caller-selected sets", () => {
  const policy = { maxComparedOffers: 3, maxSkuLength: 20 };
  for (const skus of [
    ["ni:1"], ["ni:1", "ni:1"], ["ni:1", ""], ["ni:1", null],
    ["ni:1", "x".repeat(21)], ["ni:1", "ni:2", "ni:3", "ni:4"],
  ]) assert.throws(() => select(rows, "compare", { skus }, policy), /distinct, bounded, exact seller SKUs/);
  assert.throws(() => select(rows, "compare", { skus: "ni:1,ni:2" }, policy), /distinct, bounded, exact seller SKUs/);
  assert.throws(() => select(rows, "compare", null, policy), /tool arguments/);
});


test("exact price filters cannot mistake starting tariffs for a buyer's fixed price", () => {
  const readout = {
    ...rows,
    settlement: { network: "eip155:8453", asset: "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913" },
    offers: [
      { ...rows.offers[0], sku: "ni:cheap", amountAtomic: "1000", category: "data" },
      { ...rows.offers[1], sku: "ni:costly", amountAtomic: "20000", category: "data" },
      { ...rows.offers[0], sku: "ni:variable", amountAtomic: "100",
        pricing: { minimumAtomic: "100", mode: "canonical-json-byte-bands" } },
      { ...rows.offers[1], sku: "ni:unknown", amountAtomic: null },
      { ...rows.offers[0], sku: "ni:held", listed: false, amountAtomic: "1" },
    ],
  };
  assert.deepEqual(select(readout, "search", { query: "", maxFixedPriceAtomic: "1000" }).offers.map(row=>row.sku),
    ["ni:cheap"]);
  assert.deepEqual(select(readout, "search", { query: "", maxFixedPriceAtomic: "20000" }).offers.map(row=>row.sku),
    ["ni:cheap", "ni:costly"]);
  assert.equal(select(readout, "search", { query: "", maxFixedPriceAtomic: "0" }).total, 0);
  assert.deepEqual(select(readout, "search", { query: "gas", category: "data", maxFixedPriceAtomic: "1000" })
    .offers.map(row=>row.sku), ["ni:cheap"], "filter composes with existing literal discovery");
  assert.equal(readout.offers[2].amountAtomic, "100", "price filters never mutate the seller");
});

test("buyer search and coordinates share uint256 admission without treating overflow as a price", () => {
  const rail = { network: "eip155:8453", asset: "0x" + "ab".repeat(20) };
  const positive = { ...rows, recordType: "561-group.x402-market-catalog", settlement: rail,
    offers: [{ ...rows.offers[0], amountAtomic: "1000" },
      { ...rows.offers[1], amountAtomic: "9".repeat(78) }] };
  const ceiling = ((1n << 256n) - 1n).toString();
  assert.deepEqual(select(positive, "search", { query: "", maxFixedPriceAtomic: ceiling })
    .offers.map(o => o.sku), ["ni:1"]);
  assert.deepEqual(selectMarketCoordinateFiber(positive, { maxFixedPriceAtomic: ceiling })
    .offers.map(o => o.sku), ["ni:1"]);
  assert.throws(() => select(positive, "search", {
    query: "", maxFixedPriceAtomic: (1n << 256n).toString(),
  }), /canonical uint256/);
});

test("atomic budget search refuses missing settlement denomination and misleading price syntax", () => {
  const priced = { ...rows, settlement: { network: "eip155:8453", asset: "0x" + "ab".repeat(20) } };
  assert.throws(() => select(rows, "search", { query: "", maxFixedPriceAtomic: "1000" }),
    /requires source-qualified network and asset/);
  for (const val of [1, "-1", "01", "1.0", "1e9", "", "a", "0".repeat(2), "9".repeat(90)]) {
    assert.throws(() => select(priced, "search", { query: "", maxFixedPriceAtomic: val }),
      /canonical uint256 atomic amount/);
  }
  assert.throws(() => select(priced, "search", {
    query: "", maxFixedPriceAtomic: "9".repeat(78),
  }), /canonical uint256 atomic amount/, "uint256 overflow must not be silently accepted");
});

test("sample composition uses the original JSON Schema evaluator and exact public SKUs", () => {
  const report = {recordType: "561-group.x402-market-catalog", offers: [
    {
      sku: "ni:source", listed: true, method: "GET", name: "Measure metres",
      output: { schema: {type:"object",required:["amount","unit"],properties:{
        amount:{type:"integer"},unit:{const:"m"}}}, example: {amount:3,unit:"m"}},
      request:{}
    },
    {
      sku: "ni:consumer", listed: true, method: "POST", name: "Use metres",
      request: {bodySchema:{type:"object",required:["amount","unit"],properties:{
        amount:{type:"integer"},unit:{const:"m"}}}},
      output:{schema:{type:"object"},example:{accepted:true}},
    },
    {
      sku: "ni:km", listed: true, method: "POST", name: "Use kilometres",
      request: {bodySchema:{type:"object",required:["amount","unit"],properties:{
        amount:{type:"integer"},unit:{const:"km"}}}},
      output:{schema:{type:"object"},example:{accepted:true}},
    },
    {
      sku: "ni:held", listed: false, method:"POST", name:"Internal",
      request:{bodySchema:{type:"object"}},output:{schema:{type:"object"},example:{amount:3,unit:"m"}},
    },
  ]};
  const selected = select(report,"compare",{skus:["ni:source","ni:consumer","ni:km","ni:held"]},
    {maxComparedOffers:8,maxSamplePairs:56});
  assert.deepEqual(selected.offers.map(x=>x.sku), ["ni:source","ni:consumer","ni:km"]);
  assert.deepEqual(selected.missingSkus, ["ni:held"]);
  const relation = selected.sampleComposition;
  assert.equal(relation.kind, "x402.market.sample-composition-reading.v1");
  assert.equal(relation.totalDirectedPairs,6);
  assert.equal(relation.consideredPairs,6);
  assert.equal(relation.complete,true);
  assert.ok(relation.sampleRefusedPairs > 0, "different measurement units cannot be silently glued");
  assert.ok(relation.sampleAdmittedLinks.some(edge=>
    edge.from==="ni:source" && edge.to==="ni:consumer"
    && edge.evidenceLevel==="one-example-structural-only"
    && edge.executionAuthorized===false));
  assert.equal(relation.sampleAdmittedLinks.some(edge=>edge.to==="ni:km" && edge.from==="ni:source"),false);
  assert.equal(relation.sampleAdmittedLinks.some(edge=>edge.to==="ni:held" || edge.from==="ni:held"),false);
  assert.equal(relation.authorizesExecution,false);
});

test("original sample evaluation refuses invalid sources and reports unfinished budgets", () => {
  const a={sku:"a",method:"GET",output:{schema:{type:"string"},example:{value:4}}};
  const b={sku:"b",method:"POST",request:{bodySchema:{type:"object"}}};
  const bad=compareMarketOfferSamples([a,b],{maxSamplePairs:2});
  assert.deepEqual(bad.invalidOutputExampleSkus,["a"]);
  assert.deepEqual(bad.sampleAdmittedLinks,[]);
  assert.equal(bad.sampleUnassayedPairs,2);
  const partial=compareMarketOfferSamples([a,b],{maxSamplePairs:1});
  assert.equal(partial.complete,false);
  assert.equal(partial.consideredPairs,1);
  assert.equal(partial.unexaminedPairs,1);
  const none=compareMarketOfferSamples([a,b]);
  assert.equal(none.complete,false);
  assert.equal(none.unexaminedPairs,2);
  assert.throws(()=>compareMarketOfferSamples([a,b],{maxSamplePairs:-1}),/budget/);
  const invalidTarget=compareMarketOfferSamples([
    {sku:"x",method:"GET",output:{schema:{type:"object"},example:{good:true}}},
    {sku:"y",method:"POST",request:{bodySchema:{"$schema":"unsupported",type:"object",
      required:["good"],properties:{good:{type:"boolean"}}}}},
  ],{maxSamplePairs:2});
  assert.equal(invalidTarget.sampleAdmittedLinks.length,0);
  assert.deepEqual(invalidTarget.invalidTargetSchemaSkus,["y"]);
});

test("optional-only POST schemas cannot manufacture apparently useful workflow paths", () => {
  const source={
    sku:"source",method:"GET",
    output:{schema:{type:"object",required:["amount"],properties:{amount:{type:"integer"}}},
      example:{amount:7}},
  };
  const broad={sku:"broad-translate",method:"POST",
    request:{bodySchema:{properties:{text:{type:"string"}}}}};
  const result=compareMarketOfferSamples([source,broad],{maxSamplePairs:2});
  assert.equal(result.complete,true);
  assert.deepEqual(result.sampleAdmittedLinks,[]);
  assert.deepEqual(result.nonDiscriminatingInputSchemaSkus,["broad-translate"]);
  assert.equal(result.sampleUnassayedPairs,2);
  assert.equal(result.authorizesExecution,false);
  const actual={...broad,sku:"required-input",
    request:{bodySchema:{required:["amount"],properties:{amount:{type:"integer"}}}}};
  const repaired=compareMarketOfferSamples([source,actual],{maxSamplePairs:2});
  assert.deepEqual(repaired.nonDiscriminatingInputSchemaSkus,[]);
  assert.deepEqual(repaired.sampleAdmittedLinks.map(edge=>[edge.from,edge.to]),
    [["source","required-input"]]);
});

test("one original POST request contract exposes the same object admission as the live market", () => {
  const declaration = {
    method:"POST", route:"/v1/consumer",
    bodySchema:{required:["amount"],properties:{amount:{type:"integer"}}},
    bodyExample:{amount:5},
  };
  const original=JSON.stringify(declaration.bodySchema);
  const request=requestContract({declaration,probeUrl:"https://market.example/v1/consumer",
    mimeType:"application/json"});
  assert.equal(request.bodySchema.type,"object");
  assert.equal(JSON.stringify(declaration.bodySchema),original,"original declaration is not rewritten");
  assert.equal(validateJsonSchema({amount:5},request.bodySchema).valid,true);
  assert.equal(validateJsonSchema("held",request.bodySchema).valid,false,
    "required applies only to objects in standard JSON Schema; market admission supplies object type");
  const source={sku:"string-producer",method:"GET",
    output:{schema:{type:"string"},example:"held"}};
  const target={sku:"object-consumer",method:"POST",request};
  const comparison=compareMarketOfferSamples([source,target],{maxSamplePairs:2});
  assert.deepEqual(comparison.sampleAdmittedLinks,[]);
  assert.equal(comparison.sampleRefusedPairs,1,
    "unrelated string output is not admitted as an object request");
  assert.equal(comparison.authorizesExecution,false);
});

test("a trusted coordinate host can select real capacity beyond the first market's alpha profile", () => {
  const readout = {
    recordType: "561-group.x402-market-catalog",
    offers: Array.from({length: 25}, (_, i) => ({
      sku: "ni:source:" + i, listed: true, name: "Source " + i,
      gateway: "gateway-" + i, seller: { enterprise: "seller-" + i },
      category: "category-" + i, compute:{package:"@provider/" + i},
    })),
  };
  const output = selectMarketCoordinateFiber(readout, { limit:22 }, {
    maxPageSize:22, maxOffset:100001, maxFacetValues:22,
  });
  assert.equal(output.total,25);
  assert.equal(output.offers.length,22);
  assert.equal(output.nextOffset,22);
  assert.equal(output.facets.seller.values.length,22);
  assert.equal(output.facets.seller.truncated,true);
  assert.equal(selectMarketCoordinateFiber(readout, {offset:100001}, {
    maxOffset:100001,
  }).offers.length,0);
  const conservative = selectMarketCoordinateFiber(readout);
  assert.equal(conservative.offers.length,20);
  assert.equal(conservative.facets.seller.values.length,12);
  assert.throws(()=>selectMarketCoordinateFiber(readout,{limit:22},{
    maxPageSize:20,
  }),/budget exceeded/);
  assert.throws(()=>selectMarketCoordinateFiber(readout,{},{
    maxFacetValues:Infinity,
  }),/budget exceeded/);
});

test("an absent or held source coordinate reports an explicit not-found refusal", () => {
  const readout={recordType:"561-group.x402-market-catalog",offers:[
    {sku:"ni:present",listed:true,seller:{enterprise:"org"}},
    {sku:"ni:held",listed:false,seller:{enterprise:"org"}},
  ]};
  for (const near of ["ni:missing","ni:held"]) {
    assert.throws(()=>selectMarketCoordinateFiber(readout,{near}), error=>
      error instanceof TypeError && error.code === "MARKET_COORDINATE_NOT_FOUND");
  }
  assert.throws(()=>selectMarketCoordinateFiber(
    {...readout,recordType:"forged"},{near:"ni:present"}), error=>
    error instanceof TypeError && error.code !== "MARKET_COORDINATE_NOT_FOUND");
});


test("MCP and HTTP fibers reuse the same source-denominated fixed-price budget", () => {
  const rail = { network: "eip155:8453", asset: "0x" + "ab".repeat(20) };
  const fixed = { ...rows.offers[0], amountAtomic: "1000" };
  const sibling = { ...rows.offers[0], sku: "ni:cheap-sibling",
    amountAtomic: "2500", operation: "sibling" };
  const pricey = { ...rows.offers[1], amountAtomic: "9000" };
  const variable = { ...rows.offers[0], sku: "ni:variable", amountAtomic: "1",
    pricing: { mode: "request-dependent", minimumAtomic: "1" } };
  const unknown = { ...rows.offers[1], sku: "ni:unknown-price" };
  const catalog = { ...rows, recordType: "561-group.x402-market-catalog",
    settlement: rail, offers: [fixed, sibling, pricey, variable, unknown,
      { ...rows.offers[2], amountAtomic: "0" }] };
  const input = { maxFixedPriceAtomic: "2500" };
  const mcp = select(catalog, "search", { query: "", ...input });
  const http = selectMarketCoordinateFiber(catalog, input);
  assert.deepEqual(http.offers.map(row => row.sku),
    mcp.offers.map(row => row.sku));
  assert.deepEqual(http.offers.map(row => row.sku), ["ni:1", "ni:cheap-sibling"]);
  assert.equal(http.maxFixedPriceAtomic, "2500");
  assert.deepEqual(http.sourceSettlementRails, rail);
  assert.equal(selectMarketCoordinateFiber({ ...catalog, settlement: undefined })
    .sourceSettlementRails.asset, null, "missing denomination remains unknown");
  assert.equal(http.facets.category.values[0].count, 2);
  assert.equal(http.total, 2);
  assert.equal(http.nextOffset, null);
  assert.equal(http.offers.every(row => row.pricing === undefined), true);
  assert.deepEqual(selectMarketCoordinateFiber(catalog, {
    near: "ni:1", ...input,
  }).offers.map(row => row.sku), ["ni:cheap-sibling"]);
  assert.equal(selectMarketCoordinateFiber(catalog, {
    filters: { category: "publication" }, ...input,
  }).total, 0);
  assert.equal(selectMarketCoordinateFiber(catalog, {
    maxFixedPriceAtomic: "0",
  }).total, 0);
  assert.equal(selectMarketCoordinateFiber(catalog, {
    maxFixedPriceAtomic: "9000",
  }).total, 3);
  // An exact source read is unaltered by selecting a buyer's smaller fiber.
  assert.equal(catalog.offers[0].amountAtomic, "1000");
  assert.equal(selectMarketCoordinateFiber(catalog).total, 5);
});

test("atomic price budget refuses malformed and unqualified offers without replacing seller facts", () => {
  const catalog = { ...rows, recordType: "561-group.x402-market-catalog",
    settlement: { network: "eip155:8453", asset: "0x" + "ab".repeat(20) } };
  for (const amount of [0, -1, "01", "-1", "1.0", "1e2", "",
    "0".repeat(2), "9".repeat(78)]) {
    for (const read of [
      () => select(catalog, "search", { query: "", maxFixedPriceAtomic: amount }),
      () => selectMarketCoordinateFiber(catalog, { maxFixedPriceAtomic: amount }),
    ]) {
      assert.throws(read, error => error instanceof TypeError &&
        error.code === "MARKET_ATOMIC_CEILING_INVALID", String(amount));
    }
  }
  const unqualified = { ...catalog, settlement: undefined };
  for (const read of [
    () => select(unqualified, "search", { query: "", maxFixedPriceAtomic: "1000" }),
    () => selectMarketCoordinateFiber(unqualified, { maxFixedPriceAtomic: "1000" }),
  ]) assert.throws(read, /source-qualified network and asset/);
  const duplicate = { ...catalog, offers: [rows.offers[0], rows.offers[0]] };
  assert.throws(() => selectMarketCoordinateFiber(duplicate, {
    maxFixedPriceAtomic: "1000",
  }), /duplicate catalog SKU/);
  const privateAnchor = { ...catalog, offers: rows.offers };
  assert.throws(() => selectMarketCoordinateFiber(privateAnchor, {
    near: "ni:3", maxFixedPriceAtomic: "1000",
  }), /currently listed original seller SKU/);
});


const basketReadout = Object.freeze({
  recordType: "561-group.x402-market-catalog",
  settlement: Object.freeze({
    scheme: "exact", network: "eip155:8453",
    asset: "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913",
  }),
  offers: Object.freeze([
    { ...rows.offers[0], sku: "ni:first", method: "GET",
      url: "https://seller.example/first", amountAtomic: "1500",
      cell: "ni:first-cell", law: "ni:first-law",
      request: { example: { method: "GET", url: "https://seller.example/first" } } },
    { ...rows.offers[1], sku: "ni:second", method: "POST",
      url: "https://seller.example/second", amountAtomic: "2100" },
    { ...rows.offers[0], sku: "ni:variable", amountAtomic: "20",
      pricing: { mode: "request-dependent", minimumAtomic: "20" } },
    { ...rows.offers[1], sku: "ni:bad", amountAtomic: null },
    { ...rows.offers[2], sku: "ni:private", listed: false, amountAtomic: "1" },
  ]),
});
const basketPolicy = { maxItems: 8, maxTotalCalls: 100, maxSkuLength: 256 };
const selectedBasket = maximumTotalAtomic => previewPublicMarketBasket(basketReadout, {
  items: [{sku:"ni:first",calls:2},{sku:"ni:second",calls:1}],
  maximumTotalAtomic,
},basketPolicy);

test("one source-owned multi-call preview sums exact atomic units and preserves original source identity", () => {
  const r = selectedBasket("5100");
  assert.equal(r.kind, "x402.market.basket-preview.v1");
  assert.equal(r.complete, true);
  assert.equal(r.pricedSubtotalAtomic, "5100");
  assert.equal(r.advertisedTotalAtomic, "5100");
  assert.equal(r.withinAdvertisedCeiling, true);
  assert.equal(r.state, "within-advertised-ceiling");
  assert.deepEqual(r.lines.map(x=>x.extendedAmountAtomic), ["3000","2100"]);
  assert.deepEqual(r.lines.map(x=>x.sku), ["ni:first","ni:second"]);
  assert.equal(r.lines[0].cell, "ni:first-cell");
  assert.equal(r.lines[0].law, "ni:first-law");
  assert.deepEqual(r.lines[0].requestExample, {method:"GET",url:"https://seller.example/first"});
  assert.equal(r.paymentAuthorized,false);
  assert.equal(r.purchaseExecuted,false);
  assert.equal(r.deliveryReceived,false);
  assert.equal(r.concurrentExecutionProven,false);
  assert.equal(Object.isFrozen(r) && Object.isFrozen(r.lines) && Object.isFrozen(r.lines[0]),true);
  assert.equal(selectedBasket("5099").withinAdvertisedCeiling,false,
    "one atomic unit over a ceiling is not an eligible basket");
});

test("held, missing, variable and malformed prices never become cheap bundle costs", () => {
  const result = previewPublicMarketBasket(basketReadout, {
    items:[{sku:"ni:first",calls:1},{sku:"ni:variable",calls:1},
      {sku:"ni:bad",calls:1},{sku:"ni:private",calls:1},
      {sku:"ni:unknown",calls:1}],
    maximumTotalAtomic:"9999999",
  },basketPolicy);
  assert.equal(result.complete,false);
  assert.equal(result.withinAdvertisedCeiling,false);
  assert.equal(result.advertisedTotalAtomic,null);
  assert.equal(result.pricedSubtotalAtomic,"1500");
  assert.deepEqual(result.lines.map(x=>x.state), [
    "fixed-price-preview","not-fixed-price","not-fixed-price",
    "not-listed-or-unknown","not-listed-or-unknown"
  ]);
  assert.equal(JSON.stringify(result).includes("Private"),false);
  assert.equal(result.sourceSettlementRails.asset,basketReadout.settlement.asset);
  assert.equal(JSON.stringify(result).includes("payTo"),false);
});

test("one uint256 atomic-unit law and caller-owned finite computation bounds", () => {
  const huge=((1n<<256n)-1n).toString();
  const many={...basketReadout,offers:[{...basketReadout.offers[0],amountAtomic:huge}]};
  const r=previewPublicMarketBasket(many, {
    items:[{sku:"ni:first",calls:2}],maximumTotalAtomic:huge
  },basketPolicy);
  assert.equal(r.complete,true);
  assert.equal(r.pricedSubtotalAtomic, (2n*((1n<<256n)-1n)).toString());
  assert.equal(r.advertisedTotalAtomic,null);
  assert.equal(r.state,"total-outside-uint256");
  assert.equal(r.withinAdvertisedCeiling,false);
  const one=previewPublicMarketBasket(basketReadout,{
    items:[{sku:"ni:first",calls:1}],maximumTotalAtomic:"0"
  },basketPolicy);
  assert.equal(one.state,"exceeds-advertised-ceiling");
  assert.throws(()=>selectedBasket((1n<<256n).toString()),/canonical uint256/);
  assert.throws(()=>previewPublicMarketBasket({...basketReadout,settlement:{}},{
    items:[{sku:"ni:first",calls:1}],maximumTotalAtomic:"3000"
  },basketPolicy),/source-qualified network and asset/);
});

test("incorrect basket inputs and host budget limits refuse before advertising availability", () => {
  const malformed = [
    {items:[],maximumTotalAtomic:"5000"},
    {items:[{sku:"ni:first",calls:0}],maximumTotalAtomic:"5000"},
    {items:[{sku:"ni:first",calls:1},{sku:"ni:first",calls:1}],maximumTotalAtomic:"5000"},
    {items:[{sku:"ni:first",calls:1.5}],maximumTotalAtomic:"5000"},
    {items:[{sku:"ni:first",calls:101}],maximumTotalAtomic:"5000"},
    {items:[{sku:"ni:first",calls:1,owned:true}],maximumTotalAtomic:"5000"},
    {items:[{sku:"ni:first",calls:1}],maximumTotalAtomic:"01"},
    {items:[{sku:"ni:first",calls:1}],maximumTotalAtomic:"1.5"},
    {items:[{sku:"ni:first",calls:1}]},
  ];
  for(const args of malformed)assert.throws(
    ()=>previewPublicMarketBasket(basketReadout,args,basketPolicy), TypeError);
  assert.throws(()=>previewPublicMarketBasket({...basketReadout,offers:[
    basketReadout.offers[0],basketReadout.offers[0]
  ]},{items:[{sku:"ni:first",calls:1}],maximumTotalAtomic:"2000"},basketPolicy),
  /duplicate catalog SKU/);
  assert.throws(()=>previewPublicMarketBasket({recordType:"untrusted",offers:[]},{
    items:[{sku:"ni:first",calls:1}],maximumTotalAtomic:"2000"
  },basketPolicy),/original source-qualified/);
  const bigPolicy={maxItems:16,maxTotalCalls:1000,maxSkuLength:256};
  assert.equal(previewPublicMarketBasket(basketReadout, {
    items:[{sku:"ni:first",calls:101}],maximumTotalAtomic:"500000"
  },bigPolicy).withinAdvertisedCeiling,true,
    "an independent merchant's larger host budget is not a Networking-global rejection");
});
