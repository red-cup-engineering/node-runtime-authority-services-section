/** Relating owns this unit (the morphisms of its relational category); the engine re-exports it. */
export * from "@red-cup-engineering/relating/operation";
