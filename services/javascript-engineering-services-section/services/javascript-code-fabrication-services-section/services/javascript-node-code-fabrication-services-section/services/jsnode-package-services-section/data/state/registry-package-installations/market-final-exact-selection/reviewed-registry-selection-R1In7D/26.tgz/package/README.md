# JSNode package vulnerability triage services section

<!-- 561-group-standards:badges:start -->
[![Red Cup Engineering](https://img.shields.io/badge/561%20Group-Red%20Cup%20Engineering-c0392b)](https://github.com/red-cup-engineering)
[![License: MIT](https://img.shields.io/badge/license-MIT-c0392b)](LICENSE)
[![Indigenous data: CARE](https://img.shields.io/badge/Indigenous%20data-CARE-4b6f44)](https://github.com/red-cup-engineering/.github/blob/main/GOVERNANCE.md)
[![Tips welcome](https://img.shields.io/badge/tips-welcome-d4a017)](https://github.com/561-group/.github/blob/main/TIPS.md)
<!-- 561-group-standards:badges:end -->

Deterministic scoring core for the orphan-patch harvester (561-group
finance-operations note "The witnessed record as the product", section
"The orphan-patch harvester"): given public advisory, maintainer-activity,
and dependent-count data, it emits a ranked list of orphaned, depended-upon,
vulnerable package candidates. No network, no fork, no publish, no keys —
those are later, separate effects this package does not perform.

`src/orphan-patch-scoring.mjs` carries the pure scoring algebra;
`scripts/score-set-of-orphan-patch-candidates.mjs` is the one-effect
operation (stdin JSON in, stdout JSON out); `data/records/schema/` carries
the input and output JSON Schemas.

## Actual CVE applicability from an npm project or its dependencies

The `./scan-repository-cves` export accepts **exactly one** input-source
carrier: a complete frozen npm package-lock v2/v3, an array of exact npm
name/version pairs, or a public GitHub repository at a 40-character immutable
commit and package-lock.json path. A request with two competing carriers
(including an empty or null second carrier) is refused by the **same source
selection** in pre-payment admission, direct inventory extraction and actual
OSV-backed computation, before any upstream source call. It never silently
chooses the first input in a report about the other input. The caller does
not need to supply any advisories.

It resolves the locked npm release identities, queries OSV's live version-matching
API in bounded batches, retrieves full advisories, joins OSV/GHSA/CVE identifiers,
and gives every match the exact installed version and lockfile location. Root
dependency paths are reported only when the lockfile's dependency declarations
prove them. For each installed location, `dependencyPaths` preserves up to eight
version-bearing root-to-component paths and the declaration kind of each edge;
`rootDependencies` separately retains **all** reachable top-level source
dependencies, including those beyond the illustrative path limit. This matters
when multiple direct dependencies bring in the same vulnerable package.
Supplying only an exact name/version list produces **no fabricated root path**.

The output includes candidate fixed versions from advisory records;
it does **not** assert that changing a version is safe for the whole application
or that package presence proves exploitability. A missing package identity or
unresolved workspace is a coverage gap, not a clean security bill.

```js
import { scanRepositoryCves, diffCveFindings } from "@red-cup-engineering/jsnode-package-vulnerability-triage-services-section/scan-repository-cves";

// Direct public-advisory lookups for a customer's exact dependency versions.
const current = await scanRepositoryCves({
  dependencies: [{ name: "lodash", version: "4.17.20" }]
});
// Full report also accepts { packageLock: <parsed package-lock.json> }.
// To scan an immutable public GitHub revision instead:
// { github: { owner: "example", repo: "app", commit: "<40-hex-SHA>", path: "package-lock.json" } }
const changes = diffCveFindings(previousReport, current);
```

For someone holding a local npm lockfile, the read-only command
`scan-repository-cves ./package-lock.json` emits a full JSON report.
No package install, checkout, lifecycle scripts, login or repository write is
performed. Cloud/runtime consumers can inject `fetchImplementation`, which
uses the same original OSV source interfaces.

**Honest scope:** npm lockfile versions 2/3, up to 512 locked distinct releases
and 40 distinct matched advisories per bounded query. For a larger estate,
partition the submitted inventory into scoped calls and combine their exact
source-qualified responses in the consuming customer service; never mistake
one bounded response for a complete estate assessment. Public GitHub mode
accepts pinned source only and requires its lockfile to be publicly readable.
The OSV batch reader follows each original package's independent page token,
up to five bounded continuation rounds, and retrieves full source records in
five-concurrent-request batches. Malformed or incomplete pages, missing
required npm dependencies, non-registry Git/file package sources, source
failure, or an exceeded advisory budget refuse a complete bill rather than
manufacturing a negative finding. Absent *optional* peer packages are not
missing required releases; a package's own development dependencies are not
invented as installed downstream dependencies.

`coverage.complete` denotes completeness **within the submitted dependency
inventory and queried OSV version corpus**, not all vulnerabilities or actual
runtime code reachability. `coverage.pathEvidenceComplete` is separate:
a report may match every release while some explanatory root paths are bounded
(`graphPathsTruncated`), or an actual installation edge is unresolved.
Neither flag certifies application exploitability, patch compatibility or a
complete census of all known and unknown vulnerabilities.

On a public GitHub source request the exact pinned revision is preserved; for
raw exact package versions no dependency graph is assumed. Security claims and
permitted disclosures remain subject to the original source and owner.

The original `score-set-of-orphan-patch-candidates` package operation is
unchanged. It selects orphan repair opportunities from caller-supplied rows;
it is not a repository vulnerability scanner.

OSV record identifiers follow the published OSV 1.9.2 source-character
grammar, including legitimate record IDs containing a colon or period. The
one shared validator serves both matched-repository lookups and public
advisory assembly; its 512-character maximum is this service's bounded
request policy, not a restriction imposed by OSV.

## Assembling and propagating public advisories

`assemblePublicAdvisories({ ids: ["GHSA-…", ...] })` on the
`./assemble-public-advisories` export now obtains 1–8 original **public**
OSV records, builds a revisioned dossier with each source ID, modified
timestamp, CVE/GHSA alias index, affected package/version ranges, references
and withdrawal status. It does not manufacture an official CVE record, a
new CVE identifier, or an assertion that two different source descriptions
have been legally reconciled.

`diffPublicAdvisories(previousDossier, currentDossier)` reports public
new/updated/withdrawn records with stable identifiers, while
`diffCveFindings(previousScan, currentScan)` reports changes to a buyer's
version-specific affected components. These are the reusable computation
suppliers for a downstream opted-in distribution service; they do not
themselves send unsolicited alerts, open GitHub issues or publish embargoed
information. The public merchant/contract determines payment and rights,
and Coesite/Causeway determine authorized recipient channels.

## Source-bound CVE change sets

For a **change in the same software inventory**, use
`deriveCveChangeSet(previousScan, currentScan)` from the existing
`./scan-repository-cves` export. It returns a versioned result with one
shared source identity, the provenance assurance, the previous/current coverage
and the actual added, modified or no-longer-observed package/advisory events.

A change set requires either:

- Two pinned public GitHub `package-lock.json` scans naming the **same**
  `owner/repo` and relative lockfile path (their commit SHA may differ).
- Two caller-provided npm lockfiles or exact dependency lists scanned with the
  **same explicit `scope` string**, for example `scope: "project-one"`.
  This identifier is **caller-asserted**, not cryptographically verified or
  a claim that the Group had access to a private repository.

The source-affinity check runs in the original `admitCveDiffRequest`
pre-payment operation and the deriving function. It rejects cross-repository,
mixed-kind and mismatched-scope comparisons instead of selling a fictitious
remediation. Anonymous unscoped reports can still be examined individually;
the original `diffCveFindings` preserves its legacy pure event read but
**will not report any removal without a shared source identity**.

The change-set response states whether the previous and current inventories
are complete, whether removal observations are admissible, and whether the
current dependency-root explanations are bounded or incomplete. A package
disappearing from a source-qualified dependency inventory is **not** a
certification of remediation, exploitability or safety. Customers must qualify
upgrades and actual runtime usage separately. The original recurring Group
public-intelligence workflow already carries pinned GitHub source identity,
so it can continue through this same operation without a second event ledger.

## Have a public repository scanned

[Request a free, real OSV/CVE scan of your pinned public repository or exact npm dependencies](https://github.com/red-cup-engineering/jsnode-package-vulnerability-triage-engineering-services-section/issues/new?template=public-cve-scan.yml).

The public issue form accepts **just a public GitHub repository URL**, an optional
npm package-lock.json path, or newline-separated exact name@version npm
dependencies. When no SHA is provided, the worker resolves the public default
branch to its immutable Git commit before reading the lockfile. An explicitly
supplied 40-character commit SHA remains supported for reproducible auditing. On submission, the repository's GitHub Actions
job invokes the already-released source scanning operation; it reads the public
lockfile, queries OSV by actual package and version, and comments on the issue
with linked vulnerabilities and fix candidates. The complete machine-readable
JSON result is attached to the Actions run. No customer's repository is
checked out, installed, tested, or modified. Results and requested dependencies
are **public**. Do not submit confidential inputs, credentials or embargoed
advisories. An unsuccessful scan is a refusal, never a clean bill of health.

This free, opt-in entrance is not a payment or retained monitoring contract.
The Group's original public seller has the three added product declarations
for CVE applicability, public advisory dossiers and change propagation.
Until the actual Market supplier release, catalog compilation, deployment,
and useful paid response are received, those routes are **not advertised as
live checkouts**. For contracted audits, monitored estates and coordinated
disclosures use the [original Group customer Work intake](https://561.group/work/).

### Have public advisories assembled

[Request a free, versioned public CVE/GHSA advisory dossier](https://github.com/red-cup-engineering/jsnode-package-vulnerability-triage-engineering-services-section/issues/new?template=public-cve-dossier.yml).
Supply up to eight existing public OSV/GHSA advisory identifiers. The same
working GitHub issue-to-report channel retrieves their **current public source
records**, assembles CVE aliases and affected products, and returns a dated
response with complete JSON version ranges and references. This does not
assign CVE numbers or accept unpublished/embargoed findings.

Actual seller transactions for this and recurring propagation continue to
depend on the existing Market's independently received runtime/registry,
not on the existence of this free inquiry.
