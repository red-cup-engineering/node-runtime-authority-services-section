import { isOsvRecordId } from "./osv-record-identity.mjs";

/**
 * Read-only package-lock / exact-dependency -> OSV applicability.
 * Original data suppliers: npm's installed lock tree and OSV's public, version-aware API.
 * No package install, repository checkout, shell, credentials, issue creation or publication.
 */
const MAX_PACKAGES = 512;
const MAX_ADVISORIES = 40;
const MAX_BYTES = 4_000_000;
const FIELDS = ["dependencies", "optionalDependencies", "devDependencies", "peerDependencies"];
const NPM_NAME_PART = /^[a-z0-9][a-z0-9._-]*$/iu;
function validNpmName(name) {
  if (typeof name !== "string") return false;
  const parts = name.split("/");
  return parts.length === 1 ? NPM_NAME_PART.test(parts[0]) :
    parts.length === 2 && parts[0].startsWith("@") &&
    NPM_NAME_PART.test(parts[0].slice(1)) && NPM_NAME_PART.test(parts[1]);
}
const COMMIT = /^[0-9a-f]{40}$/iu;
const SAFE_SEGMENT = /^[a-z0-9][a-z0-9._-]*$/iu;
const CVE = /^CVE-[0-9]{4}-[0-9]{4,}$/u;
const NPM_VERSION = /^[0-9]+\.[0-9]+\.[0-9]+(?:[-+][0-9A-Za-z.-]+)?$/u;

function object(value, name) {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new TypeError(`${name} must be an object`);
  return value;
}

/**
 * One customer job selects precisely one input *source*. Counting explicit
 * keys (rather than truthy values) makes null, empty arrays and competing
 * inventory carriers unable to silently change the assessed software.
 * Keep this rule shared by the pre-payment gate and the real OSV reader.
 */
function selectedCveInputSource(input) {
  object(input, "scan request");
  const sources = ["github", "packageLock", "dependencies"]
    .filter(key => Object.hasOwn(input, key));
  if (sources.length !== 1)
    throw new TypeError("CVE scan requires exactly one source: github, packageLock, or dependencies");
  return sources[0];
}
/**
 * Public GitHub snapshots are comparable across commits of the SAME
 * repository and lockfile path. Customer-uploaded snapshots can name their
 * own stable scope, but that name is a caller assertion, not an attestation.
 */
const CUSTOMER_SCOPE = /^[A-Za-z0-9][A-Za-z0-9._:/@-]{0,255}$/u;
function readCveRequestScope(request, kind) {
  if (!Object.hasOwn(request, "scope")) return null;
  if (kind === "github")
    throw new TypeError("a pinned public GitHub repository supplies its own source scope; do not override it");
  if (typeof request.scope !== "string" || !CUSTOMER_SCOPE.test(request.scope))
    throw new TypeError("scope must be one bounded, nonsecret customer-held inventory identifier");
  return request.scope;
}
function declaredCveReportSource(kind, source, scope) {
  return source ? {
    kind: "public-github-commit",
    repository: source.owner + "/" + source.repo,
    commit: source.commit,
    path: source.path
  } : {
    kind: kind === "dependencies" ? "exact-dependencies" : "npm-lockfile",
    ...(scope === null ? {} : { scope, scopeAssurance: "caller-declared" })
  };
}
function cveSourceScope(source) {
  if (!source || typeof source !== "object" || Array.isArray(source)) return null;
  if (source.kind === "public-github-commit") {
    const name = source.repository, path = source.path;
    if (typeof name !== "string" || !/^[a-z0-9._-]+\/[a-z0-9._-]+$/iu.test(name) ||
        typeof path !== "string" || !path.endsWith("package-lock.json") ||
        path.split("/").some(segment => !SAFE_SEGMENT.test(segment)) ||
        typeof source.commit !== "string" || !COMMIT.test(source.commit))
      throw new TypeError("CVE change comparison needs original pinned GitHub repository, relative lockfile path and exact commit");
    return { identity: "github:" + name.toLowerCase() + "/" + path,
      assurance: "matching-caller-supplied-pinned-repository-identities" };
  }
  if (source.kind === "exact-dependencies" || source.kind === "npm-lockfile") {
    if (source.scope === undefined) return null;
    if (typeof source.scope !== "string" || !CUSTOMER_SCOPE.test(source.scope))
      throw new TypeError("CVE change comparison contains an invalid declared inventory scope");
    return { identity: source.kind + ":" + source.scope,
      assurance: "matching-caller-declared-inventory-scopes" };
  }
  return null;
}
function compareCveSourceScopes(previous, current) {
  const oldScope = cveSourceScope(previous?.source);
  const newScope = cveSourceScope(current?.source);
  if (oldScope && newScope) {
    if (oldScope.identity !== newScope.identity)
      throw new TypeError("CVE change comparison crosses different software sources; refusing false remediation or impact propagation");
    return { qualified: true, ...newScope };
  }
  return { qualified: false, identity: null,
    assurance: "unqualified: no stable shared repository or caller-declared inventory scope" };
}
function validateCveChangeReport(value, label) {
  object(value, label);
  if (!Array.isArray(value.findings) || value.findings.length > 1024 ||
      !value.coverage || typeof value.coverage.complete !== "boolean")
    throw new TypeError(label + " must carry at most 1024 findings and explicit coverage.complete");
  for (const finding of value.findings) {
    if (!finding || typeof finding.component?.name !== "string" ||
        typeof finding.component?.version !== "string" ||
        typeof finding.advisory?.id !== "string")
      throw new TypeError(label + " has a finding without npm component and advisory identities");
  }
  return value;
}
function nameFromLocation(location) {
  const parts = location.split("/");
  const i = parts.lastIndexOf("node_modules");
  if (i < 0 || i + 1 >= parts.length) return null;
  const name = parts[i + 1]?.startsWith("@") ? parts.slice(i + 1, i + 3).join("/") : parts[i + 1];
  return validNpmName(name ?? "") ? name : null;
}
function locationCandidates(parent, name) {
  const candidates = [];
  let base = parent;
  for (;;) {
    candidates.push(base ? `${base}/node_modules/${name}` : `node_modules/${name}`);
    if (!base) break;
    const prefix = base.lastIndexOf("/node_modules/");
    base = prefix < 0 ? "" : base.slice(0, prefix);
  }
  return candidates;
}
function normalizeEntry({ name, version, location, path = null, direct = null }) {
  if (typeof name !== "string" || !validNpmName(name) || typeof version !== "string" ||
      !NPM_VERSION.test(version) || version.length > 128) {
    throw new TypeError(`unresolved or invalid package: ${String(name)}@${String(version)}`);
  }
  return { name, version, location, dependencyPath: path, direct };
}
/**
 * Enumerate actual versioned npm releases, not ranges in package.json.
 * Package-lock v2/v3 identifies installed instances by packages[] locations.
 * The BFS follows each record's declared dependencies through npm's ancestor
 * module-resolution locations to distinguish witnessed paths from unknown ones.
 */
const MAX_LOCK_LOCATIONS = 1024;
const MAX_GRAPH_PATHS_PER_LOCATION = 8;
const MAX_GRAPH_PATH_DEPTH = 48;

function isNonRegistrySource(resolved) {
  return typeof resolved === "string" &&
    /^(?:git(?:\+|:)|ssh:|file:|link:|github:|https?:\/\/(?:github\.com|codeload\.github\.com)\/)/iu.test(resolved);
}

/**
 * Interpret actual npm lockfile installation *locations*, not version ranges
 * or package-name lookups. Peer and optional edges remain identifiable; a
 * package's own development dependencies are NOT installed for consumers.
 * A lock records one tree with possibly several incoming dependency edges.
 */
export function installedNpmPackages(input) {
  const kind = selectedCveInputSource(input);
  if (kind === "github") throw new TypeError("remote GitHub input must be pinned and fetched before reading an npm inventory");
  if (kind === "dependencies") {
    if (input.dependencies.length === 0 || input.dependencies.length > MAX_PACKAGES)
      throw new RangeError("explicit dependencies must contain between 1 and 512 exact releases");
    return {
      mode: "exact-dependencies",
      packages: input.dependencies.map((item, i) => {
        object(item, "dependencies[" + i + "]");
        return normalizeEntry({ name: item.name, version: item.version,
          location: item.location ?? null, path: null, direct: null });
      }),
      gaps: [], graphPathsTruncated: 0,
    };
  }

  const lock = object(input.packageLock, "packageLock");
  if (![2, 3].includes(lock.lockfileVersion) || !lock.packages ||
      typeof lock.packages !== "object" || Array.isArray(lock.packages)) {
    throw new TypeError("a complete npm package-lock v2/v3 with packages is required; package.json ranges are not installed versions");
  }
  const lockEntries = Object.entries(lock.packages);
  if (lockEntries.length > MAX_LOCK_LOCATIONS + 1)
    throw new RangeError("npm lock contains over 1024 installation records; select a smaller locked project");
  const packages = new Map(lockEntries);
  if (!packages.has("")) throw new TypeError("npm lockfile has no root package record");
  const root = object(packages.get(""), "lockfile root");
  const gaps = new Map(), truncated = new Set();
  const addGap = (key, reason) => {
    if (!gaps.has(key)) gaps.set(key, { location: key, reason });
  };

  const initialTrail = { location: "", locations: [""], segments: [], relations: [] };
  const trails = new Map([["", [initialTrail]]]);
  // Keep every valid parent/child edge even when an illustrative path has
  // already reached its eight-explanation limit.
  const outgoing = new Map();
  const queue = [initialTrail];
  for (let cursor = 0; cursor < queue.length; cursor++) {
    const trail = queue[cursor], location = trail.location;
    const entry = packages.get(location);
    if (!entry || typeof entry !== "object" || Array.isArray(entry)) {
      addGap(location, "dependency tree contains a malformed installed-package record");
      continue;
    }
    if (trail.segments.length >= MAX_GRAPH_PATH_DEPTH) {
      truncated.add(location);
      continue;
    }
    for (const field of FIELDS) {
      // Dependency manifests from registry packages list their own development
      // dependencies but npm does not install those for their consumers.
      if (field === "devDependencies" && location !== "") continue;
      if (entry[field] === undefined) continue;
      const requests = entry[field];
      if (!requests || typeof requests !== "object" || Array.isArray(requests)) {
        addGap(location + "#" + field, "dependency declarations are not a name-to-range object");
        continue;
      }
      for (const requestedAs of Object.keys(requests).sort()) {
        if (!validNpmName(requestedAs)) {
          addGap(location + "#" + field + "/" + requestedAs, "invalid npm dependency name");
          continue;
        }
        const target = locationCandidates(location, requestedAs).find(path => packages.has(path));
        if (!target) {
          const omittedOptional = field === "optionalDependencies" ||
            (field === "peerDependencies" && entry.peerDependenciesMeta?.[requestedAs]?.optional === true);
          if (!omittedOptional) {
            addGap(location + "#" + field + "/" + requestedAs,
              "declared required dependency has no resolved installation location");
          }
          continue;
        }
        const child = packages.get(target);
        if (!child || typeof child !== "object" || Array.isArray(child) || child.link) {
          addGap(target, "dependency resolves to a linked or malformed installation, not a versioned npm release");
          continue;
        }
        if (isNonRegistrySource(child.resolved)) {
          addGap(target, "non-registry source cannot be certified as the npm release named in this lockfile");
          continue;
        }
        const name = child.name ?? nameFromLocation(target);
        if (!validNpmName(name) || typeof child.version !== "string" || !NPM_VERSION.test(child.version)) {
          addGap(target, "dependency resolution lacks an exact npm component name or version");
          continue;
        }
        const edges = outgoing.get(location) ?? new Map();
        edges.set(target + "#" + field + "#" + requestedAs, { target, field, requestedAs });
        outgoing.set(location, edges);
        if (trail.locations.includes(target)) continue; // peer cycles are not fresh paths
        const next = {
          location: target, locations: [...trail.locations, target],
          segments: [...trail.segments, name + "@" + child.version],
          relations: [...trail.relations, field],
        };
        const previous = trails.get(target) ?? [];
        if (previous.some(path =>
          path.locations.length === next.locations.length &&
          path.locations.every((position, i) => position === next.locations[i]) &&
          path.relations.every((relation, i) => relation === next.relations[i]))) continue;
        if (previous.length >= MAX_GRAPH_PATHS_PER_LOCATION) {
          truncated.add(target);
          continue;
        }
        previous.push(next);
        trails.set(target, previous);
        queue.push(next);
      }
    }
  }

  // Compute the complete set of *direct customer dependencies* that reach
  // each installed package. This monotone location-graph traversal does not
  // discard impacted owners when path samples hit their explanation cap.
  const rootOwners = new Map(), frontier = [];
  const addOwner = (location, root) => {
    const owners = rootOwners.get(location) ?? new Map();
    const key = root.requestedAs + "@" + root.version + "#" + root.kind;
    if (owners.has(key)) return;
    owners.set(key, root);
    rootOwners.set(location, owners);
    frontier.push({ location, root });
  };
  for (const edge of (outgoing.get("") ?? new Map()).values()) {
    const installed = packages.get(edge.target);
    addOwner(edge.target, { requestedAs: edge.requestedAs,
      name: installed.name ?? nameFromLocation(edge.target),
      version: installed.version, kind: edge.field });
  }
  for (let cursor = 0; cursor < frontier.length; cursor++) {
    const { location, root } = frontier[cursor];
    for (const edge of (outgoing.get(location) ?? new Map()).values())
      addOwner(edge.target, root);
  }

  const output = [];
  for (const [location, raw] of lockEntries) {
    if (location === "") continue;
    const entry = object(raw, "packages[" + location + "]");
    if (entry.link) {
      addGap(location, "symlink/workspace installation needs a resolved target");
      continue;
    }
    const name = entry.name ?? nameFromLocation(location);
    if (!validNpmName(name) || typeof entry.version !== "string" || !NPM_VERSION.test(entry.version)) {
      addGap(location, "package identity or exact npm release version is missing");
      continue;
    }
    // A Git source can claim the same package name/version as an npm release
    // without containing its bytes. It cannot be called an applicable npm
    // advisory solely because the version happens to match.
    if (isNonRegistrySource(entry.resolved)) {
      addGap(location, "non-registry source: package version alone does not establish npm release identity");
      continue;
    }
    const allPaths = trails.get(location) ?? [];
    if (!allPaths.length)
      addGap(location, "no dependency path from the lockfile root establishes this installation");
    const pathOptions = allPaths.map(trail => ({
      path: trail.segments, kinds: trail.relations,
    }));
    const primary = pathOptions[0] ?? null;
    const row = normalizeEntry({
      name, version: entry.version, location,
      path: primary?.path ?? null,
      direct: pathOptions.length ? pathOptions.some(option => option.path.length === 1) : null,
    });
    row.dependencyKinds = primary?.kinds ?? null;
    row.dependencyPaths = pathOptions;
    row.pathsTruncated = truncated.has(location);
    row.rootDependencies = [...(rootOwners.get(location)?.values() ?? [])]
      .sort((a, b) => a.requestedAs.localeCompare(b.requestedAs) ||
        a.version.localeCompare(b.version) || a.kind.localeCompare(b.kind));
    output.push(row);
  }
  if (!output.length || output.length > MAX_PACKAGES)
    throw new RangeError("lockfile has zero or more than 512 resolved npm releases; submit a bounded project or exact dependency set");
  output.sort((a, b) => a.location.localeCompare(b.location));
  return {
    mode: "npm-lockfile", packages: output, rootName: root.name ?? lock.name ?? null,
    gaps: [...gaps.values()].sort((a, b) => a.location.localeCompare(b.location)),
    graphPathsTruncated: [...truncated].filter(location => location !== "").length,
    pathExplanationLimit: MAX_GRAPH_PATHS_PER_LOCATION,
  };
}

function admittedGitHubSource(value) {
  const source = object(value, "github");
  const owner = source.owner, repo = source.repo;
  const commit = source.commit, path = source.path ?? "package-lock.json";
  if (!SAFE_SEGMENT.test(owner ?? "") || !SAFE_SEGMENT.test(repo ?? "") || !COMMIT.test(commit ?? "") ||
      typeof path !== "string" || !path.endsWith("package-lock.json") ||
      path.split("/").some(part => !SAFE_SEGMENT.test(part))) {
    throw new TypeError("github requires a public owner/repo, exact 40-hex commit and safe package-lock.json path");
  }
  return { owner, repo, commit: commit.toLowerCase(), path,
    url: `https://raw.githubusercontent.com/${owner}/${repo}/${commit}/${path}` };
}
async function responseJson(response, source) {
  if (!response?.ok) throw new Error(`${source}: upstream returned HTTP ${response?.status ?? "unknown"}`);
  return response.json();
}
async function fetchPublicLock(source, fetchImplementation) {
  const response = await fetchImplementation(source.url, { headers: { Accept: "application/json" },
    signal: AbortSignal.timeout(12_000) });
  if (!response.ok) throw new Error(`public GitHub lockfile unavailable: HTTP ${response.status}`);
  const data = await response.text();
  if (data.length > MAX_BYTES) throw new RangeError("public GitHub lockfile exceeds 4 MB");
  try { return JSON.parse(data); } catch { throw new TypeError("public GitHub lockfile did not contain JSON"); }
}
/**
 * One authoritatively selected source plan serves admission and computation.
 * A previous snapshot requesting a changed-state response must already name
 * the SAME software subject before any GitHub/OSV network request begins.
 */
function cveScanPlan(request) {
  const kind = selectedCveInputSource(request);
  const source = kind === "github" ? admittedGitHubSource(request.github) : null;
  const scope = readCveRequestScope(request, kind);
  const declaration = declaredCveReportSource(kind, source, scope);
  if (request.previousScan !== undefined) {
    validateCveChangeReport(request.previousScan, "previousScan");
    const agreement = compareCveSourceScopes(request.previousScan, { source: declaration });
    if (!agreement.qualified)
      throw new TypeError("a revision comparison needs the same pinned public repository or explicitly scoped inventory");
  }
  return { kind, source, scope, declaration };
}
/** Pre-payment admission never chooses one of several competing inventories. */
export function admitCveScanRequest(request) {
  const plan = cveScanPlan(request);
  if (!plan.source) installedNpmPackages(request);
  return true;
}
/** Admission for the independently sold, source-affine CVE change-set job. */
export function admitCveDiffRequest(request) {
  object(request, "change-set request");
  validateCveChangeReport(request.previousScan, "previousScan");
  validateCveChangeReport(request.currentScan, "currentScan");
  const comparison = compareCveSourceScopes(request.previousScan, request.currentScan);
  if (!comparison.qualified)
    throw new TypeError("a paid CVE change set requires a single identifiable software subject across both scans");
  return true;
}
function dedupePackageVersions(packages) {
  const map = new Map();
  for (const pkg of packages) {
    const key = `npm:${pkg.name}@${pkg.version}`;
    const entry = map.get(key) ?? { name: pkg.name, version: pkg.version, instances: [] };
    entry.instances.push({ location: pkg.location, dependencyPath: pkg.dependencyPath, direct: pkg.direct,
      dependencyKinds: pkg.dependencyKinds ?? null,
      dependencyPaths: pkg.dependencyPaths ?? [],
      rootDependencies: pkg.rootDependencies ?? [],
      pathsTruncated: pkg.pathsTruncated === true });
    map.set(key, entry);
  }
  for (const item of map.values()) item.instances.sort((a, b) =>
    String(a.location ?? "").localeCompare(String(b.location ?? "")));
  if (map.size > MAX_PACKAGES) throw new RangeError("too many unique versions");
  return [...map.values()];
}
/**
 * Query OSV's actual batch contract. Its result positions match the input,
 * but continuation tokens belong to individual positions, NOT the batch.
 * Retain the original component identity while re-querying only unfinished
 * positions. A missing page or source failure must not become a clean result.
 */
async function queryOsv(installed, fetchImplementation) {
  const rows = installed.map(component => ({ component, matches: [] }));
  const globallyObserved = new Set();
  for (let start = 0; start < rows.length; start += 128) {
    let pending = rows.slice(start, start + 128).map(row => ({
      row, pageToken: null, pageTokens: new Set(), advisoryIds: new Set(),
    }));
    let page = 0;
    while (pending.length) {
      if (page++ >= 5) throw new Error("OSV batch exceeded five bounded page rounds; source coverage is unknown");
      const queries = pending.map(({ row, pageToken }) => ({
        package: { ecosystem: "npm", name: row.component.name },
        version: row.component.version,
        ...(pageToken ? { page_token: pageToken } : {}),
      }));
      const response = await fetchImplementation("https://api.osv.dev/v1/querybatch", {
        method: "POST", headers: { "content-type": "application/json" },
        body: JSON.stringify({ queries }), signal: AbortSignal.timeout(20_000),
      });
      const result = await responseJson(response, "OSV querybatch");
      if (!Array.isArray(result?.results) || result.results.length !== pending.length)
        throw new Error("OSV returned incomplete batch positions; source coverage is unknown");
      const continuation = [];
      for (let i = 0; i < pending.length; i++) {
        const state = pending[i], match = result.results[i];
        if (!match || typeof match !== "object" || Array.isArray(match) ||
            (match.vulns !== undefined && !Array.isArray(match.vulns))) {
          throw new Error("OSV returned malformed vulnerability results; source coverage is unknown");
        }
        for (const advisory of match.vulns ?? []) {
          if (!isOsvRecordId(advisory?.id))
            throw new Error("OSV returned a vulnerability without a valid record identity");
          if (state.advisoryIds.has(advisory.id)) continue;
          state.advisoryIds.add(advisory.id);
          globallyObserved.add(advisory.id);
          if (globallyObserved.size > MAX_ADVISORIES)
            throw new RangeError("OSV matched more than " + MAX_ADVISORIES + " source records; scope the inventory before purchase");
          state.row.matches.push(advisory);
        }
        const token = match.next_page_token;
        if (token === undefined || token === null || token === "") continue;
        if (typeof token !== "string" || token.length > 2048 || state.pageTokens.has(token))
          throw new Error("OSV returned an invalid or repeated page token; refusing incomplete coverage");
        state.pageTokens.add(token);
        state.pageToken = token;
        continuation.push(state);
      }
      pending = continuation;
    }
  }
  return rows;
}

function advisoryFixes(record, packageName) {
  const fixes = [];
  for (const affected of record.affected ?? []) {
    if (affected.package?.name !== packageName || affected.package?.ecosystem?.toLowerCase() !== "npm") continue;
    for (const range of affected.ranges ?? []) {
      for (const event of range.events ?? []) if (typeof event.fixed === "string") fixes.push(event.fixed);
    }
  }
  return [...new Set(fixes)].sort();
}
/**
 * Identifiers displayed to humans can change when OSV learns a new CVE
 * alias, or when duplicate source records are consolidated. An alert stream
 * must track the underlying original OSV record IDs, not a mutable display
 * choice; otherwise one new CVE alias manufactures a removal and new attack.
 */
function findingSourceIds(finding) {
  const records = finding?.advisory?.records;
  return [...new Set((Array.isArray(records) && records.length ? records : [finding.advisory.id])
    .filter(id => typeof id === "string"))].sort();
}
function findingBucket(finding) {
  return finding.component.name + "\u0000" + finding.component.version;
}
function findingDisplayKey(finding) {
  return finding.component.name + "@" + finding.component.version + "::" + finding.advisory.id;
}
function findingMaterialEvidence(finding) {
  const a = finding.advisory;
  return JSON.stringify({
    ids: findingSourceIds(finding),
    aliases: [...new Set(a.aliases ?? [])].sort(),
    modified: a.modified ?? null, withdrawn: a.withdrawn ?? null,
    fixes: [...new Set(a.fixes ?? [])].sort(),
    summary: a.summary ?? null, published: a.published ?? null,
    instances: finding.component.instances ?? [],
  });
}
export function diffCveFindings(previous, current) {
  const comparison = compareCveSourceScopes(previous, current);
  const before = new Map();
  for (const finding of previous?.findings ?? []) {
    const bucket = findingBucket(finding);
    const rows = before.get(bucket) ?? [];
    rows.push(finding);
    before.set(bucket, rows);
  }
  const events = [], matched = new Set();
  for (const finding of current?.findings ?? []) {
    const matches = (before.get(findingBucket(finding)) ?? []).filter(earlier =>
      findingSourceIds(earlier).some(id => findingSourceIds(finding).includes(id)));
    const key = findingDisplayKey(finding);
    if (!matches.length) {
      events.push({ kind: "added", key, finding });
      continue;
    }
    for (const earlier of matches) matched.add(earlier);
    if (matches.length !== 1 ||
        matches.some(earlier => findingDisplayKey(earlier) !== key ||
          findingMaterialEvidence(earlier) !== findingMaterialEvidence(finding))) {
      events.push({ kind: "updated", key, finding,
        previousKeys: matches.map(findingDisplayKey).sort(),
        reason: matches.length > 1 ? "source-records-consolidated" :
          matches[0].advisory.withdrawn !== finding.advisory.withdrawn ?
            "withdrawal-state-changed" : "source-record-or-dependency-evidence-changed" });
    }
  }
  // Never retract a confirmed alert on a partial scan, even if a new
  // required package record is missing or a graph proof was refused.
  if (current?.coverage?.complete && comparison.qualified) {
    for (const findings of before.values()) {
      for (const finding of findings) {
        if (matched.has(finding)) continue;
        events.push({ kind: "removed", key: findingDisplayKey(finding), prior: finding,
          reason: "no-longer-present-in-current-inventory-or-public-source" });
      }
    }
  }
  return events.sort((a, b) => a.key.localeCompare(b.key) || a.kind.localeCompare(b.kind));
}

/**
 * Commercially meaningful propagation: a SOURCE-BOUND pair of snapshots and
 * the actual observations distinguishing them. Missing source identity is a
 * refusal; a stable caller scope is permitted but remains caller-asserted.
 */
export function deriveCveChangeSet(previousScan, currentScan) {
  admitCveDiffRequest({ previousScan, currentScan });
  const comparison = compareCveSourceScopes(previousScan, currentScan);
  return {
    format: "561-cve-change-set-v1",
    comparison,
    coverage: {
      previousComplete: previousScan.coverage.complete,
      currentComplete: currentScan.coverage.complete,
      removalsAdmitted: currentScan.coverage.complete,
      currentPathEvidenceComplete: currentScan.coverage.pathEvidenceComplete ?? null,
      caveat: "A removed observation is not proof of code remediation or runtime exploitability"
    },
    events: diffCveFindings(previousScan, currentScan)
  };
}

/**
 * One bounded real service: exact npm releases -> current OSV match -> detailed
 * advisory/CVE aliases and affected installation instances. Does not assert
 * exploitability, running reachability or CVE numbering authority.
 */
export async function scanRepositoryCves(request, { fetchImplementation = fetch, now = () => new Date().toISOString() } = {}) {
  const plan = cveScanPlan(request);
  const { kind, source } = plan;
  const contents = source ? { packageLock: await fetchPublicLock(source, fetchImplementation) } : request;
  const resolved = installedNpmPackages(contents);
  const installed = dedupePackageVersions(resolved.packages);
  const matches = await queryOsv(installed, fetchImplementation);
  const ids = [...new Set(matches.flatMap(row => row.matches.map(v => v.id)))].sort();
  if (ids.length > MAX_ADVISORIES) throw new RangeError(`OSV matched ${ids.length} advisories; this bounded endpoint admits at most ${MAX_ADVISORIES}, use a scoped input`);
  // Bound concurrent source reads so one large inventory does not create
  // forty simultaneous advisory requests on the public upstream service.
  const details = new Map();
  for (let start = 0; start < ids.length; start += 5) {
    const batch = await Promise.all(ids.slice(start, start + 5).map(async id => {
      if (!isOsvRecordId(id))
        throw new TypeError("OSV advisory has invalid ID");
      const response = await fetchImplementation("https://api.osv.dev/v1/vulns/" + encodeURIComponent(id), {
        headers: { Accept: "application/json" }, signal: AbortSignal.timeout(12_000),
      });
      const detail = await responseJson(response, "OSV advisory");
      if (detail.id !== id || typeof detail.modified !== "string")
        throw new Error("OSV detail ID or revision did not match the queried advisory");
      return [id, detail];
    }));
    for (const [id, detail] of batch) details.set(id, detail);
  }
  // OSV aggregates several importer records about the same vulnerability.
  // Join only records sharing an explicit identifier/alias, scoped to the
  // exact affected package+version. Keep all original IDs and revisions.
  const findings = [];
  for (const { component, matches: matching } of matches) {
    const candidates = matching.map(({ id }) => {
      const record = details.get(id);
      return { id, record, identifiers: [id, ...(record.aliases ?? [])].filter(a => typeof a === "string") };
    });
    const groups = [];
    for (const candidate of candidates) {
      const touching = groups.filter(group => group.some(row =>
        row.identifiers.some(alias => candidate.identifiers.includes(alias))));
      if (!touching.length) { groups.push([candidate]); continue; }
      for (const group of touching) groups.splice(groups.indexOf(group), 1);
      groups.push([...touching.flat(), candidate]);
    }
    for (const group of groups) {
      const identifiers = [...new Set(group.flatMap(row => row.identifiers))].sort();
      const cves = identifiers.filter(a => CVE.test(a));
      const canonical = cves[0] ?? identifiers.find(a => a.startsWith("GHSA-")) ?? identifiers[0];
      const original = group.map(row => row.id).sort();
      const modifications = group.map(row => row.record.modified).filter(Boolean).sort();
      const fixes = [...new Set(group.flatMap(row => advisoryFixes(row.record, component.name)))].sort();
      const withdrawn = group.every(row => Boolean(row.record.withdrawn));
      findings.push({
        component: { name: component.name, version: component.version, ecosystem: "npm",
          purl: `pkg:npm/${encodeURIComponent(component.name).replace(/%2F/giu, "/")}@${encodeURIComponent(component.version)}`,
          instances: component.instances },
        advisory: { id: canonical, records: original, aliases: identifiers, cves,
          modified: modifications.at(-1) ?? null,
          published: group.map(row => row.record.published).filter(Boolean).sort()[0] ?? null,
          withdrawn: withdrawn ? group.map(row => row.record.withdrawn).filter(Boolean).sort()[0] ?? null : null,
          summary: group.find(row => typeof row.record.summary === "string")?.record.summary ?? null,
          fixes, url: `https://osv.dev/vulnerability/${encodeURIComponent(original[0])}` }
      });
    }
  }
  findings.sort((a, b) => a.component.name.localeCompare(b.component.name) ||
                    a.component.version.localeCompare(b.component.version) || a.advisory.id.localeCompare(b.advisory.id));
  const coverage = { complete: resolved.gaps.length === 0,
    pathEvidenceComplete: (resolved.graphPathsTruncated ?? 0) === 0 && resolved.gaps.length === 0,
    graphPathsTruncated: resolved.graphPathsTruncated ?? 0,
    pathExplanationLimit: resolved.pathExplanationLimit ?? null,
    meaning: "Known OSV version-matched advisories for the supplied npm releases; complete only means no discovered inventory gaps, not all vulnerabilities, exhaustive paths or proven reachability",
    gaps: resolved.gaps, examined: installed.length, matches: findings.length, asOf: now() };
  const result = { format: "561-cve-applicability-v1", source: plan.declaration, coverage, findings };
  if (request.previousScan !== undefined) {
    result.comparison = compareCveSourceScopes(request.previousScan, result);
    result.changes = diffCveFindings(request.previousScan, result);
  }
  return result;
}
