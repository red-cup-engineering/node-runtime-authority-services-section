/** Browser-safe native operation input projection, shared by server and world clients.
 * Controls prepare input; the installed operation contract remains its admission authority. */
/** Resolve one schema node's `$ref`: local `#`/`#/$defs/X` against `root`, a
 *  cross-schema address through the catalog — the same delegation
 *  `resolveRefRuntime` performs for validation. Undefined when the address is
 *  outside the package surface (the loose-slot convention has no literal to
 *  walk here, so the property degrades to unsupported). */
function resolveSchemaNode(node, root, seen = new Set()) {
  if (seen.has(node)) return undefined;
  seen = new Set([...seen, node]);
  const ref = node["$ref"];
  if (typeof ref !== "string") return node;
  if (ref === "#") return root;
  if (ref.startsWith("#/$defs/")) {
    const defs = root["$defs"];
    const sub = typeof defs === "object" && defs !== null ? (defs)[ref.slice("#/$defs/".length)] : undefined;
    return typeof sub === "object" && sub !== null ? resolveSchemaNode(sub, root, seen) : undefined;
  }
  return undefined;
}

function schemaFormControlKind(node) {
  if (Array.isArray(node["enum"])) return { kind: "enum", enumValues: node["enum"] };
  const type = node["type"];
  if (type === "string") return { kind: "string" };
  if (type === "number" || type === "integer") return { kind: "number" };
  if (type === "boolean") return { kind: "boolean" };
  if (type === "object" && typeof node["properties"] === "object" && node["properties"] !== null) return { kind: "object" };
  return { kind: "unsupported" };
}

// Native forms submit empty optional controls even when the object is absent.
// Its schema's required descendants take effect only once some input is supplied.
const hasSuppliedControlInput = (controls, params) => controls.some(control => control.kind === "object"
  ? hasSuppliedControlInput(control.controls ?? [], params)
  : params.has(control.propertyPath) && params.get(control.propertyPath) !== "");

/** Walk one object schema's top-level properties into typed control
 *  descriptors, recursing into nested objects. Undefined when `schema` is not
 *  itself an object schema with properties — the caller's signal to fall back
 *  to the single free-form textarea. */
function schemaFormControls(schema, root, prefix = "", ancestors = new Set()) {
  if (ancestors.has(schema)) return undefined;
  ancestors = new Set([...ancestors, schema]);
  if (schema["type"] !== "object" || typeof schema["properties"] !== "object" || schema["properties"] === null) return undefined;
  const properties = schema["properties"];
  if (Object.keys(properties).some(key => key.includes("."))) return undefined;
  const required = new Set(Array.isArray(schema["required"]) ? (schema["required"]) : []);
  const controls = [];
  for (const [key, rawProp] of Object.entries(properties)) {
    const path = prefix === "" ? key : `${prefix}.${key}`;
    const prop = typeof rawProp === "object" && rawProp !== null ? (rawProp) : {};
    const resolved = resolveSchemaNode(prop, root);
    if (resolved === undefined) {
      controls.push({ propertyName: key, propertyPath: path, required: required.has(key), kind: "unsupported" });
      continue;
    }
    const { kind, enumValues } = schemaFormControlKind(resolved);
    if (kind === "object") {
      const nested = schemaFormControls(resolved, root, path, ancestors);
      controls.push(nested === undefined
        ? { propertyName: key, propertyPath: path, required: required.has(key), kind: "unsupported" }
        : { propertyName: key, propertyPath: path, required: required.has(key), kind: "object", controls: nested });
      continue;
    }
    controls.push({ propertyName: key, propertyPath: path, required: required.has(key), kind, label: resolved.title, description: resolved.description, integer: resolved.type === "integer", constraints: {
      ...(typeof resolved.minimum === "number" ? { min: String(resolved.minimum) } : {}),
      ...(typeof resolved.maximum === "number" ? { max: String(resolved.maximum) } : {}),
      ...(Number.isInteger(resolved.minLength) ? { minLength: resolved.minLength } : {}),
      ...(Number.isInteger(resolved.maxLength) ? { maxLength: resolved.maxLength } : {}),
    }, ...(enumValues === undefined ? {} : { enumValues }) });
  }
  return controls;
}

/** Resolve an endpoint's `domainSchema` (a bare `$ref`, or an inline literal)
 *  to the concrete schema it addresses, then its top-level control walk —
 *  undefined when unresolvable or not an object schema. */
export function endpointSchemaFormControls(domainSchema) {
  if (domainSchema === undefined) return undefined;
  const root = resolveSchemaNode(domainSchema, domainSchema);
  return root === undefined ? undefined : schemaFormControls(root, root);
}

/** The inverse of the control walk: coerce one posted string value to the type
 *  its control descriptor declares. Numbers/booleans that fail to coerce are
 *  left as the raw string so the schema contract validator produces the rejection,
 *  rather than swallowing the error here. */
function coerceSchemaFormValue(control, raw) {
  if (control.kind === "number") {
    if (raw.trim() === "") return raw;
    const value = Number(raw);
    return Number.isFinite(value) ? value : raw;
  }
  if (control.kind === "boolean") return raw === "true" ? true : raw === "false" ? false : raw;
  if (control.kind === "enum" && control.enumValues !== undefined) {
    const index = control.enumValues.findIndex(value => JSON.stringify(value) === raw);
    return index < 0 ? raw : control.enumValues[index];
  }
  return raw;
}

function decodeSchemaFormValue(controls, params) {
  const out = {};
  for (const control of controls) {
    if (control.kind === "object" && control.controls !== undefined) {
      if (!control.required && !hasSuppliedControlInput(control.controls, params)) continue;
      const nested = decodeSchemaFormValue(control.controls, params);
      if (control.required || Object.keys(nested).length > 0) Object.defineProperty(out, control.propertyName, { value: nested, enumerable: true, writable: true, configurable: true });
      continue;
    }
    const raw = params.get(control.propertyPath);
    if (raw === null || (raw === "" && !control.required)) continue;
    if (control.kind === "unsupported") {
      try {
        Object.defineProperty(out, control.propertyName, { value: parseJsonValue(raw), enumerable: true, writable: true, configurable: true });
      } catch {
        Object.defineProperty(out, control.propertyName, { value: raw, enumerable: true, writable: true, configurable: true });
      }
      continue;
    }
    Object.defineProperty(out, control.propertyName, { value: coerceSchemaFormValue(control, raw), enumerable: true, writable: true, configurable: true });
  }
  return out;
}

function parseJsonValue(text) {
  return JSON.parse(text);
}

/**
 * Decode a posted `application/x-www-form-urlencoded` body back into the
 * input value shape `endpoint.domainSchema` declares, name-path property by
 * name-path property. Returns `undefined` when the schema does not resolve to a
 * walkable object shape, signalling the caller to leave the wire untouched
 * (the schema-less/free-form textarea path posts the whole input value as one
 * `body` control already handled upstream).
 */
export function decodeSchemaFormEntries(domainSchema, formBody) {
  const controls = endpointSchemaFormControls(domainSchema);
  if (controls === undefined) return undefined;
  return decodeSchemaFormValue(controls, new URLSearchParams(formBody));
}

export function schemaFields(controls, { optionalAncestor = false } = {}) {
  return controls.flatMap((control) => {
    const optional = optionalAncestor || !control.required;
    if (control.kind === "object") return schemaFields(control.controls ?? [], { optionalAncestor: optional });
    const options = control.kind === "boolean" ? [true, false] : control.enumValues;
    return [{
      name: control.propertyPath, label: control.label ?? control.propertyPath, required: !optional,
      kind: options ? "select" : control.kind === "number" ? "number" : control.kind === "unsupported" ? "textarea" : "text",
      ...(options ? { options: [{ value: "", label: "Choose…" }, ...options.map((value) => ({ value: control.kind === "enum" ? JSON.stringify(value) : String(value), label: String(value) }))] } : {}),
      description: control.description ?? (control.kind === "unsupported" ? "JSON value" : ""),
      ...(control.kind === "number" ? { step: control.integer ? "1" : "any" } : {}),
      ...control.constraints,
    }];
  });
}

