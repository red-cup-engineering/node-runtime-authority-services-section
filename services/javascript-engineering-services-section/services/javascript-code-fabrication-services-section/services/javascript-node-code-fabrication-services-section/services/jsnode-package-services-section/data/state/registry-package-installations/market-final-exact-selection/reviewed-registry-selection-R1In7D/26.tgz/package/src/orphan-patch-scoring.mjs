// Scoring algebra for the orphan-patch harvester's deterministic core
// (561-group-finance-operations-services-section note "The witnessed
// record as the product", section "The orphan-patch harvester"). Pure
// functions only: no network, no filesystem, no fork/publish effect.

const SEVERITY_WEIGHT = Object.freeze({ critical: 40, high: 30, medium: 20, low: 10, unknown: 5 });

const RELEASE_SILENCE_SATURATION_DAYS = 720;
const MAX_RELEASE_SILENCE_SCORE = 30;
const RESPONSE_SILENCE_SATURATION_DAYS = 180;
const MAX_RESPONSE_SILENCE_SCORE = 15;
const NO_RESPONSE_RECORD_SCORE = MAX_RESPONSE_SILENCE_SCORE;
const MAX_DEPENDENT_SCORE = 25;

function packageKey({ package: name, ecosystem }) {
  return `${ecosystem}::${name}`;
}

function severityWeight(severity) {
  const normalized = typeof severity === "string" ? severity.toLowerCase() : "unknown";
  return Object.hasOwn(SEVERITY_WEIGHT, normalized) ? SEVERITY_WEIGHT[normalized] : SEVERITY_WEIGHT.unknown;
}

// Linear ramp to a saturation point, never negative and never past the cap.
function saturatingRamp(value, saturationAt, cap) {
  const clamped = Math.max(0, Math.min(value, saturationAt));
  return (clamped / saturationAt) * cap;
}

function groupByPackage(rows) {
  const byKey = new Map();
  for (const row of rows) {
    const key = packageKey(row);
    if (!byKey.has(key)) byKey.set(key, []);
    byKey.get(key).push(row);
  }
  return byKey;
}

function indexByPackage(rows) {
  const byKey = new Map();
  for (const row of rows) byKey.set(packageKey(row), row);
  return byKey;
}

function unpatchedSeverityContribution(advisoriesForPackage) {
  const unpatched = advisoriesForPackage.filter((advisory) => advisory.fixedVersion === null);
  if (unpatched.length === 0) return null;
  let worst = unpatched[0];
  for (const advisory of unpatched) {
    if (severityWeight(advisory.severity) > severityWeight(worst.severity)) worst = advisory;
  }
  const advisoryIds = unpatched.map((advisory) => advisory.id).sort();
  const reasons = unpatched
    .slice()
    .sort((left, right) => left.id.localeCompare(right.id))
    .map((advisory) => `unpatched ${advisory.severity} advisory ${advisory.id} (published ${advisory.published})`);
  return { score: severityWeight(worst.severity), advisoryIds, reasons };
}

function maintainerSilenceContribution(maintenanceForPackage) {
  if (!maintenanceForPackage) {
    return { score: 0, reasons: ["no maintenance signal recorded"] };
  }
  const { lastReleaseDaysAgo, openIssueResponseDaysMedian } = maintenanceForPackage;
  const releaseScore = saturatingRamp(lastReleaseDaysAgo, RELEASE_SILENCE_SATURATION_DAYS, MAX_RELEASE_SILENCE_SCORE);
  const reasons = [`last release ${lastReleaseDaysAgo} days ago`];
  let responseScore;
  if (openIssueResponseDaysMedian === null) {
    responseScore = NO_RESPONSE_RECORD_SCORE;
    reasons.push("no issue response recorded");
  } else {
    responseScore = saturatingRamp(openIssueResponseDaysMedian, RESPONSE_SILENCE_SATURATION_DAYS, MAX_RESPONSE_SILENCE_SCORE);
    reasons.push(`median issue response ${openIssueResponseDaysMedian} days`);
  }
  return { score: releaseScore + responseScore, reasons };
}

function dependentImpactContribution(dependentsForPackage) {
  const dependentCount = dependentsForPackage ? dependentsForPackage.dependentCount : 0;
  if (dependentCount <= 0) return { score: 0, reasons: [] };
  const score = Math.min(MAX_DEPENDENT_SCORE, Math.log10(dependentCount + 1) * 10);
  return { score, reasons: [`${dependentCount} known dependents`] };
}

function round2(value) {
  return Math.round(value * 100) / 100;
}

/**
 * Scores public orphan-patch-harvester inputs into a ranked candidate list.
 *
 * The score for a package rises with (1) the worst-severity advisory that
 * has no known fixed version, (2) maintainer silence (days since the last
 * release, and days to a median issue response, or no response at all),
 * and (3) how many known packages depend on it. A package with only
 * already-patched advisories (every matching advisory carries a non-null
 * fixedVersion) is excluded from the result: the harvester's opportunity
 * is an unpatched, publicly disclosed vulnerability, not a resolved one.
 *
 * @param {object} input An OrphanPatchHarvestInput JSON object.
 * @param {object[]} input.advisories `{id, package, ecosystem, severity, published, fixedVersion}` rows; `fixedVersion` is `null` when no fix is known.
 * @param {object[]} input.maintenance `{package, ecosystem, lastReleaseDaysAgo, openIssueResponseDaysMedian}` rows; `openIssueResponseDaysMedian` is `null` when no issue response was ever recorded.
 * @param {object[]} input.dependents `{package, ecosystem, dependentCount}` rows.
 * @returns {{candidates: {package: string, ecosystem: string, score: number, reasons: string[], advisoryIds: string[]}[]}} An OrphanPatchHarvestOutput JSON object, candidates ranked by score descending (ties broken by ecosystem then package name, ascending).
 */
export function scoreOrphanPatchCandidates(input) {
  const advisoriesByPackage = groupByPackage(input.advisories);
  const maintenanceByPackage = indexByPackage(input.maintenance);
  const dependentsByPackage = indexByPackage(input.dependents);

  const candidates = [];
  for (const [key, advisoriesForPackage] of advisoriesByPackage) {
    const severityContribution = unpatchedSeverityContribution(advisoriesForPackage);
    if (severityContribution === null) continue;

    const silenceContribution = maintainerSilenceContribution(maintenanceByPackage.get(key));
    const dependentContribution = dependentImpactContribution(dependentsByPackage.get(key));
    const { package: packageName, ecosystem } = advisoriesForPackage[0];

    candidates.push({
      package: packageName,
      ecosystem,
      score: round2(severityContribution.score + silenceContribution.score + dependentContribution.score),
      reasons: [...severityContribution.reasons, ...silenceContribution.reasons, ...dependentContribution.reasons],
      advisoryIds: severityContribution.advisoryIds,
    });
  }

  candidates.sort((left, right) => {
    if (right.score !== left.score) return right.score - left.score;
    if (left.ecosystem !== right.ecosystem) return left.ecosystem.localeCompare(right.ecosystem);
    return left.package.localeCompare(right.package);
  });

  return { candidates };
}
