import test from "node:test";
import assert from "node:assert/strict";
import {
  admitCurrentPaidBriefing,
  createPaidBriefing,
  publishCurrentPaidBriefing,
  readCurrentPaidBriefing,
} from "../src/paid-briefing.mjs";

function makeBriefing(id, title) {
  return createPaidBriefing({
    id,
    issuedAt: "2026-09-25T00:00:00.000Z",
    issue: {
      title,
      dek: `${title} summary`,
      sections: [{ heading: `${title} section`, "body-markdown": `${title} findings`, sources: ["source-1"] }],
      references: {
        "source-1": { title: `${title} source`, URL: `https://example.test/${id}`, type: "webpage" },
      },
    },
  });
}

function briefingBucket() {
  const objects = new Map();
  return {
    async get(key) {
      const value = objects.get(key);
      return value === undefined ? null : { async text() { return value; } };
    },
    async put(key, value) {
      objects.set(key, value);
    },
  };
}

test("admission pins one publication through delivery while later requests see the replacement", async () => {
  const env = { KOIOS_INTELLIGENCE_BRIEFINGS: briefingBucket() };
  const issueA = makeBriefing("issue-a", "Issue A");
  const issueB = makeBriefing("issue-b", "Issue B");

  await publishCurrentPaidBriefing(issueA, env);
  const queryA = {};
  await admitCurrentPaidBriefing(queryA, env);

  await publishCurrentPaidBriefing(issueB, env);
  assert.equal((await readCurrentPaidBriefing(queryA, env)).id, "issue-a");

  const queryB = {};
  await admitCurrentPaidBriefing(queryB, env);
  assert.equal((await readCurrentPaidBriefing(queryB, env)).id, "issue-b");
});

test("a direct read without admission continues to return the current publication", async () => {
  const env = { KOIOS_INTELLIGENCE_BRIEFINGS: briefingBucket() };
  await publishCurrentPaidBriefing(makeBriefing("issue-current", "Current issue"), env);

  assert.equal((await readCurrentPaidBriefing({}, env)).id, "issue-current");
});
