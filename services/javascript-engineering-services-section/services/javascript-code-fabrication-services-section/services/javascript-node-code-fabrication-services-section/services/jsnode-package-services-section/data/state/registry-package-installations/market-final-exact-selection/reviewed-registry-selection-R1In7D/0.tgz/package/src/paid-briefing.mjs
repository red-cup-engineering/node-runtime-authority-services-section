/**
 * The commercial Koios briefing carrier.
 *
 * A newsroom owns the source claims and composes an issue.  This module turns
 * that issue into a bounded data product, then reads the current published
 * product from the market's R2 binding.  It deliberately knows nothing about
 * x402: payment remains the one market's networking concern.
 */

import { parseResearchPublication } from "@red-cup-engineering/mandate-portfolio-allocation-service/research-publication";
export const PAID_BRIEFING_KIND = "koios.news.intelligence-briefing/v1";
export const CURRENT_BRIEFING_KEY = "current.json";

// The market invokes admission before presenting its payment challenge and
// invokes compute only after settlement. Keep the exact admitted projection
// against the request-local query object so a concurrent publication cannot
// change what this purchase delivers. The market reuses this same object for
// both phases; a WeakMap keeps the binding private and request-scoped.
const admittedBriefings = new WeakMap();

function requireText(value, name) {
  if (typeof value !== "string" || value.trim() === "") throw new TypeError(`paid briefing requires ${name}`);
  return value.trim();
}

function requireInstant(value, name) {
  const text = requireText(value, name);
  if (!Number.isFinite(Date.parse(text))) throw new TypeError(`paid briefing requires ${name} to be an ISO-8601 instant`);
  return text;
}

function normalizeSection(section, index) {
  if (!section || typeof section !== "object") throw new TypeError(`paid briefing section ${index} must be an object`);
  const heading = requireText(section.heading, `section ${index} heading`);
  const body = requireText(section["body-markdown"], `section ${index} body-markdown`);
  const sources = Array.isArray(section.sources) ? section.sources.map((source) => requireText(source, `section ${index} source`)) : [];
  if (sources.length === 0) throw new TypeError(`paid briefing section ${index} requires at least one source`);
  return Object.freeze({ heading, "body-markdown": body, sources: Object.freeze(sources) });
}

/**
 * Forms the durable, sellable briefing artifact from an already-composed
 * issue.  No source claim, inference receipt, or reader identity is copied
 * into the artifact; the purchaser gets the issue and its cited references.
 */
export function createPaidBriefing({ issue, issuedAt, id, research, publication } = {}) {
  if (!issue || typeof issue !== "object") throw new TypeError("createPaidBriefing requires an issue");
  const sections = Array.isArray(issue.sections) ? issue.sections.map(normalizeSection) : [];
  if (sections.length === 0) throw new TypeError("createPaidBriefing requires an issue with sections");
  const references = issue.references && typeof issue.references === "object" && !Array.isArray(issue.references)
    ? Object.fromEntries(Object.entries(issue.references).map(([key, reference]) => {
      const source = requireText(key, "reference id");
      if (!reference || typeof reference !== "object") throw new TypeError(`paid briefing reference ${source} must be an object`);
      return [source, Object.freeze({
        id: requireText(reference.id ?? source, `reference ${source} id`),
        type: requireText(reference.type ?? "webpage", `reference ${source} type`),
        title: requireText(reference.title, `reference ${source} title`),
        URL: requireText(reference.URL, `reference ${source} URL`),
        ...(reference.issued === undefined ? {} : { issued: reference.issued }),
      })];
    }))
    : {};
  for (const section of sections) {
    for (const source of section.sources) {
      if (!Object.hasOwn(references, source)) throw new TypeError(`paid briefing section cites undeclared reference ${source}`);
    }
  }
  const dataset = research === undefined ? undefined : parseResearchPublication(research);
  if (dataset && Date.parse(dataset.issuedAt) > Date.parse(issuedAt)) throw new TypeError('briefing predates its research');
  if (dataset && dataset.observations.some(source => !Object.values(references).some(reference => reference.URL === source.source))) throw new TypeError('research sources must appear in briefing references');
  const release = publication === undefined ? undefined : Object.freeze({
    url: requireText(publication.url, 'publication URL'),
    candidateId: requireText(publication.candidateId, 'publication candidate'),
    releaseManifest: requireText(publication.releaseManifest, 'publication manifest'),
    assessmentReceipt: requireText(publication.assessmentReceipt, 'publication assessment receipt'),
  });
  if (release && new URL(release.url).protocol !== 'https:') throw new TypeError('publication URL requires HTTPS');
  return Object.freeze({
    kind: PAID_BRIEFING_KIND,
    id: requireText(id, "id"),
    issuedAt: requireInstant(issuedAt, "issuedAt"),
    title: requireText(issue.title, "issue title"),
    dek: typeof issue.dek === "string" ? issue.dek.trim() : "",
    sections: Object.freeze(sections),
    references: Object.freeze(references),
    ...(dataset ? { research: dataset } : {}),
    ...(release ? { publication: release } : {}),
  });
}

/** Validates an untrusted stored payload and returns the public product. */
export function parsePaidBriefing(payload) {
  if (!payload || typeof payload !== "object" || Array.isArray(payload)) throw new TypeError("paid briefing artifact must be an object");
  if (payload.kind !== PAID_BRIEFING_KIND) throw new TypeError(`paid briefing artifact kind must be ${PAID_BRIEFING_KIND}`);
  return createPaidBriefing({
    id: payload.id,
    issuedAt: payload.issuedAt,
    research: payload.research,
    publication: payload.publication,
    issue: {
      title: payload.title,
      dek: payload.dek,
      sections: payload.sections,
      references: payload.references,
    },
  });
}

function bucketFrom(env) {
  const bucket = env?.KOIOS_INTELLIGENCE_BRIEFINGS;
  if (!bucket || typeof bucket.get !== "function") {
    throw new TypeError("KOIOS_INTELLIGENCE_BRIEFINGS must bind the published Koios briefing bucket");
  }
  return bucket;
}

async function readCurrentBriefingFromBucket(env) {
  const bucket = bucketFrom(env);
  const object = await bucket.get(CURRENT_BRIEFING_KEY);
  if (object === null) throw new RangeError("no current Koios intelligence briefing has been published");
  if (object.size !== undefined && object.size > 1048576) throw new RangeError('paid briefing byte limit');
  const text = typeof object.text === "function" ? await object.text() : undefined;
  if (typeof text !== "string") throw new TypeError("published Koios briefing object does not expose text()");
  if (new TextEncoder().encode(text).length > 1048576) throw new RangeError('paid briefing byte limit');
  return parsePaidBriefing(JSON.parse(text));
}

/**
 * Publishes the next product only after it conforms to the same projection
 * the buyer will receive.  A scheduler or release action supplies the R2
 * binding; this code does not create a second delivery service.
 * @param {unknown} payload
 * @param {Record<string, unknown>} env
 * @returns {Promise<object>} the admitted public product
 */
export async function publishCurrentPaidBriefing(payload, env) {
  const briefing = parsePaidBriefing(payload);
  const body = JSON.stringify(briefing) + '\n';
  if (new TextEncoder().encode(body).length > 1048576) throw new RangeError('paid briefing byte limit');
  const bucket = bucketFrom(env);
  if (typeof bucket.put !== "function") {
    throw new TypeError("KOIOS_INTELLIGENCE_BRIEFINGS must support put() when publishing a Koios briefing");
  }
  await bucket.put(CURRENT_BRIEFING_KEY, body, {
    httpMetadata: { contentType: "application/json; charset=utf-8" },
    customMetadata: { kind: briefing.kind, id: briefing.id, issuedAt: briefing.issuedAt },
  });
  return briefing;
}

/**
 * Pre-payment admission for the market.  A missing issue is refused before
 * a buyer is challenged, rather than discovering absence after settlement.
 */
export async function admitCurrentPaidBriefing(query, env) {
  if (!query || typeof query !== "object" || Array.isArray(query)) {
    throw new TypeError("current Koios briefing admission requires a request query object");
  }
  admittedBriefings.set(query, await readCurrentBriefingFromBucket(env));
  return true;
}

/**
 * Reads the admitted paid briefing after the shared market has accepted
 * payment. The same query object is used during admission and delivery, so
 * publication changes cannot alter this request's product. Standalone reads
 * still return the current R2 product for direct package consumers.
 */
export async function readCurrentPaidBriefing(query, env) {
  if (!query || typeof query !== "object" || Array.isArray(query)) {
    throw new TypeError("current Koios briefing delivery requires a request query object");
  }
  const briefing = admittedBriefings.get(query) ?? await readCurrentBriefingFromBucket(env);
  admittedBriefings.delete(query);
  return briefing;
}
