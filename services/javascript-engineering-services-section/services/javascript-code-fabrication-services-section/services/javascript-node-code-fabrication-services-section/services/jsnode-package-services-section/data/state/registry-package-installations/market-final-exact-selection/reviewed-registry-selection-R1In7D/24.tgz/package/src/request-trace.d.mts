import type { IncomingHttpHeaders } from "node:http";
export type RequestTraceEntry = Readonly<{ e: unknown; a: string; v: unknown; t: unknown }>;
export type RequestTrace = Readonly<{
  kind: "web-server.request-trace";
  id: string;
  entries: readonly RequestTraceEntry[];
}>;
export type TraceRequest = Readonly<{
  method?: string | undefined;
  url?: string | undefined;
  httpVersion?: string | undefined;
  headers: IncomingHttpHeaders;
  socket: Readonly<{ remoteAddress?: string | undefined }>;
}>;
export type TraceJudgment = Readonly<{
  name: string;
  path: string;
  reason?: unknown;
  value: "absurd" | "potential" | "active" | "stable";
}>;
/** Diagnostic projection; the original request remains with its transport owner. */
export function traceRequest(req: TraceRequest, now: () => unknown): RequestTrace;
export function claimOf(trace: RequestTrace, claim: string): string | null;
export function allClaims(trace: RequestTrace, claim: string): string[];
export function appendEntries(trace: RequestTrace, entries: readonly RequestTraceEntry[]): RequestTrace;
export function settleRequestTrace<J extends TraceJudgment>(trace: RequestTrace, judgments: readonly J[]): Readonly<{
  kind: "web-server.request-settlement";
  trace: RequestTrace;
  value: TraceJudgment["value"];
  ready: boolean;
  denied: boolean;
  contradicted: boolean;
  unsettled: boolean;
  judgments: readonly J[];
  settlement: unknown;
  utterances: readonly unknown[];
  section: Readonly<{ contradicted: readonly J[] }>;
}>;
