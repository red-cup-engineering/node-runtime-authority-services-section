import { decimalUnits } from "@red-cup-engineering/exact-number-data-service/decimal-string";

/** Data's canonical decimal integer, restricted to the x402 EVM uint256 carrier.
 * Zero remains valid for metered usage and buyer budgets. A merchant selling
 * a fixed positive-price service rejects zero at its own admission.
 */
export function evmAtomicAmount(value) {
  if (typeof value !== "string" || value.length === 0 || value.length > 78)
    throw new TypeError("x402 amount must be a bounded canonical unsigned atomic decimal string");
  let amount;
  try { amount = decimalUnits(value, 0); }
  catch { throw new TypeError("x402 amount must be a canonical unsigned atomic decimal string"); }
  if (amount >= (1n << 256n))
    throw new RangeError("x402 amount exceeds EVM uint256");
  return amount;
}

export function evmNetwork(value) {
  if (!/^eip155:[1-9][0-9]*$/u.test(value ?? "")) {
    throw new TypeError("x402 network must be one explicit EVM CAIP-2 identifier");
  }
  return value;
}
 
/** Same source-qualified 20-byte EVM address admission for seller, pricing and recovery. */
export function evmAddress(value, label = "x402 EVM address") {
  if (typeof value !== "string" || !/^0x[0-9a-fA-F]{40}$/u.test(value)) {
    throw new TypeError(`${label} must be an explicit 20-byte EVM address`);
  }
  return value;
}
