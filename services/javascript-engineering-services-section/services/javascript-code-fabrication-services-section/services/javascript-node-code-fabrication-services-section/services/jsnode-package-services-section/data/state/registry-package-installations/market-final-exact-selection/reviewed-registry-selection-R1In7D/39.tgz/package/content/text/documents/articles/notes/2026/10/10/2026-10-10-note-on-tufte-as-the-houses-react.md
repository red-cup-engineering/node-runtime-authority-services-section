---
title: "TUFTE is the house's React"
description: "What the Leader said TUFTE is between 2026-08-27 and 2026-09-29: the Group's React-style framework and visual styling engine, not its web server and not a switch; how TUFTE sits among the web family (http-server, activitypub-server, VICTOR); tiles that need not be square; the sameness of the Group's sites as a defect; and how production sites are worked."
date-created: 2026-10-10
type: note
keywords:
  - tufte
  - victor
  - web-family
  - production-sites
cites-utterances:
  - "ni:///sha-256;AqNDZ8peoPUf4zMb3JMV32LrjvT8QjHz3qzgOVSmEEQ"
  - "ni:///sha-256;yyXxNCRO-rQFjFuPZ1gVt-XPqOSuzFLsDGNZ9j-uKeI"
  - "ni:///sha-256;_0OCNaUH6IOkKRCOENBNWcwtyMnX3waLc_QjxrNnsHQ"
  - "ni:///sha-256;eWx-g9WeYFqSb0j-8ZLr79ym97NvDcp49z-x4VN_luM"
  - "ni:///sha-256;Ux5VoEoPc1WiAtrHSxGpY49P4pI7Hor7RH9peeiTGSE"
  - "ni:///sha-256;zr6gE9ACirFJvpYkngTdVzFZgstc-mKrJCNGejIy_T0"
  - "ni:///sha-256;gZav6o4sYuH6YD7KFDpRITdvkFy3gb3kPVE6UvOC0kc"
---

# TUFTE is the house's React

## What TUFTE is

TUFTE is the Group's React-style framework: the engine in which a Group web property's interface is written and styled. It is a visual styling engine for websites. For the Group, turning TUFTE off is the same act as turning off CSS: the site loses its form. The Leader's analogy, 2026-09-29, names two other pieces of software and the roles they hold: React is the framework that composes an interface; Apache is a web server that answers requests. TUFTE holds React's role. The web server (`apps/computer-web-server`) holds Apache's role. TUFTE does not serve, and the server does not compose an interface.

The name has two expansions in the Leader's own words. On 2026-08-27 the Leader said "Tiling User Frontend Topology Engine"; the house term and the charter say Tiling User Form Topology Engine, and the Leader used "Form" on the ASSIST request. Both are carried as the term's aliases. The charter (`content/text/documents/articles/notes/2026/08/30/2026-08-30-note-on-tufte-framework-charter.md`) states that each word is load-bearing.

## TUFTE is not opinionated

A framework supplies mechanisms, and the property composes with them. TUFTE therefore does not impose a house look: the structural CSS the engine needs is separate from skin, and a property sets its own skin and composition. Tiles do not have to be square or boring: a tile is a region with a role, a span and a place in a topology, and a bordered rectangle is one renderer's realization of it (see `2026-10-01-note-on-tufte-medium-independent-form-topology-engine.md` on rectangles as one realization, and `2026/09/29/2026-09-29-note-on-publication-as-a-tufte-application.md` on varied tiles).

All the Group's web properties looking identical is a defect of the code that makes them. It is the symptom the 2026-09-29 note traces to publication being a document container rather than a TUFTE application. The Leader reads the code as both wrong and thin: the remedy is an engine that offers real range, not a tweak of its defaults.

## Where TUFTE sits in the web family

- On 2026-08-27 the Leader set the goal of a family of web applications that meets and then beats modern website tooling, so that the Group holds all the website tooling it will need, across all of its work. Where the living web needs study, the work studies it (`living-web-science-services-section`, founded on that day).
- The simpler applications sit lower in the stack. Legacy code needed for them is brought back and realized in the live tree: the http-server and the activitypub-server (`apps/computer-web-server`, `apps/activitypub-server`, `apps/indieweb-server`). The Leader's first statement had VICTOR as the application that fuses all of the living-web server applications.
- The Leader's later statement governs: on 2026-09-23 the ecosystem note says VICTOR is only meant to publish static websites, and what it carries beyond that is probably TUFTE's. The record is `engineering-services-section/content/text/documents/articles/notes/2026/09/27/2026-09-27-note-on-returning-victor-to-publishing.md`.
- The Leader asked on 2026-08-27 for research into the rest of the repository to find legacy code to revive and active code to improve before VICTOR uses any of it. The Leader's belief then was that the repository holds more working code than the agent knew. Notes recovered from legacy sit under `…/computer-engineering-services-section/content/text/documents/articles/notes/recovered/`; whether they answer the request is not judged here.
- On 2026-09-17 the Leader asked for TUFTE, QwzSpace and the other web engines to carry discrete capabilities, each doing its best job to meet and then beat the software in its class, with the work done as high-level reasoning and engineering improvement. Rule: `science-engineering-operations-parameterize-in-order`.
- The Leader asked that Terra-medium agents work concurrently on the simpler applications while the Leader and the senior agent worked on TUFTE and VICTOR.

## Production sites

A property that serves real people is worked slowly and with full reasoning. The Leader, 2026-09-29: reflect on the gravity and importance of the work and go slower. A page whose displayed creation date was 2026-09-27 when read on 2026-09-29 was reported as a defect; the cell's own `date-created` is the date a page shows, and the date a page was published is stated separately.

## Open

- Which of the Group's current properties still render with the shared publication skin is unread.
- The cause of the 2026-09-27 date on the 2026-09-29 reading of the Binding Generations workshops page is not established.
