import { requireOwnerPayee, assertQuotedPurchase, challengeNamesResource, matchesExactPaymentSettlementReport, prepareHttpResourceRequest, selectExactPaymentRequirement } from "./http-quote.mjs";
import { readFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import { setTimeout as delay } from "node:timers/promises";
import { x402HTTPClient } from "@x402/core/client";
import { exactEvmBuyerClient } from "./http-authorization.mjs";
import {
  loadSuccessorAccountBinding,
  SuccessorChainMigrationObstruction,
} from "./successor-deployment.mjs";

const ADDRESS = /^0x[0-9a-f]{40}$/u;
const HASH = /^0x[0-9a-f]{64}$/u;

function requiredSturdyRef(value) {
  if (!/^urn:ocapn:sturdyref:[A-Za-z0-9_-]{43}$/u.test(value ?? "")) {
    throw new TypeError("one canonical OCapN sturdy reference is required");
  }
  return value;
}

export class X402ResourceResponseError extends Error {
  constructor(message, { boundary, status, contentType, bodySha256, cause } = {}) {
    super(message, { cause });
    this.name = "X402ResourceResponseError";
    this.code = "X402_RESOURCE_INVALID_RESPONSE";
    this.boundary = boundary;
    this.status = status;
    this.contentType = contentType;
    this.bodySha256 = bodySha256;
  }
}

export class IncompleteSettlementEvidenceError extends Error {
  constructor(message) {
    super(message);
    this.name = "IncompleteSettlementEvidenceError";
    this.code = "X402_TERMINAL_SETTLEMENT_EVIDENCE_INCOMPLETE";
    this.type = "X402TerminalSettlementEvidenceRefusal";
  }
}

function incomplete(message) {
  throw new IncompleteSettlementEvidenceError(message);
}

function exactJoin(value, label) {
  if (!HASH.test(value?.demand ?? "")) incomplete(`${label}.demand must be one demand content address`);
  if (label !== "result" && !HASH.test(value?.offer ?? "")) {
    incomplete(`${label}.offer must be one offer content address`);
  }
  if (!HASH.test(value?.transactionHash ?? "") || !Number.isSafeInteger(value?.logIndex) || value.logIndex < 0) {
    incomplete(`${label} must name one exact transaction/log coordinate`);
  }
}

export function assertTerminalSettlementEvidence(receipt, terminal) {
  const evidence = terminal?.settlementEvidence;
  if (evidence?.type !== "SemioticExchangeTerminalSettlementEvidence") {
    incomplete("terminal delivery must carry SemioticExchangeTerminalSettlementEvidence");
  }
  const exchange = evidence.exchange;
  if (exchange?.network !== receipt?.exchange?.network
      || exchange?.address?.toLowerCase() !== receipt?.exchange?.address
      || !ADDRESS.test(exchange?.address?.toLowerCase() ?? "")) {
    incomplete("terminal exchange coordinate does not match the admitted successor deployment");
  }
  const joins = evidence.joins;
  if (!HASH.test(joins?.demand ?? "") || !HASH.test(joins?.offer ?? "")
      || !HASH.test(joins?.result?.contentAddress ?? "")) {
    incomplete("terminal evidence requires exact demand, offer, and result content addresses");
  }
  exactJoin(joins.purchase, "purchase");
  exactJoin(joins.result, "result");
  if (joins.purchase.demand !== joins.demand || joins.purchase.offer !== joins.offer
      || joins.result.demand !== joins.demand) {
    incomplete("demand, offer, purchase, and result joins do not commute");
  }
  const consideration = evidence.consideration;
  const requirement = receipt.requirement;
  const payer = receipt.customer?.split(":").at(-1)?.toLowerCase();
  if (consideration?.network !== requirement?.network
      || consideration?.network !== exchange.network
      || consideration?.asset?.toLowerCase() !== requirement?.asset?.toLowerCase()
      || consideration?.amount !== requirement?.amount
      || consideration?.payer?.toLowerCase() !== payer
      || consideration?.payee?.toLowerCase() !== requirement?.payTo?.toLowerCase()
      || !ADDRESS.test(consideration?.asset?.toLowerCase() ?? "")
      || !ADDRESS.test(consideration?.payer?.toLowerCase() ?? "")
      || !ADDRESS.test(consideration?.payee?.toLowerCase() ?? "")
      || !HASH.test(consideration?.transactionHash?.toLowerCase() ?? "")) {
    incomplete("terminal consideration must carry the exact network, asset, amount, payer, payee, and transaction");
  }
  const settlementReceipt = consideration.receipt;
  if (settlementReceipt?.transactionHash?.toLowerCase() !== consideration.transactionHash.toLowerCase()
      || settlementReceipt?.status !== 1
      || !Number.isSafeInteger(settlementReceipt?.blockNumber) || settlementReceipt.blockNumber < 0
      || !HASH.test(settlementReceipt?.blockHash?.toLowerCase() ?? "")) {
    incomplete("terminal consideration must include one successful exact transaction receipt");
  }
  return terminal;
}

async function digestBody(response) {
  const digest = createHash("sha256");
  if (response.body == null) return digest.digest("hex");
  let size = 0;
  for await (const chunk of response.body) {
    size += chunk.byteLength;
    if (size > 16 * 1024 * 1024) throw new RangeError("resource response exceeds 16 MiB");
    digest.update(chunk);
  }
  return digest.digest("hex");
}

async function exactJsonResponse(response, boundary) {
  const contentType = response.headers.get("content-type")?.split(";", 1)[0]?.trim().toLowerCase() ?? null;
  if (contentType !== "application/json" && !contentType?.endsWith("+json")) {
    throw new X402ResourceResponseError(
      `${boundary} returned a non-JSON representation`,
      {
        boundary,
        status: response.status,
        contentType,
        bodySha256: await digestBody(response),
      },
    );
  }
  const chunks = [];
  let size = 0;
  for await (const chunk of response.body ?? []) {
    size += chunk.byteLength;
    if (size > 16 * 1024 * 1024) throw new RangeError("resource response exceeds 16 MiB");
    chunks.push(Buffer.from(chunk));
  }
  const text = Buffer.concat(chunks).toString("utf8");
  try {
    return JSON.parse(text);
  } catch (cause) {
    throw new X402ResourceResponseError(
      `${boundary} returned malformed JSON`,
      {
        boundary,
        status: response.status,
        contentType,
        bodySha256: createHash("sha256").update(text).digest("hex"),
        cause,
      },
    );
  }
}

export async function openEnterpriseAccountPayer({
  deploymentManifestPath,
  accountBindingPath,
  keystorePath,
  passwordFile,
  openSettlementSigner,
} = {}) {
  const active = await loadSuccessorAccountBinding({
    manifestPath: deploymentManifestPath,
    accountBindingPath,
    nodeId: "x402-exact-purchase-service",
  });
  const binding = active.binding;
  const account = binding?.account?.address?.toLowerCase();
  const policySigner = binding?.policy?.signer?.toLowerCase();
  if (!/^0x[0-9a-f]{40}$/u.test(account ?? "") || !/^0x[0-9a-f]{40}$/u.test(policySigner ?? "")) {
    throw new Error("payer binding must name one enterprise account and policy signer");
  }
  if (typeof openSettlementSigner !== "function") {
    throw new SuccessorChainMigrationObstruction(
      "the enterprise owner must supply its successor policy-signer custody capability",
      { nodeId: "x402-exact-purchase-service" },
    );
  }
  const controller = await openSettlementSigner({ path: keystorePath, passwordFile });
  if (controller.address.toLowerCase() !== policySigner) {
    throw new Error("encrypted custody does not control the enterprise account policy signer");
  }
  return Object.freeze({
    network: active.deployment.chain,
    exchange: active.deployment.exchange,
    deploymentBlock: active.deployment.deploymentBlock,
    rpc: active.deployment.rpc,
    caip10: binding.account.caip10,
    signer: Object.freeze({
      address: account,
      signTypedData: ({ domain, types, message }) => controller.signTypedData(domain, types, message),
    }),
  });
}

/**
 * Buy an ordinary x402 HTTP representation using the customer's signer.
 * No exchange, OCapN reference, host ledger or seller-specific response shape
 * participates in this contract. Hooks let the owning enterprise retain intent
 * before transmission and settlement before reading delivery.
 */
export async function purchaseHttpResource({
  url, method = "GET", body, headers = {}, payer, network, asset, maximumAmount, expectedPayTo,
  acceptedQuote, rpcUrl, fetchImpl, httpClient, signal,
  maximumResponseBytes = 16 * 1024 * 1024, beforePayment, onSettlement, onDelivery,
} = {}) {
  const { resource, requestHeaders, serialized, request } =
    prepareHttpResourceRequest({ url, method, body, headers });
  if (typeof fetchImpl !== "function") {
    throw new TypeError("paid x402 purchase requires owner-controlled egress-safe fetchImpl");
  }
  const { token: selectedAsset, payee: admittedPayTo } =
    requireOwnerPayee({ network, asset, maximumAmount, expectedPayTo });
  const selectedNetwork = network;
  const ceiling = maximumAmount;
  // Refuse a mutated method/body/URL or weakened owner authority before egress.
  if (acceptedQuote !== undefined) {
    assertQuotedPurchase(acceptedQuote, {
      request, maximumAmount: ceiling, expectedPayTo: admittedPayTo,
    });
  }
  const account = payer?.signer?.address?.toLowerCase();
  if (payer?.network !== selectedNetwork || !ADDRESS.test(account ?? "")
      || payer?.caip10?.toLowerCase() !== `${selectedNetwork}:${account}`) {
    throw new TypeError("payer must bind its signer and CAIP-10 account to the admitted network");
  }
  if (!Number.isSafeInteger(maximumResponseBytes) || maximumResponseBytes < 1
      || maximumResponseBytes > 64 * 1024 * 1024) {
    throw new TypeError("maximumResponseBytes must be between 1 and 67108864");
  }
  const protocol = httpClient ?? new x402HTTPClient(exactEvmBuyerClient({
    signer: payer.signer, network: selectedNetwork, rpcUrl,
  }));
  const init = { method, headers: requestHeaders, body: serialized, redirect: "error",
    signal: signal ?? AbortSignal.timeout(30_000) };
  const unpaid = await fetchImpl(resource.href, init);
  if (unpaid.status !== 402) {
    const digest = createHash("sha256");
    let size = 0;
    for await (const chunk of unpaid.body ?? []) {
      size += chunk.byteLength;
      if (size > maximumResponseBytes) throw new RangeError("unpaid representation exceeds maximumResponseBytes");
      digest.update(chunk);
    }
    throw new X402ResourceResponseError(`resource did not return an x402 payment requirement: HTTP ${unpaid.status}`, {
      boundary: "unpaid resource response", status: unpaid.status,
      contentType: unpaid.headers.get("content-type")?.split(";", 1)[0]?.trim().toLowerCase() ?? null,
      bodySha256: digest.digest("hex"),
    });
  }
  // V2 carries the challenge in headers. It need not have a JSON body.
  let required;
  try { required = protocol.getPaymentRequiredResponse(name => unpaid.headers.get(name)); }
  finally { await unpaid.body?.cancel(); }
  if (required?.x402Version !== 2) throw new TypeError("one official x402 v2 challenge is required");
  // Bind the quote to the requested endpoint. A 561 market seller may
  // advertise the canonical path without caller-supplied query parameters,
  // while the paid replay retains those exact input parameters. Never admit
  // a different host, path, scheme, or a *rewritten* nonempty query.
  if (!challengeNamesResource(required, resource.href)) {
    throw new X402ResourceResponseError("x402 v2 challenge names a different resource URL", {
      boundary: "unpaid resource challenge",
      status: 402,
      contentType: unpaid.headers.get("content-type")?.split(";", 1)[0]?.trim().toLowerCase() ?? null,
    });
  }
  const requirement = selectExactPaymentRequirement(required, {
    network: selectedNetwork, asset: selectedAsset, maximumAmount: ceiling,
    expectedPayTo: admittedPayTo,
  });
  // A fresh 402 may still be within the budget while contradicting the
  // earlier quoted amount, payee, EIP-712 domain or timeout: do not sign it.
  if (acceptedQuote !== undefined) {
    assertQuotedPurchase(acceptedQuote, {
      request, requirement, maximumAmount: ceiling, expectedPayTo: admittedPayTo,
    });
  }
  const payload = await protocol.createPaymentPayload({ ...required, accepts: [requirement] });
  await beforePayment?.({
    request: { ...request, headers: { ...requestHeaders }, ...(serialized === undefined ? {} : { body: serialized }) },
    requirement: structuredClone(requirement), paymentPayload: structuredClone(payload),
  });
  // The signed authorization might have reached the merchant even if the
  // transport or payment-response decoder fails. This content-addressable
  // request/terms witness contains NO replayable payment signature or body.
  const pendingAttempt = Object.freeze({
    type: "X402HttpPaymentAttempt", customer: payer.caip10,
    request, requirement, settlementStatus: "unconfirmed",
  });
  let paid, payment;
  try {
    paid = await fetchImpl(resource.href, {
      ...init, headers: { ...requestHeaders, ...protocol.encodePaymentSignatureHeader(payload) },
      signal: signal ?? AbortSignal.timeout(30_000),
    });
    payment = await protocol.processPaymentResult(payload, name => paid.headers.get(name), paid.status);
  } catch (cause) {
    try { await paid?.body?.cancel(); } catch { /* original uncertainty prevails */ }
    const error = new Error("signed x402 payment outcome unknown; reconcile before retry", { cause });
    error.code = "X402_PAYMENT_OUTCOME_UNKNOWN";
    error.receipt = Object.freeze({
      ...pendingAttempt,
      ...(paid === undefined ? {} : { status: paid.status }),
    });
    throw error;
  }
  const settlement = payment.settleResponse;
  // The same pure rule is consumed by durable recovery and one-shot buying.
  // A facilitator's report is still not independent chain confirmation.
  const settlementMatchesRequirements = matchesExactPaymentSettlementReport(settlement, {
    network: selectedNetwork,
    asset: selectedAsset,
    amount: requirement.amount,
    payTo: requirement.payTo,
    payer: account,
  });
  const receipt = {
    type: "X402HttpPurchaseReceipt", customer: payer.caip10, request, requirement,
    ...(settlement === undefined ? {} : { settlement }),
    settlementMatchesRequirements,
    status: paid.status,
  };
  if (settlement !== undefined) {
    try {
      await onSettlement?.(structuredClone(receipt));
    } catch (cause) {
      // A provider can have reported a completed charge even if the buyer's
      // journal fails. Never discard its receipt or silently retry payment.
      try { await paid.body?.cancel(); } catch { /* retain the charge witness */ }
      const error = new Error("reported x402 settlement could not be journaled by the buyer", { cause });
      error.code = "X402_SETTLEMENT_OBSERVER_REFUSED";
      error.receipt = receipt;
      throw error;
    }
  }
  if (!settlementMatchesRequirements) {
    await paid.body?.cancel();
    const pending = settlement?.errorReason === "settlement_pending";
    const error = new Error(pending
      ? "x402 payment transaction is pending; reconcile the reported transaction before retry"
      : "paid response does not carry a matching successful x402 settlement");
    error.code = pending ? "X402_SETTLEMENT_PENDING" : "X402_SETTLEMENT_NOT_VERIFIED";
    error.receipt = receipt;
    throw error;
  }
  // A real charge can coexist with a failed computation/delivery. Keep the
  // settlement witness, but never represent an HTTP error as purchased output.
  if (!paid.ok) {
    await paid.body?.cancel();
    const error = new X402ResourceResponseError(
      `paid resource returned HTTP ${paid.status} after successful settlement`,
      {
        boundary: "paid resource response",
        status: paid.status,
        contentType: paid.headers.get("content-type")?.split(";", 1)[0]?.trim().toLowerCase() ?? null,
      },
    );
    error.receipt = receipt;
    throw error;
  }
  const chunks = [];
  let size = 0;
  try {
    for await (const chunk of paid.body ?? []) {
      size += chunk.byteLength;
      if (size > maximumResponseBytes) throw new RangeError("purchased representation exceeds maximumResponseBytes");
      chunks.push(Buffer.from(chunk));
    }
  } catch (error) {
    error.receipt = receipt;
    throw error;
  }
  const bytes = Buffer.concat(chunks);
  const delivered = Object.freeze({
    ...receipt,
    delivery: Object.freeze({
      status: paid.status, ok: paid.ok, contentType: paid.headers.get("content-type"),
      bytes: size, sha256: createHash("sha256").update(bytes).digest("hex"),
      encoding: "base64", body: bytes.toString("base64"),
    }),
  });
  // Delivery is a separate buyer-observed event, not a facilitator receipt or
  // customer acceptance. Record only the output's content address and byte
  // measurement: the potentially private purchased body remains with its buyer.
  if (onDelivery !== undefined) {
    const observed = Object.freeze({
      type: "X402HttpPurchaseDeliveryObservation",
      customer: delivered.customer,
      request: delivered.request,
      requirement: delivered.requirement,
      settlement: delivered.settlement,
      settlementMatchesRequirements: delivered.settlementMatchesRequirements,
      delivery: Object.freeze({
        status: delivered.delivery.status,
        contentType: delivered.delivery.contentType,
        bytes: delivered.delivery.bytes,
        sha256: delivered.delivery.sha256,
      }),
      requesterAccepted: null,
    });
    try {
      await onDelivery(structuredClone(observed));
    } catch (cause) {
      // No retry of an already-settled payment, and no lost purchased bytes.
      const error = new Error("paid x402 delivery could not be journaled by the buyer", { cause });
      error.code = "X402_DELIVERY_OBSERVER_REFUSED";
      error.receipt = delivered;
      throw error;
    }
  }
  return delivered;
}

export async function purchaseExactResource(options = {}) {
  requiredSturdyRef(options.sturdyRef);
  if (!ADDRESS.test(options.payer?.exchange ?? "")) {
    throw new Error("payer is not bound to the canonical SemioticExchange deployment");
  }
  const receipt = await purchaseHttpResource({
    ...options, method: "POST",
    headers: { ...options.headers, authorization: `OCapN ${options.sturdyRef}` },
  });
  const representation = receipt.delivery;
  const contentType = representation.contentType?.split(";", 1)[0]?.trim().toLowerCase();
  let responseBody;
  try {
    if (contentType !== "application/json" && !contentType?.endsWith("+json")) throw new TypeError("not JSON");
    responseBody = JSON.parse(Buffer.from(representation.body, "base64").toString("utf8"));
  } catch (cause) {
    const error = new X402ResourceResponseError("paid resource response returned an invalid JSON representation", {
      boundary: "paid resource response", status: receipt.status, contentType,
      bodySha256: representation.sha256, cause,
    });
    error.receipt = receipt;
    throw error;
  }
  const result = typeof responseBody.result === "string" ? new URL(responseBody.result, options.url) : null;
  if (receipt.status !== 202 || typeof responseBody.invocation !== "string" || !result
      || result.origin !== new URL(options.url).origin || result.username || result.password || result.hash) {
    const error = new Error("SemioticExchange purchase requires a same-origin asynchronous result");
    error.receipt = receipt;
    throw error;
  }
  return Object.freeze({
    type: "X402ExactPurchaseReceipt", customer: receipt.customer,
    exchange: Object.freeze({
      network: options.network, address: options.payer.exchange,
      deploymentBlock: options.payer.deploymentBlock,
    }),
    resource: receipt.request.url, request: receipt.request, requirement: receipt.requirement,
    invocation: responseBody.invocation, result: result.href, settlement: receipt.settlement,
  });
}

export async function awaitPurchasedResult({
  receipt,
  fetchImpl,
  pollIntervalMs = 250,
  signal,
  onObservation,
} = {}) {
  if (typeof fetchImpl !== "function") {
    throw new TypeError("paid x402 result observation requires owner-controlled egress-safe fetchImpl");
  }
  if (!Number.isSafeInteger(pollIntervalMs) || pollIntervalMs < 1) {
    throw new TypeError("pollIntervalMs must be a positive safe integer");
  }
  try {
    for (;;) {
      signal?.throwIfAborted();
      const response = await fetchImpl(receipt.result, {
        headers: { accept: "application/json" }, redirect: "error",
        signal: signal ?? AbortSignal.timeout(30_000),
      });
      const body = await exactJsonResponse(response, "purchased result response");
      await onObservation?.(Object.freeze({ status: response.status, body }));
      if (!response.ok) throw new Error(`purchased result refused observation: HTTP ${response.status}`);
      if (body.status === "terminal") {
        if (body.terminal?.type?.endsWith("Refusal")) {
          throw new Error(`paid capability refused delivery: ${body.terminal.reason ?? "unknown refusal"}`);
        }
        assertTerminalSettlementEvidence(receipt, body.terminal);
        return Object.freeze({ ...receipt, delivery: body.terminal });
      }
      // The seller's result face admits only these provisional states.
      // Silently polling arbitrary JSON forever can hide a malformed result
      // endpoint after the buyer has already been charged.
      if (!["pending", "settlement-pending", "recovery-pending", "recovery-started"].includes(body?.status)) {
        throw new X402ResourceResponseError("paid result returned an unknown lifecycle state", {
          boundary: "purchased result response",
          status: response.status,
          contentType: response.headers.get("content-type")?.split(";", 1)[0]?.trim().toLowerCase() ?? null,
        });
      }
      await delay(pollIntervalMs, undefined, { signal });
    }
  } catch (cause) {
    // Payment was already submitted before polling. Preserve its immutable
    // receipt on EVERY failed read, timeout, refusal and evidence mismatch:
    // the caller must reconcile or recover, not buy the same lot a second time.
    if (cause instanceof Error && cause.receipt === undefined) {
      cause.receipt = receipt;
    }
    throw cause;
  }
}

export async function purchaseAndAwaitExactResource(options) {
  return awaitPurchasedResult({
    receipt: await purchaseExactResource(options),
    fetchImpl: options.fetchImpl,
    pollIntervalMs: options.pollIntervalMs,
    signal: options.signal,
    onObservation: options.onObservation,
  });
}
