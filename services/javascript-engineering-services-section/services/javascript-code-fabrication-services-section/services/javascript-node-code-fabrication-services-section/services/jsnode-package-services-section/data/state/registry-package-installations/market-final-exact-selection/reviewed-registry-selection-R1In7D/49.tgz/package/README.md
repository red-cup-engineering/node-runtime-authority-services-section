# MCP Engineering Services Section

The house's one Model Context Protocol implementation. Every MCP server and client in the house composes these modules; none carries its own JSON-RPC framing.

- `./server`: `admitMcpToolArguments` reuses the original SignCell JSON Schema admission for stateless tool consumers; call it only when handling a tool invocation. `createMcpServer` dispatches the lifecycle (with protocol-version negotiation), tools, resources, resource templates, prompts, pagination, batches and an observation hook. Tool arguments are admitted against each tool's `inputSchema` before its handler runs, and every entry can be hidden per principal. `mcpOperationTools` turns typed operations into tools executed by the platform a request carries. The stdio transport accepts line and `Content-Length` framing.
- `./federation`: publish namespaced upstream tools through a live catalogue. Initial discovery and later refresh wait at most 1.5 seconds; unfinished peers publish independently when they answer.
- `./http`: `mcpResource` is the Streamable HTTP transport as one web-application resource. It serves the Fetch-shaped and native Node contexts and handles bearer authentication with the RFC 9728 `resource_metadata` challenge, origin checks, optional sessions, and single-event streams.
- `./client`: `createMcpClient` over `mcpHttpTransport` or `mcpStdioTransport`.
- `scripts/bridge-mcp-server.mjs`: expose one authenticated HTTP MCP node to a stdio-only client.
- `scripts/call-tool.mjs`: make one authenticated HTTP tool call with JSON on stdin and only the tool value on stdout; `--input-key` wraps carrier input and repeatable `--argument name=value` adds fixed host-supplied fields.
- `./tool-binding`: `bindMcpTools` turns an explicitly granted subset of a server's tools into function-calling tools.
- `./client-endpoint`: the JSON carrier for stdio and HTTP client configuration.
- `./catalog`: admission of external tool catalogs, and tool refusals. `assayMcpCatalogDispatch` assays exact `tools/list` to `tools/call` name transport; an underscore-or-hyphen near miss is reported as evidence and is never an alias.
- `./modern`: the 2026-07-28 modern stateless era as a named compatibility boundary, not a conformance claim: `mcpProtocolEra`, `MCP_PROTOCOL_MIGRATION_PROFILE` (not ready, with its blockers), `mcpModernRouteHeaders`, and `assayMcpModernRequest`, which checks a request's version, optional named client identity, required client capabilities and routing headers against its body; `mcpModernDiscovery`, which constructs the RFC-shaped, explicit supported-version and server-identity discovery value for a real consumer. This does not claim that the rest of the native server supports the modern lifecycle. `initialize` still negotiates only `MCP_PROTOCOL_VERSIONS`.
- `./articulating-tools`: the articulating apex's actions as tools.

Authorization servers live in `oauth-services-section`; what a server offers lives with the system that serves it.

Compose local tools with live catalogues explicitly: `createMcpServer({ name, version, tools: localTools, toolSources: [federation.tools] })`. The same options pass through `mcpResource`. Keep the source collection itself, including when initially empty; spreading a catalogue creates a snapshot and conveys no subscription.

An issued machine client running on the MCP host can explicitly dial its local
listener without changing its authenticated identity. Set `MCP_ORIGIN` to the
canonical HTTPS origin and `MCP_CONNECT_ORIGIN` to an HTTP loopback literal origin,
for example `http://127.0.0.1:18807`. Both `bridge-mcp-server` and `call-mcp-tool`
then send OAuth and MCP requests to that listener with the canonical Host header;
the OAuth resource and bridge cache identity remain canonical. The existing
client ID and secret still come from their existing environment file.

The shared `mcpConnectFetch` client adapter accepts only `127.0.0.1` or `[::1]`,
refuses requests outside `MCP_ORIGIN`, and never follows redirects or falls back
to the public endpoint. Leaving `MCP_CONNECT_ORIGIN` unset keeps the existing
fetch transport. This selects a local connection; it creates no client,
permission, listener, or server.
