# Semiotic Content Address

This repository's package is `@red-cup-engineering/semiotic-content-address`,
to be mounted at `red-cup-engineering/computer-data-engineering-services-section/lib/semiotic-content-address`
as a Git submodule selected by the Computer Data parent at initial receiving
commit `3211920f`. Later supplier advances belong to the source-owned
automatic Gitlink normalizer, not manually followed parent pointers.

**Source custody:** Computer Data owns carrier commitment (NFC normalization,
deterministic CBOR and RFC 6920 NI), exact byte addressing and the
*source-domain-specific audit* that diagnoses competing content identities.
That audit belongs to **this package**, not a separate Code package.
The scanner performs developer/source analysis; it is neither an independent
NI producer nor a replacement for general Computer Code source tooling.

**Upstream:** URI Services owns NI grammar; CBOR Services deterministic CBOR;
Cryptographic Data owns portable hashing and byte operations. No custom
cryptographic/URI/CBOR implementation is added here.

**Downstream:** SignCell uses the identified values to build typed cells.
SignChain, SignGraph and SignCraft carry subsequent witnessed order, structure,
and settlement. Content custody, network exchange and filesystem paths remain
owned by their own upstream effect/transport/path packages.

The original carrier and raw-byte functions, adversarial tests, and
source-domain identity audit were lifted from Data and Code with behavior
unchanged. Nothing about an NI proves evidence, equivalence of Mark surfaces,
institutional authority, or identity of source histories.

The repository slug `semiotic-content-address-system` is **historical** and
nonconforming as a package-section name. The canonical package name is
`semiotic-content-address`. A provider-level repository rename/move needs
independent receiving and exact .gitmodules source updating; avoid a
second repository solely to hide the old slug. Historical coordinate/proof
notes remain in `content/`; they are not executable authority.

The Computer Data parent currently retains the original package commit
`8974c45e` at its `lib/semiotic-content-address` Gitlink. This repository's
later `f3075e60` audit/CLI repair awaits advancement by the original
automatic Gitlink normalizer. Independent npm publication, native consumer
version selection, and the actual SignCell migration are **not established**.

The **canonical consumer import** for SignCell and all Data users, once the
independent package is released, is
`import { semanticId } from "@red-cup-engineering/semiotic-content-address"`.
The root export resolves to the original carrier implementation directly;
there is no second `./semiotic-content-address` alias or re-encoding layer.
