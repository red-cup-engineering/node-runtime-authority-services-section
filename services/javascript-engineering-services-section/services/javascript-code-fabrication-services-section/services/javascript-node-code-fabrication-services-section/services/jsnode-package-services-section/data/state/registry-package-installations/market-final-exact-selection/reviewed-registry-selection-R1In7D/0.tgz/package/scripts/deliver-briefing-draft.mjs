#!/usr/bin/env node
/**
 * @module deliver-briefing-draft
 * The effect: hand a composed briefing issue's rendered Markdown to
 * `@red-cup-engineering/buttondown-services-section`'s create-draft flow.
 * Draft only — never sends, per the product's founder fence (README).
 */
import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { createDraftEmail } from "@red-cup-engineering/buttondown-services-section";
import { readNewsletterKey } from "@red-cup-engineering/buttondown-services-section/newsletter-keys";

/** The briefing's Buttondown newsletter, whose key file holds its API key. */
export const NEWSLETTER = "koios-briefing";

/**
 * Creates a Buttondown draft email from one rendered issue Markdown file.
 * The key is the `koios-briefing` newsletter's (buttondown-services-section's
 * newsletter-keys); the command refuses cleanly, before touching the
 * filesystem or network, when none is held.
 *
 * @param {{issuePath: string, subject: string, status?: "draft"|"scheduled", publishDate?: string}} input
 * @param {{token: string|null, fetch?: typeof fetch}} capabilities The newsletter's key and the fetch capability.
 * @returns {Promise<{id: string, subject: string, status: string, publishDate: string|null, response: unknown}>}
 * @throws {Error} When `issuePath`/`subject` are missing, or no key is held.
 */
export async function deliverBriefingDraft({ issuePath, subject, status, publishDate } = {}, { token = null, fetch: fetchImpl = fetch } = {}) {
  if (!issuePath || !subject) {
    throw new Error("usage: deliver-briefing-draft.mjs <issue.md> <subject> [status] [publishDate]");
  }
  if (!token) throw new Error(`no Buttondown key is held for the ${NEWSLETTER} newsletter; refusing to attempt delivery.`);
  const body = await readFile(issuePath, "utf8");
  return createDraftEmail({ token, fetch: fetchImpl, subject, body, status, publishDate });
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const [issuePath, subject, status, publishDate] = process.argv.slice(2);
  try {
    const result = await deliverBriefingDraft({ issuePath, subject, status, publishDate }, { token: await readNewsletterKey(NEWSLETTER) });
    process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
  } catch (error) {
    process.stderr.write(`deliver-briefing-draft: ${error.message}\n`);
    process.exitCode = 2;
  }
}
